﻿namespace PAPERBROS
{
    partial class RegistrarAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrarAdmin));
            this.rdbtn_Usuario = new System.Windows.Forms.RadioButton();
            this.rdbtn_Admin = new System.Windows.Forms.RadioButton();
            this.txt_Registro1 = new System.Windows.Forms.TextBox();
            this.txt_Registro2 = new System.Windows.Forms.TextBox();
            this.txt_Registro3 = new System.Windows.Forms.TextBox();
            this.txt_Registro4 = new System.Windows.Forms.TextBox();
            this.txt_Registro5 = new System.Windows.Forms.TextBox();
            this.txt_Registro6 = new System.Windows.Forms.TextBox();
            this.lbl_Registro1 = new System.Windows.Forms.Label();
            this.btn_Registrar = new System.Windows.Forms.Button();
            this.lbl_Registro2 = new System.Windows.Forms.Label();
            this.lbl_Registro3 = new System.Windows.Forms.Label();
            this.lbl_Registro4 = new System.Windows.Forms.Label();
            this.lbl_Registro5 = new System.Windows.Forms.Label();
            this.lbl_Registro6 = new System.Windows.Forms.Label();
            this.rd_Gerente = new System.Windows.Forms.RadioButton();
            this.rd_Empleado = new System.Windows.Forms.RadioButton();
            this.lbl_Registro7 = new System.Windows.Forms.Label();
            this.txt_Registro7 = new System.Windows.Forms.TextBox();
            this.ofd_FotoAdmin = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbl_Aviso = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnl_foto = new System.Windows.Forms.Panel();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_tomar_foto = new System.Windows.Forms.Button();
            this.txt_QR = new System.Windows.Forms.Button();
            this.pb_foto = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_Camara = new System.Windows.Forms.ComboBox();
            this.btn_Open_foto = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_foto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // rdbtn_Usuario
            // 
            this.rdbtn_Usuario.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rdbtn_Usuario.AutoSize = true;
            this.rdbtn_Usuario.Enabled = false;
            this.rdbtn_Usuario.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdbtn_Usuario.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Usuario.Location = new System.Drawing.Point(126, 46);
            this.rdbtn_Usuario.Name = "rdbtn_Usuario";
            this.rdbtn_Usuario.Size = new System.Drawing.Size(57, 19);
            this.rdbtn_Usuario.TabIndex = 0;
            this.rdbtn_Usuario.Text = "Cliente";
            this.rdbtn_Usuario.UseVisualStyleBackColor = true;
            this.rdbtn_Usuario.CheckedChanged += new System.EventHandler(this.rdbtn_Usuario_CheckedChanged);
            // 
            // rdbtn_Admin
            // 
            this.rdbtn_Admin.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rdbtn_Admin.AutoSize = true;
            this.rdbtn_Admin.Enabled = false;
            this.rdbtn_Admin.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdbtn_Admin.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Admin.Location = new System.Drawing.Point(255, 69);
            this.rdbtn_Admin.Name = "rdbtn_Admin";
            this.rdbtn_Admin.Size = new System.Drawing.Size(92, 19);
            this.rdbtn_Admin.TabIndex = 1;
            this.rdbtn_Admin.Text = "Administrador";
            this.rdbtn_Admin.UseVisualStyleBackColor = true;
            this.rdbtn_Admin.CheckedChanged += new System.EventHandler(this.rdbtn_Admin_CheckedChanged);
            // 
            // txt_Registro1
            // 
            this.txt_Registro1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Registro1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Registro1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Registro1.Enabled = false;
            this.txt_Registro1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Registro1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Registro1.Location = new System.Drawing.Point(107, 199);
            this.txt_Registro1.Name = "txt_Registro1";
            this.txt_Registro1.Size = new System.Drawing.Size(100, 20);
            this.txt_Registro1.TabIndex = 2;
            // 
            // txt_Registro2
            // 
            this.txt_Registro2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Registro2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Registro2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Registro2.Enabled = false;
            this.txt_Registro2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Registro2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Registro2.Location = new System.Drawing.Point(319, 199);
            this.txt_Registro2.Name = "txt_Registro2";
            this.txt_Registro2.Size = new System.Drawing.Size(100, 20);
            this.txt_Registro2.TabIndex = 3;
            // 
            // txt_Registro3
            // 
            this.txt_Registro3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Registro3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Registro3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Registro3.Enabled = false;
            this.txt_Registro3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Registro3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Registro3.Location = new System.Drawing.Point(107, 245);
            this.txt_Registro3.Name = "txt_Registro3";
            this.txt_Registro3.Size = new System.Drawing.Size(100, 20);
            this.txt_Registro3.TabIndex = 4;
            // 
            // txt_Registro4
            // 
            this.txt_Registro4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Registro4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Registro4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Registro4.Enabled = false;
            this.txt_Registro4.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Registro4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Registro4.Location = new System.Drawing.Point(319, 245);
            this.txt_Registro4.Name = "txt_Registro4";
            this.txt_Registro4.Size = new System.Drawing.Size(100, 20);
            this.txt_Registro4.TabIndex = 5;
            this.txt_Registro4.TextChanged += new System.EventHandler(this.txt_Registro4_TextChanged);
            // 
            // txt_Registro5
            // 
            this.txt_Registro5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Registro5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Registro5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Registro5.Enabled = false;
            this.txt_Registro5.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Registro5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Registro5.Location = new System.Drawing.Point(107, 291);
            this.txt_Registro5.Name = "txt_Registro5";
            this.txt_Registro5.Size = new System.Drawing.Size(100, 20);
            this.txt_Registro5.TabIndex = 6;
            // 
            // txt_Registro6
            // 
            this.txt_Registro6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Registro6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Registro6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Registro6.Enabled = false;
            this.txt_Registro6.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Registro6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Registro6.Location = new System.Drawing.Point(319, 291);
            this.txt_Registro6.Name = "txt_Registro6";
            this.txt_Registro6.Size = new System.Drawing.Size(100, 20);
            this.txt_Registro6.TabIndex = 7;
            // 
            // lbl_Registro1
            // 
            this.lbl_Registro1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Registro1.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Registro1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Registro1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Registro1.Location = new System.Drawing.Point(3, 29);
            this.lbl_Registro1.Name = "lbl_Registro1";
            this.lbl_Registro1.Size = new System.Drawing.Size(83, 62);
            this.lbl_Registro1.TabIndex = 8;
            this.lbl_Registro1.Text = "----";
            // 
            // btn_Registrar
            // 
            this.btn_Registrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Registrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Registrar.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_Registrar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Registrar.Location = new System.Drawing.Point(474, 202);
            this.btn_Registrar.Name = "btn_Registrar";
            this.btn_Registrar.Size = new System.Drawing.Size(75, 23);
            this.btn_Registrar.TabIndex = 14;
            this.btn_Registrar.Text = "Registrar";
            this.btn_Registrar.UseVisualStyleBackColor = true;
            this.btn_Registrar.Click += new System.EventHandler(this.btn_Registrar_Click);
            // 
            // lbl_Registro2
            // 
            this.lbl_Registro2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Registro2.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Registro2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Registro2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Registro2.Location = new System.Drawing.Point(209, 29);
            this.lbl_Registro2.Name = "lbl_Registro2";
            this.lbl_Registro2.Size = new System.Drawing.Size(90, 34);
            this.lbl_Registro2.TabIndex = 16;
            this.lbl_Registro2.Text = "----";
            // 
            // lbl_Registro3
            // 
            this.lbl_Registro3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Registro3.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Registro3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Registro3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Registro3.Location = new System.Drawing.Point(6, 75);
            this.lbl_Registro3.Name = "lbl_Registro3";
            this.lbl_Registro3.Size = new System.Drawing.Size(81, 72);
            this.lbl_Registro3.TabIndex = 17;
            this.lbl_Registro3.Text = "----";
            // 
            // lbl_Registro4
            // 
            this.lbl_Registro4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Registro4.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Registro4.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Registro4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Registro4.Location = new System.Drawing.Point(209, 72);
            this.lbl_Registro4.Name = "lbl_Registro4";
            this.lbl_Registro4.Size = new System.Drawing.Size(90, 33);
            this.lbl_Registro4.TabIndex = 18;
            this.lbl_Registro4.Text = "----";
            // 
            // lbl_Registro5
            // 
            this.lbl_Registro5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Registro5.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Registro5.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Registro5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Registro5.Location = new System.Drawing.Point(6, 118);
            this.lbl_Registro5.Name = "lbl_Registro5";
            this.lbl_Registro5.Size = new System.Drawing.Size(80, 63);
            this.lbl_Registro5.TabIndex = 19;
            this.lbl_Registro5.Text = "----";
            // 
            // lbl_Registro6
            // 
            this.lbl_Registro6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Registro6.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Registro6.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Registro6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Registro6.Location = new System.Drawing.Point(209, 118);
            this.lbl_Registro6.Name = "lbl_Registro6";
            this.lbl_Registro6.Size = new System.Drawing.Size(90, 37);
            this.lbl_Registro6.TabIndex = 20;
            this.lbl_Registro6.Text = "----";
            // 
            // rd_Gerente
            // 
            this.rd_Gerente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rd_Gerente.AutoSize = true;
            this.rd_Gerente.Enabled = false;
            this.rd_Gerente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.rd_Gerente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rd_Gerente.Location = new System.Drawing.Point(255, 46);
            this.rd_Gerente.Name = "rd_Gerente";
            this.rd_Gerente.Size = new System.Drawing.Size(60, 19);
            this.rd_Gerente.TabIndex = 21;
            this.rd_Gerente.Text = "Gerente";
            this.rd_Gerente.UseVisualStyleBackColor = true;
            this.rd_Gerente.CheckedChanged += new System.EventHandler(this.rd_Gerente_CheckedChanged);
            // 
            // rd_Empleado
            // 
            this.rd_Empleado.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rd_Empleado.AutoSize = true;
            this.rd_Empleado.Enabled = false;
            this.rd_Empleado.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.rd_Empleado.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rd_Empleado.Location = new System.Drawing.Point(125, 69);
            this.rd_Empleado.Name = "rd_Empleado";
            this.rd_Empleado.Size = new System.Drawing.Size(71, 19);
            this.rd_Empleado.TabIndex = 23;
            this.rd_Empleado.Text = "Empleado";
            this.rd_Empleado.UseVisualStyleBackColor = true;
            this.rd_Empleado.CheckedChanged += new System.EventHandler(this.rd_Empleado_CheckedChanged);
            // 
            // lbl_Registro7
            // 
            this.lbl_Registro7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Registro7.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Registro7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Registro7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Registro7.Location = new System.Drawing.Point(3, 166);
            this.lbl_Registro7.Name = "lbl_Registro7";
            this.lbl_Registro7.Size = new System.Drawing.Size(84, 29);
            this.lbl_Registro7.TabIndex = 25;
            this.lbl_Registro7.Text = "----";
            // 
            // txt_Registro7
            // 
            this.txt_Registro7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Registro7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Registro7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Registro7.Enabled = false;
            this.txt_Registro7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Registro7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Registro7.Location = new System.Drawing.Point(107, 336);
            this.txt_Registro7.Name = "txt_Registro7";
            this.txt_Registro7.PasswordChar = '*';
            this.txt_Registro7.Size = new System.Drawing.Size(100, 20);
            this.txt_Registro7.TabIndex = 24;
            // 
            // ofd_FotoAdmin
            // 
            this.ofd_FotoAdmin.FileName = "openFileDialog1";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.groupBox1.Controls.Add(this.rd_Empleado);
            this.groupBox1.Controls.Add(this.rd_Gerente);
            this.groupBox1.Controls.Add(this.rdbtn_Usuario);
            this.groupBox1.Controls.Add(this.rdbtn_Admin);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(14, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(446, 118);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.groupBox2.Controls.Add(this.lbl_Aviso);
            this.groupBox2.Controls.Add(this.lbl_Registro7);
            this.groupBox2.Controls.Add(this.lbl_Registro5);
            this.groupBox2.Controls.Add(this.lbl_Registro3);
            this.groupBox2.Controls.Add(this.lbl_Registro6);
            this.groupBox2.Controls.Add(this.lbl_Registro1);
            this.groupBox2.Controls.Add(this.lbl_Registro4);
            this.groupBox2.Controls.Add(this.lbl_Registro2);
            this.groupBox2.Location = new System.Drawing.Point(14, 173);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(446, 227);
            this.groupBox2.TabIndex = 27;
            this.groupBox2.TabStop = false;
            // 
            // lbl_Aviso
            // 
            this.lbl_Aviso.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lbl_Aviso.AutoSize = true;
            this.lbl_Aviso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aviso.ForeColor = System.Drawing.Color.Red;
            this.lbl_Aviso.Location = new System.Drawing.Point(411, 72);
            this.lbl_Aviso.Name = "lbl_Aviso";
            this.lbl_Aviso.Size = new System.Drawing.Size(18, 24);
            this.lbl_Aviso.TabIndex = 0;
            this.lbl_Aviso.Text = "*";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(81, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(394, 33);
            this.label1.TabIndex = 32;
            this.label1.Text = "REGISTRO DE USUARIOS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(481, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(69, 39);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = global::PAPERBROS.Properties.Resources.PollosHermanos;
            this.pictureBox1.Location = new System.Drawing.Point(465, 62);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 83);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.SlateBlue;
            this.panel2.Location = new System.Drawing.Point(0, 47);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(568, 5);
            this.panel2.TabIndex = 34;
            // 
            // pnl_foto
            // 
            this.pnl_foto.Controls.Add(this.btn_Cancel);
            this.pnl_foto.Controls.Add(this.btn_tomar_foto);
            this.pnl_foto.Controls.Add(this.txt_QR);
            this.pnl_foto.Controls.Add(this.pb_foto);
            this.pnl_foto.Controls.Add(this.label4);
            this.pnl_foto.Controls.Add(this.cmb_Camara);
            this.pnl_foto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_foto.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.pnl_foto.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.pnl_foto.Location = new System.Drawing.Point(0, 0);
            this.pnl_foto.Name = "pnl_foto";
            this.pnl_foto.Size = new System.Drawing.Size(565, 412);
            this.pnl_foto.TabIndex = 24;
            this.pnl_foto.Visible = false;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Cancel.Location = new System.Drawing.Point(408, 173);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(82, 30);
            this.btn_Cancel.TabIndex = 22;
            this.btn_Cancel.Text = "Cancelar";
            this.btn_Cancel.UseVisualStyleBackColor = false;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_tomar_foto
            // 
            this.btn_tomar_foto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_tomar_foto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_tomar_foto.Enabled = false;
            this.btn_tomar_foto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_tomar_foto.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_tomar_foto.Location = new System.Drawing.Point(408, 127);
            this.btn_tomar_foto.Name = "btn_tomar_foto";
            this.btn_tomar_foto.Size = new System.Drawing.Size(82, 30);
            this.btn_tomar_foto.TabIndex = 21;
            this.btn_tomar_foto.Text = "Tomar foto";
            this.btn_tomar_foto.UseVisualStyleBackColor = false;
            this.btn_tomar_foto.Click += new System.EventHandler(this.btn_tomar_foto_Click);
            // 
            // txt_QR
            // 
            this.txt_QR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_QR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.txt_QR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_QR.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_QR.Location = new System.Drawing.Point(404, 36);
            this.txt_QR.Name = "txt_QR";
            this.txt_QR.Size = new System.Drawing.Size(82, 30);
            this.txt_QR.TabIndex = 20;
            this.txt_QR.Text = "Camara";
            this.txt_QR.UseVisualStyleBackColor = false;
            this.txt_QR.Click += new System.EventHandler(this.txt_QR_Click);
            // 
            // pb_foto
            // 
            this.pb_foto.BackColor = System.Drawing.Color.DimGray;
            this.pb_foto.Location = new System.Drawing.Point(85, 87);
            this.pb_foto.Name = "pb_foto";
            this.pb_foto.Size = new System.Drawing.Size(282, 221);
            this.pb_foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_foto.TabIndex = 19;
            this.pb_foto.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(37, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 15);
            this.label4.TabIndex = 18;
            this.label4.Text = "Camaras";
            // 
            // cmb_Camara
            // 
            this.cmb_Camara.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmb_Camara.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.cmb_Camara.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Camara.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.cmb_Camara.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.cmb_Camara.FormattingEnabled = true;
            this.cmb_Camara.Location = new System.Drawing.Point(107, 42);
            this.cmb_Camara.Name = "cmb_Camara";
            this.cmb_Camara.Size = new System.Drawing.Size(278, 23);
            this.cmb_Camara.TabIndex = 17;
            // 
            // btn_Open_foto
            // 
            this.btn_Open_foto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Open_foto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Open_foto.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_Open_foto.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Open_foto.Location = new System.Drawing.Point(476, 151);
            this.btn_Open_foto.Name = "btn_Open_foto";
            this.btn_Open_foto.Size = new System.Drawing.Size(75, 39);
            this.btn_Open_foto.TabIndex = 36;
            this.btn_Open_foto.Text = "Tomar foto";
            this.btn_Open_foto.UseVisualStyleBackColor = true;
            this.btn_Open_foto.Visible = false;
            this.btn_Open_foto.Click += new System.EventHandler(this.btn_Open_foto_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(9, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(69, 39);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 37;
            this.pictureBox3.TabStop = false;
            // 
            // RegistrarAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(565, 412);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btn_Open_foto);
            this.Controls.Add(this.pnl_foto);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Registro7);
            this.Controls.Add(this.txt_Registro6);
            this.Controls.Add(this.txt_Registro5);
            this.Controls.Add(this.txt_Registro4);
            this.Controls.Add(this.txt_Registro3);
            this.Controls.Add(this.txt_Registro2);
            this.Controls.Add(this.txt_Registro1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_Registrar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RegistrarAdmin";
            this.Load += new System.EventHandler(this.RegistrarAdmin_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_foto.ResumeLayout(false);
            this.pnl_foto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_foto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rdbtn_Usuario;
        private System.Windows.Forms.RadioButton rdbtn_Admin;
        private System.Windows.Forms.TextBox txt_Registro1;
        private System.Windows.Forms.TextBox txt_Registro2;
        private System.Windows.Forms.TextBox txt_Registro3;
        private System.Windows.Forms.TextBox txt_Registro4;
        private System.Windows.Forms.TextBox txt_Registro5;
        private System.Windows.Forms.TextBox txt_Registro6;
        private System.Windows.Forms.Label lbl_Registro1;
        private System.Windows.Forms.Button btn_Registrar;
        private System.Windows.Forms.Label lbl_Registro2;
        private System.Windows.Forms.Label lbl_Registro3;
        private System.Windows.Forms.Label lbl_Registro4;
        private System.Windows.Forms.Label lbl_Registro5;
        private System.Windows.Forms.Label lbl_Registro6;
        private System.Windows.Forms.RadioButton rd_Gerente;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton rd_Empleado;
        private System.Windows.Forms.Label lbl_Registro7;
        private System.Windows.Forms.TextBox txt_Registro7;
        private System.Windows.Forms.OpenFileDialog ofd_FotoAdmin;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbl_Aviso;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnl_foto;
        private System.Windows.Forms.PictureBox pb_foto;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmb_Camara;
        private System.Windows.Forms.Button btn_tomar_foto;
        private System.Windows.Forms.Button txt_QR;
        private System.Windows.Forms.Button btn_Open_foto;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}