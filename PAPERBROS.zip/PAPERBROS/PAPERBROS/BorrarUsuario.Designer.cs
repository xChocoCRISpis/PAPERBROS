﻿
namespace PAPERBROS
{
    partial class BorrarUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BorrarUsuario));
            this.dgv_BorrarUsuario = new System.Windows.Forms.DataGridView();
            this.lbl_BorrarU1 = new System.Windows.Forms.Label();
            this.txt_BorrarU1 = new System.Windows.Forms.TextBox();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.txt_Buscar = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BorrarUsuario)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_BorrarUsuario
            // 
            this.dgv_BorrarUsuario.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.dgv_BorrarUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_BorrarUsuario.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgv_BorrarUsuario.Location = new System.Drawing.Point(12, 212);
            this.dgv_BorrarUsuario.Name = "dgv_BorrarUsuario";
            this.dgv_BorrarUsuario.Size = new System.Drawing.Size(468, 259);
            this.dgv_BorrarUsuario.TabIndex = 0;
            this.dgv_BorrarUsuario.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_BorrarUsuario_CellClick);
            this.dgv_BorrarUsuario.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_BorrarUsuario_CellContentClick);
            // 
            // lbl_BorrarU1
            // 
            this.lbl_BorrarU1.Location = new System.Drawing.Point(-78, 87);
            this.lbl_BorrarU1.Name = "lbl_BorrarU1";
            this.lbl_BorrarU1.Size = new System.Drawing.Size(56, 17);
            this.lbl_BorrarU1.TabIndex = 4;
            this.lbl_BorrarU1.Text = "---";
            this.lbl_BorrarU1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txt_BorrarU1
            // 
            this.txt_BorrarU1.Location = new System.Drawing.Point(131, 64);
            this.txt_BorrarU1.Name = "txt_BorrarU1";
            this.txt_BorrarU1.Size = new System.Drawing.Size(106, 20);
            this.txt_BorrarU1.TabIndex = 5;
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_buscar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_buscar.Location = new System.Drawing.Point(25, 19);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(100, 13);
            this.lbl_buscar.TabIndex = 17;
            this.lbl_buscar.Text = "Buscar por RFC:";
            // 
            // txt_Buscar
            // 
            this.txt_Buscar.Location = new System.Drawing.Point(131, 16);
            this.txt_Buscar.Name = "txt_Buscar";
            this.txt_Buscar.Size = new System.Drawing.Size(106, 20);
            this.txt_Buscar.TabIndex = 18;
            this.txt_Buscar.TextChanged += new System.EventHandler(this.txt_Buscar_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.txt_Buscar);
            this.groupBox1.Controls.Add(this.lbl_buscar);
            this.groupBox1.Controls.Add(this.lbl_BorrarU1);
            this.groupBox1.Controls.Add(this.txt_BorrarU1);
            this.groupBox1.Location = new System.Drawing.Point(12, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(468, 130);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PAPERBROS.Properties.Resources.image_removebg_preview__10_;
            this.pictureBox1.Location = new System.Drawing.Point(362, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 32;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.btn_Borrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(63, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(357, 39);
            this.label1.TabIndex = 20;
            this.label1.Text = "BORRAR CLIENTES";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PAPERBROS.Properties.Resources.image_removebg_preview__12_;
            this.pictureBox2.Location = new System.Drawing.Point(424, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(63, 39);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            // 
            // BorrarUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(498, 483);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgv_BorrarUsuario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BorrarUsuario";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BorrarUsuario)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_BorrarUsuario;
        private System.Windows.Forms.Label lbl_BorrarU1;
        private System.Windows.Forms.TextBox txt_BorrarU1;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.TextBox txt_Buscar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}