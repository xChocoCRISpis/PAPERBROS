﻿namespace PAPERBROS
{
    partial class Opciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Seleccionar = new System.Windows.Forms.Button();
            this.cmb_Opciones = new System.Windows.Forms.ComboBox();
            this.lbl_TipoAdmin = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pic_foto = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pic_foto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Seleccionar
            // 
            this.btn_Seleccionar.Enabled = false;
            this.btn_Seleccionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Seleccionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Seleccionar.ForeColor = System.Drawing.Color.White;
            this.btn_Seleccionar.Location = new System.Drawing.Point(161, 118);
            this.btn_Seleccionar.Name = "btn_Seleccionar";
            this.btn_Seleccionar.Size = new System.Drawing.Size(129, 24);
            this.btn_Seleccionar.TabIndex = 0;
            this.btn_Seleccionar.Text = "Seleccionar";
            this.btn_Seleccionar.UseVisualStyleBackColor = true;
            this.btn_Seleccionar.Click += new System.EventHandler(this.btn_Seleccionar_Click);
            // 
            // cmb_Opciones
            // 
            this.cmb_Opciones.FormattingEnabled = true;
            this.cmb_Opciones.Location = new System.Drawing.Point(161, 65);
            this.cmb_Opciones.Name = "cmb_Opciones";
            this.cmb_Opciones.Size = new System.Drawing.Size(129, 21);
            this.cmb_Opciones.TabIndex = 1;
            this.cmb_Opciones.SelectedIndexChanged += new System.EventHandler(this.cmb_Opciones_SelectedIndexChanged);
            // 
            // lbl_TipoAdmin
            // 
            this.lbl_TipoAdmin.AutoSize = true;
            this.lbl_TipoAdmin.BackColor = System.Drawing.Color.Blue;
            this.lbl_TipoAdmin.Location = new System.Drawing.Point(119, 118);
            this.lbl_TipoAdmin.Name = "lbl_TipoAdmin";
            this.lbl_TipoAdmin.Size = new System.Drawing.Size(13, 13);
            this.lbl_TipoAdmin.TabIndex = 8;
            this.lbl_TipoAdmin.Text = "--";
            this.lbl_TipoAdmin.Click += new System.EventHandler(this.lbl_TipoAdmin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 33);
            this.label1.TabIndex = 11;
            this.label1.Text = "MENÚ DE OPCIONES";
            // 
            // pic_foto
            // 
            this.pic_foto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pic_foto.Location = new System.Drawing.Point(12, 65);
            this.pic_foto.Name = "pic_foto";
            this.pic_foto.Size = new System.Drawing.Size(100, 86);
            this.pic_foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_foto.TabIndex = 9;
            this.pic_foto.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PAPERBROS.Properties.Resources.image_removebg_preview__7_;
            this.pictureBox2.Location = new System.Drawing.Point(12, 203);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(321, 165);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // Opciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(345, 391);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pic_foto);
            this.Controls.Add(this.lbl_TipoAdmin);
            this.Controls.Add(this.cmb_Opciones);
            this.Controls.Add(this.btn_Seleccionar);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Opciones";
            this.Load += new System.EventHandler(this.Opciones_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_foto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Seleccionar;
        private System.Windows.Forms.ComboBox cmb_Opciones;
        private System.Windows.Forms.Label lbl_TipoAdmin;
        private System.Windows.Forms.PictureBox pic_foto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}