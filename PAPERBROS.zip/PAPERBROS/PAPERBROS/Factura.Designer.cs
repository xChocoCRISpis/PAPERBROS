﻿
namespace PAPERBROS
{
    partial class Factura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Factura));
            this.dgv_Detalles = new System.Windows.Forms.DataGridView();
            this.dgv_Factura = new System.Windows.Forms.DataGridView();
            this.txt_RFCCliente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_mas = new System.Windows.Forms.Button();
            this.btn_menos = new System.Windows.Forms.Button();
            this.txt_paga = new System.Windows.Forms.TextBox();
            this.lbl_PagadoCon = new System.Windows.Forms.Label();
            this.btn_terminar = new System.Windows.Forms.Button();
            this.lbl_Producto = new System.Windows.Forms.Label();
            this.chb_Descuento = new System.Windows.Forms.CheckBox();
            this.txt_Descuento = new System.Windows.Forms.TextBox();
            this.lbl_Cambio = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Factura = new System.Windows.Forms.TextBox();
            this.btn_Descuento = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_PuntosDisp = new System.Windows.Forms.Label();
            this.lbl_puntos = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pnl_Titulo = new System.Windows.Forms.Panel();
            this.pb_Chico = new System.Windows.Forms.PictureBox();
            this.pb_Min = new System.Windows.Forms.PictureBox();
            this.pb_Full = new System.Windows.Forms.PictureBox();
            this.pb_Exit = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Detalles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Factura)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnl_Titulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Chico)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Full)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Detalles
            // 
            this.dgv_Detalles.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Detalles.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Franklin Gothic Demi", 9.75F, System.Drawing.FontStyle.Italic);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(16)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Detalles.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_Detalles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Detalles.EnableHeadersVisualStyles = false;
            this.dgv_Detalles.GridColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Detalles.Location = new System.Drawing.Point(12, 229);
            this.dgv_Detalles.Name = "dgv_Detalles";
            this.dgv_Detalles.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial", 9.75F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(74)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Detalles.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_Detalles.Size = new System.Drawing.Size(481, 173);
            this.dgv_Detalles.TabIndex = 0;
            this.dgv_Detalles.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Detalles_CellClick);
            this.dgv_Detalles.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Detalles_CellDoubleClick);
            // 
            // dgv_Factura
            // 
            this.dgv_Factura.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Factura.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Franklin Gothic Demi", 9.75F, System.Drawing.FontStyle.Italic);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(16)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Factura.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgv_Factura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Factura.EnableHeadersVisualStyles = false;
            this.dgv_Factura.GridColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Factura.Location = new System.Drawing.Point(12, 412);
            this.dgv_Factura.Name = "dgv_Factura";
            this.dgv_Factura.RowHeadersVisible = false;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Arial", 9.75F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(74)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Factura.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgv_Factura.Size = new System.Drawing.Size(481, 101);
            this.dgv_Factura.TabIndex = 1;
            this.dgv_Factura.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Factura_CellContentClick);
            // 
            // txt_RFCCliente
            // 
            this.txt_RFCCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_RFCCliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_RFCCliente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_RFCCliente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_RFCCliente.Location = new System.Drawing.Point(6, 35);
            this.txt_RFCCliente.Name = "txt_RFCCliente";
            this.txt_RFCCliente.Size = new System.Drawing.Size(100, 20);
            this.txt_RFCCliente.TabIndex = 2;
            this.txt_RFCCliente.TextChanged += new System.EventHandler(this.txt_Factura_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(30, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "RFC cliente";
            // 
            // btn_mas
            // 
            this.btn_mas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_mas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mas.ForeColor = System.Drawing.Color.White;
            this.btn_mas.Location = new System.Drawing.Point(558, 259);
            this.btn_mas.Name = "btn_mas";
            this.btn_mas.Size = new System.Drawing.Size(44, 23);
            this.btn_mas.TabIndex = 4;
            this.btn_mas.Text = "+";
            this.btn_mas.UseVisualStyleBackColor = true;
            this.btn_mas.Click += new System.EventHandler(this.btn_mas_Click);
            // 
            // btn_menos
            // 
            this.btn_menos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_menos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_menos.ForeColor = System.Drawing.Color.White;
            this.btn_menos.Location = new System.Drawing.Point(558, 288);
            this.btn_menos.Name = "btn_menos";
            this.btn_menos.Size = new System.Drawing.Size(44, 23);
            this.btn_menos.TabIndex = 5;
            this.btn_menos.Text = "-";
            this.btn_menos.UseVisualStyleBackColor = true;
            this.btn_menos.Click += new System.EventHandler(this.btn_menos_Click);
            // 
            // txt_paga
            // 
            this.txt_paga.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_paga.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_paga.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_paga.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_paga.Location = new System.Drawing.Point(247, 35);
            this.txt_paga.Name = "txt_paga";
            this.txt_paga.Size = new System.Drawing.Size(100, 20);
            this.txt_paga.TabIndex = 6;
            this.txt_paga.TextChanged += new System.EventHandler(this.txt_paga_TextChanged);
            // 
            // lbl_PagadoCon
            // 
            this.lbl_PagadoCon.AutoSize = true;
            this.lbl_PagadoCon.BackColor = System.Drawing.Color.Transparent;
            this.lbl_PagadoCon.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PagadoCon.ForeColor = System.Drawing.Color.White;
            this.lbl_PagadoCon.Location = new System.Drawing.Point(266, 16);
            this.lbl_PagadoCon.Name = "lbl_PagadoCon";
            this.lbl_PagadoCon.Size = new System.Drawing.Size(65, 16);
            this.lbl_PagadoCon.TabIndex = 7;
            this.lbl_PagadoCon.Text = "Pagado con:";
            // 
            // btn_terminar
            // 
            this.btn_terminar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_terminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_terminar.Font = new System.Drawing.Font("Arial Narrow", 9.25F, System.Drawing.FontStyle.Bold);
            this.btn_terminar.ForeColor = System.Drawing.Color.White;
            this.btn_terminar.Location = new System.Drawing.Point(533, 339);
            this.btn_terminar.Name = "btn_terminar";
            this.btn_terminar.Size = new System.Drawing.Size(102, 23);
            this.btn_terminar.TabIndex = 8;
            this.btn_terminar.Text = "Terminar";
            this.btn_terminar.UseVisualStyleBackColor = true;
            this.btn_terminar.Click += new System.EventHandler(this.btn_terminar_Click);
            // 
            // lbl_Producto
            // 
            this.lbl_Producto.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Producto.AutoSize = true;
            this.lbl_Producto.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Producto.ForeColor = System.Drawing.Color.White;
            this.lbl_Producto.Location = new System.Drawing.Point(550, 158);
            this.lbl_Producto.Name = "lbl_Producto";
            this.lbl_Producto.Size = new System.Drawing.Size(50, 16);
            this.lbl_Producto.TabIndex = 9;
            this.lbl_Producto.Text = "Producto";
            // 
            // chb_Descuento
            // 
            this.chb_Descuento.AutoSize = true;
            this.chb_Descuento.BackColor = System.Drawing.Color.Transparent;
            this.chb_Descuento.Enabled = false;
            this.chb_Descuento.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chb_Descuento.ForeColor = System.Drawing.Color.White;
            this.chb_Descuento.Location = new System.Drawing.Point(127, 15);
            this.chb_Descuento.Name = "chb_Descuento";
            this.chb_Descuento.Size = new System.Drawing.Size(74, 20);
            this.chb_Descuento.TabIndex = 12;
            this.chb_Descuento.Text = "Descuento";
            this.chb_Descuento.UseVisualStyleBackColor = false;
            this.chb_Descuento.UseWaitCursor = true;
            this.chb_Descuento.Visible = false;
            this.chb_Descuento.CheckedChanged += new System.EventHandler(this.chb_Descuento_CheckedChanged_1);
            // 
            // txt_Descuento
            // 
            this.txt_Descuento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Descuento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Descuento.Enabled = false;
            this.txt_Descuento.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Descuento.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Descuento.Location = new System.Drawing.Point(118, 35);
            this.txt_Descuento.Name = "txt_Descuento";
            this.txt_Descuento.Size = new System.Drawing.Size(100, 20);
            this.txt_Descuento.TabIndex = 10;
            this.txt_Descuento.TextChanged += new System.EventHandler(this.txt_Descuento_TextChanged);
            // 
            // lbl_Cambio
            // 
            this.lbl_Cambio.AutoSize = true;
            this.lbl_Cambio.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cambio.ForeColor = System.Drawing.Color.White;
            this.lbl_Cambio.Location = new System.Drawing.Point(298, 87);
            this.lbl_Cambio.Name = "lbl_Cambio";
            this.lbl_Cambio.Size = new System.Drawing.Size(49, 16);
            this.lbl_Cambio.TabIndex = 13;
            this.lbl_Cambio.Text = "Cambio: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(389, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "N° de ticket";
            // 
            // txt_Factura
            // 
            this.txt_Factura.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Factura.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Factura.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Factura.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Factura.Location = new System.Drawing.Point(366, 35);
            this.txt_Factura.Name = "txt_Factura";
            this.txt_Factura.Size = new System.Drawing.Size(100, 20);
            this.txt_Factura.TabIndex = 14;
            this.txt_Factura.TextChanged += new System.EventHandler(this.txt_Factura_TextChanged_1);
            // 
            // btn_Descuento
            // 
            this.btn_Descuento.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Descuento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Descuento.Font = new System.Drawing.Font("Arial Narrow", 9.25F, System.Drawing.FontStyle.Bold);
            this.btn_Descuento.ForeColor = System.Drawing.Color.White;
            this.btn_Descuento.Location = new System.Drawing.Point(547, 121);
            this.btn_Descuento.Name = "btn_Descuento";
            this.btn_Descuento.Size = new System.Drawing.Size(75, 23);
            this.btn_Descuento.TabIndex = 16;
            this.btn_Descuento.Text = "Descontar";
            this.btn_Descuento.UseVisualStyleBackColor = true;
            this.btn_Descuento.Click += new System.EventHandler(this.btn_Descuento_Click);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(83, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(502, 33);
            this.label4.TabIndex = 17;
            this.label4.Text = "GESTIÓN DE VENTAS Y TICKETS";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.groupBox1.Controls.Add(this.lbl_PuntosDisp);
            this.groupBox1.Controls.Add(this.lbl_puntos);
            this.groupBox1.Controls.Add(this.lbl_Cambio);
            this.groupBox1.Controls.Add(this.txt_paga);
            this.groupBox1.Controls.Add(this.lbl_PagadoCon);
            this.groupBox1.Controls.Add(this.txt_Descuento);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.chb_Descuento);
            this.groupBox1.Controls.Add(this.txt_Factura);
            this.groupBox1.Controls.Add(this.txt_RFCCliente);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(481, 133);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lbl_PuntosDisp
            // 
            this.lbl_PuntosDisp.AutoSize = true;
            this.lbl_PuntosDisp.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PuntosDisp.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_PuntosDisp.Location = new System.Drawing.Point(156, 87);
            this.lbl_PuntosDisp.Name = "lbl_PuntosDisp";
            this.lbl_PuntosDisp.Size = new System.Drawing.Size(13, 16);
            this.lbl_PuntosDisp.TabIndex = 23;
            this.lbl_PuntosDisp.Text = "_";
            // 
            // lbl_puntos
            // 
            this.lbl_puntos.AutoSize = true;
            this.lbl_puntos.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_puntos.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_puntos.Location = new System.Drawing.Point(30, 87);
            this.lbl_puntos.Name = "lbl_puntos";
            this.lbl_puntos.Size = new System.Drawing.Size(114, 16);
            this.lbl_puntos.TabIndex = 22;
            this.lbl_puntos.Text = "Puntos disponibles:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(603, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(72, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(5, 39);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(72, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // pnl_Titulo
            // 
            this.pnl_Titulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.pnl_Titulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Titulo.Controls.Add(this.pb_Chico);
            this.pnl_Titulo.Controls.Add(this.pb_Min);
            this.pnl_Titulo.Controls.Add(this.pb_Full);
            this.pnl_Titulo.Controls.Add(this.pb_Exit);
            this.pnl_Titulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Titulo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnl_Titulo.Location = new System.Drawing.Point(0, 0);
            this.pnl_Titulo.Name = "pnl_Titulo";
            this.pnl_Titulo.Size = new System.Drawing.Size(675, 34);
            this.pnl_Titulo.TabIndex = 21;
            this.pnl_Titulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnl_Titulo_MouseDown);
            // 
            // pb_Chico
            // 
            this.pb_Chico.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Chico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Chico.Enabled = false;
            this.pb_Chico.Image = ((System.Drawing.Image)(resources.GetObject("pb_Chico.Image")));
            this.pb_Chico.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Chico.InitialImage")));
            this.pb_Chico.Location = new System.Drawing.Point(592, -1);
            this.pb_Chico.Name = "pb_Chico";
            this.pb_Chico.Size = new System.Drawing.Size(29, 30);
            this.pb_Chico.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Chico.TabIndex = 3;
            this.pb_Chico.TabStop = false;
            this.pb_Chico.Visible = false;
            this.pb_Chico.Click += new System.EventHandler(this.pb_Chico_Click);
            // 
            // pb_Min
            // 
            this.pb_Min.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Min.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Min.Image = ((System.Drawing.Image)(resources.GetObject("pb_Min.Image")));
            this.pb_Min.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Min.InitialImage")));
            this.pb_Min.Location = new System.Drawing.Point(552, 0);
            this.pb_Min.Name = "pb_Min";
            this.pb_Min.Size = new System.Drawing.Size(29, 30);
            this.pb_Min.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Min.TabIndex = 2;
            this.pb_Min.TabStop = false;
            this.pb_Min.Click += new System.EventHandler(this.pb_Min_Click);
            // 
            // pb_Full
            // 
            this.pb_Full.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Full.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Full.Image = ((System.Drawing.Image)(resources.GetObject("pb_Full.Image")));
            this.pb_Full.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Full.InitialImage")));
            this.pb_Full.Location = new System.Drawing.Point(592, 0);
            this.pb_Full.Name = "pb_Full";
            this.pb_Full.Size = new System.Drawing.Size(29, 30);
            this.pb_Full.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Full.TabIndex = 1;
            this.pb_Full.TabStop = false;
            this.pb_Full.Click += new System.EventHandler(this.pb_Full_Click);
            // 
            // pb_Exit
            // 
            this.pb_Exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pb_Exit.Image")));
            this.pb_Exit.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Exit.InitialImage")));
            this.pb_Exit.Location = new System.Drawing.Point(632, -1);
            this.pb_Exit.Name = "pb_Exit";
            this.pb_Exit.Size = new System.Drawing.Size(29, 30);
            this.pb_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Exit.TabIndex = 0;
            this.pb_Exit.TabStop = false;
            this.pb_Exit.Click += new System.EventHandler(this.pb_Exit_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.SlateBlue;
            this.panel2.Location = new System.Drawing.Point(2, 82);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(673, 5);
            this.panel2.TabIndex = 2;
            // 
            // Factura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(675, 530);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnl_Titulo);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_Descuento);
            this.Controls.Add(this.lbl_Producto);
            this.Controls.Add(this.btn_terminar);
            this.Controls.Add(this.btn_menos);
            this.Controls.Add(this.btn_mas);
            this.Controls.Add(this.dgv_Factura);
            this.Controls.Add(this.dgv_Detalles);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Factura";
            this.Load += new System.EventHandler(this.Factura_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Detalles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Factura)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnl_Titulo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Chico)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Full)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Detalles;
        private System.Windows.Forms.DataGridView dgv_Factura;
        private System.Windows.Forms.TextBox txt_RFCCliente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_mas;
        private System.Windows.Forms.Button btn_menos;
        private System.Windows.Forms.TextBox txt_paga;
        private System.Windows.Forms.Label lbl_PagadoCon;
        private System.Windows.Forms.Button btn_terminar;
        private System.Windows.Forms.Label lbl_Producto;
        private System.Windows.Forms.CheckBox chb_Descuento;
        private System.Windows.Forms.TextBox txt_Descuento;
        private System.Windows.Forms.Label lbl_Cambio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Factura;
        private System.Windows.Forms.Button btn_Descuento;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel pnl_Titulo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pb_Chico;
        private System.Windows.Forms.PictureBox pb_Min;
        private System.Windows.Forms.PictureBox pb_Full;
        private System.Windows.Forms.PictureBox pb_Exit;
        private System.Windows.Forms.Label lbl_PuntosDisp;
        private System.Windows.Forms.Label lbl_puntos;
    }
}