﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PAPERBROS
{
    public partial class AgregarProducto : Form
    {
        string TipoAdmin;
        string foto;
        public AgregarProducto(string TipoAdmin,string imagen)
        {
            InitializeComponent();
            this.TipoAdmin = TipoAdmin;
            foto = imagen;
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Opciones Opciones = new Opciones(TipoAdmin,foto);
            Opciones.Show();
        }

        private void btn_Agregar_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();
            if (con != null)
            {
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sp_AgregarProducto";
                com.Parameters.Clear();

                try
                {
                    // pase de parámetroS
                    com.Parameters.Add("@NOMBRE", SqlDbType.VarChar, 70).Value = txt_Nombre.Text;
                    if (rdbtn_No.Checked == true)
                        com.Parameters.Add("@DISPONIBILIDAD", SqlDbType.Int).Value = -1;
                    else
                        com.Parameters.Add("@DISPONIBILIDAD", SqlDbType.Int).Value = txt_Disp.Text;
                    com.Parameters.Add("@PRECIO", SqlDbType.Money).Value = txt_Precio.Text;

                    int a = com.ExecuteNonQuery();

                    if (a > 0)
                    {
                        MessageBox.Show("Producto dado de alta exitosamente");
                        txt_Nombre.Text = null;
                        txt_Disp.Text = null;
                        txt_Precio.Text = null;

                    }
                    else
                    {
                        MessageBox.Show("El producto ya existe en la base de datos");
                    }



                }
                catch (Exception)
                {
                    MessageBox.Show("Valores inválidos");
                    txt_Disp.Text = null;
                    txt_Precio.Text = null;
                }
            }
        }

        private void rdbtn_Si_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Si.Checked == true)
                txt_Disp.Enabled = true;
        }

        private void rdbtn_No_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_No.Checked == true)
                txt_Disp.Enabled = false;
        }

        private void txt_Precio_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
