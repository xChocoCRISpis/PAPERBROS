﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PAPERBROS
{
    public partial class Bitacora : Form
    {
        public Bitacora()
        {
            InitializeComponent();
        }

        private void Bitacora_Load(object sender, EventArgs e)
        {
            CargarBitacora();
            lbl_Fecha0.Text= mc_Fecha0.SelectionRange.Start.ToString("yyyy-MM-dd");
            lbl_Fecha1.Text = mc_Fecha1.SelectionRange.End.ToString("yyyy-MM-dd");
            FechaBitacora();
        }

  

        private void btn_Nombre_Click(object sender, EventArgs e)
        {
            NombreBitacora();
        }

        private void btn_tabla_Click(object sender, EventArgs e)
        {
            TablaBitacora();
        }

        private void NombreBitacora()
        {
            SqlConnection con = Conexion.CadenaConexion();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = new SqlCommand("sp_viewNombreBitacora", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();

                SqlParameter param = new SqlParameter("@Nombre", SqlDbType.VarChar, 50);
                param.Value = txt_NomResp.Text;
                da.SelectCommand.Parameters.Add(param);

                da.Fill(dt);
                dgv_Bitacora.DataSource = dt;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void TablaBitacora()
        {
            SqlConnection con = Conexion.CadenaConexion();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = new SqlCommand("sp_ViewTablas", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();

                SqlParameter param = new SqlParameter("@Tabla", SqlDbType.VarChar, 50);
                param.Value = txt_Tabla.Text;
                da.SelectCommand.Parameters.Add(param);

                da.Fill(dt);
                dgv_Bitacora.DataSource = dt;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void CargarBitacora()
        {
            SqlConnection connection = Conexion.CadenaConexion();
            if (connection != null)
            {

                SqlDataAdapter da_Carga = new SqlDataAdapter("SELECT*FROM v_CargarBitacora", connection);
                DataSet ds_Carga = new DataSet();
                da_Carga.Fill(ds_Carga, "v_CargarBitacora");
                dgv_Bitacora.DataSource = ds_Carga;
                dgv_Bitacora.DataMember = "v_CargarBitacora";
                connection.Close();
            }
        }
        private void FechaBitacora()
        {
            SqlConnection con = Conexion.CadenaConexion();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = new SqlCommand("sp_ViewFecha", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataTable dt = new DataTable();

                SqlParameter param0 = new SqlParameter("@Inicio", SqlDbType.Date);
                param0.Value = lbl_Fecha0.Text;
                da.SelectCommand.Parameters.Add(param0);

                SqlParameter param1 = new SqlParameter("@Fin", SqlDbType.Date);
                param1.Value = lbl_Fecha1.Text;
                da.SelectCommand.Parameters.Add(param1);

                da.Fill(dt);
                dgv_Bitacora.DataSource = dt;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void mc_Fecha0_DateChanged(object sender, DateRangeEventArgs e)
        {
            lbl_Fecha0.Text = mc_Fecha0.SelectionRange.Start.ToString("yyyy-MM-dd");
            FechaBitacora();
        }

        private void mc_Fecha1_DateChanged(object sender, DateRangeEventArgs e)
        {
            lbl_Fecha1.Text = mc_Fecha1.SelectionRange.End.ToString("yyyy-MM-dd");
            FechaBitacora();
        }
    }
}
