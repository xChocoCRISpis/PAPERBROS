﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;
using System.Web;

namespace PAPERBROS
{
    public partial class SuperAdministrador : Form
    {
        string mostrar;
        bool contrato;
        int id;
        string nombre;
        string paterno;
        string materno;
        string rfc;
        int tipo;
        string log;
        string contra;
        string imagen;
        bool cambiarfoto = false;
        string ruta;
        string path;
        string nombre_tabla;
        public SuperAdministrador()
        {
            InitializeComponent();
            dgv_info_set();
        }

        private void SuperAdministrador_Load(object sender, EventArgs e)
        {

        }

        private void txt_Buscar_TextChanged(object sender, EventArgs e)
        {
            if (txt_Buscar.Text != null && txt_Buscar.Text != "")
            {
                dgv_info.Visible = true;
                dgv_info.Enabled = true;
                dgv_info_buscar();
            }
                
        }

        private void dgv_info_set()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT ADMINISTRADOR.Contratado,Id_ADMINISTRADOR AS 'ID Admin', NOMBRE, ApPaterno, ApMaterno, RFC,Id_TIPOS_ADMIN_FK AS 'Tipo', NombreLog, Contrasena, Imagen  FROM ADMINISTRADOR " +
                      "INNER JOIN LOGINS ON LOGINS.Id_ADMINISTRADOR_FK = Id_ADMINISTRADOR";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_info.ReadOnly = true;
            dgv_info.DataSource = ds.Tables[0];
        }

        private void dgv_info_buscar()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT ADMINISTRADOR.Contratado,Id_ADMINISTRADOR AS 'ID Admin', NOMBRE, ApPaterno, ApMaterno, RFC,Id_TIPOS_ADMIN_FK AS 'Tipo', NombreLog, Contrasena, Imagen  FROM ADMINISTRADOR " +
                      "INNER JOIN LOGINS ON LOGINS.Id_ADMINISTRADOR_FK = Id_ADMINISTRADOR WHERE RFC LIKE '%" + txt_Buscar.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_info.ReadOnly = true;
            dgv_info.DataSource = ds.Tables[0];
        }

        private void dgv_info_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = (DataGridViewRow)dgv_info.Rows[e.RowIndex];
                contrato = bool.Parse(Convert.ToString(row.Cells[0].Value));
                id = int.Parse(Convert.ToString(row.Cells[1].Value));
                nombre = Convert.ToString(row.Cells[2].Value);
                paterno = Convert.ToString(row.Cells[3].Value);
                materno = Convert.ToString(row.Cells[4].Value);
                rfc= Convert.ToString(row.Cells[5].Value);
                tipo= int.Parse(Convert.ToString(row.Cells[6].Value));
                log = Convert.ToString(row.Cells[7].Value);
                contra= Convert.ToString(row.Cells[8].Value);
                imagen= Convert.ToString(row.Cells[9].Value);

                txt_Contratado.Text = Convert.ToString(contrato);
                txt_Admin.Text= Convert.ToString(id);
                txt_Nombre.Text=Convert.ToString(nombre);
                txt_Paterno.Text= Convert.ToString(paterno);
                txt_Materno.Text= Convert.ToString(materno);
                txt_RFC.Text = Convert.ToString(rfc);
                txt_Tipo.Text= Convert.ToString(tipo);
                txt_Login.Text= Convert.ToString(log);
                txt_Contra.Text = Convert.ToString(contra);
                Console.WriteLine(imagen);
                pic_Foto.Image = Image.FromFile(Application.StartupPath + "\\Admins"+imagen);

            }
            catch (Exception a)
            {
                Console.WriteLine(a);
            }
        }

        private void ch_modificar_CheckedChanged(object sender, EventArgs e)
        {
            bool c = true;
            bool a = false;
            if (ch_modificar.Checked == true)
            {
                c = false;
                a = true;
                
            }

            txt_Nombre.ReadOnly = c;
            txt_Paterno.ReadOnly = c;
            txt_Materno.ReadOnly = c;
            txt_RFC.ReadOnly = c;
            txt_Login.ReadOnly = c;
            txt_Contra.ReadOnly = c;

            btn_Modificar.Enabled = a;
            pic_Foto.Enabled = a;
            ch_cajero.Enabled = a;
            ch_gerente.Enabled = a;
            ch_sa.Enabled = a;
            ch_NO.Enabled = a;
            ch_Si.Enabled = a;

        }

        private void pic_Foto_Click(object sender, EventArgs e)
        {
            if (ofd_FotoAdmin.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    string path = "\\Admins\\" + rfc + ".jpg";


                    ruta = ofd_FotoAdmin.FileName;
                    pic_Foto.Image = Image.FromFile(ruta);
                    pic_Foto.Image.Save(Application.StartupPath + "\\Admins\\" + rfc + ".jpg", ImageFormat.Jpeg);
                    this.ruta = ofd_FotoAdmin.FileName;
                    cambiarfoto = true;
                    Console.WriteLine(path);

                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);

                    MessageBox.Show("Formato de imagen incorrecto, solo se acepta JPGE");
                }
            }
        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {

            SqlConnection con = Conexion.CadenaConexion();

            DialogResult dialogo = MessageBox.Show("¿Seguro que desea modificar a el administrador, los cambios serán permanetes?",
            "Modificar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogo == DialogResult.Yes)
                if (con != null)
                {
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;

                    com.CommandText = "sp_SuperAdmin";
                    com.Parameters.Clear();

                    ruta = Application.StartupPath + @"\Admins\" + rfc+".jpg";
                    path = Path.GetFileName(ruta);

                    com.Parameters.Add("@CONTRATO", SqlDbType.Bit).Value = contrato;
                    com.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                    com.Parameters.Add("@NOMBRE", SqlDbType.VarChar, 50).Value = nombre;
                    com.Parameters.Add("@PATERNO", SqlDbType.VarChar, 50).Value = paterno;
                    com.Parameters.Add("@MATERNO", SqlDbType.VarChar, 50).Value = materno;
                    com.Parameters.Add("@RFC", SqlDbType.VarChar, 15).Value = rfc;
                    com.Parameters.Add("@TIPO", SqlDbType.Int).Value = tipo;
                    com.Parameters.Add("@LOG", SqlDbType.VarChar, 50).Value = log;
                    com.Parameters.Add("@CONTRA", SqlDbType.VarChar, 50).Value = contra;

                    com.Parameters.Add("@IMG", SqlDbType.VarChar).Value = "\\" + path;

                    int a = com.ExecuteNonQuery();
                    con.Close();
                    if (a <= 0)
                    {
                        MessageBox.Show("No se pudo realizar la modificacion");
                    }
                }
                else 
                {
                    MessageBox.Show("No hay conexión  ala base de datos");
                }
        }

        private void ch_Si_CheckedChanged(object sender, EventArgs e)
        {
            if (ch_Si.Checked == true) 
            {
                ch_NO.Checked = false;
                contrato = true;
                txt_Contratado.Text = "true";
            }
        }

        private void ch_NO_CheckedChanged(object sender, EventArgs e)
        {
            if (ch_NO.Checked == true)
            {
                ch_Si.Checked = false;
                contrato = false;
                txt_Contratado.Text = "false";
            }
        }

        private void ch_sa_CheckedChanged(object sender, EventArgs e)
        {
            if (ch_sa.Checked == true)
            {
                ch_gerente.Checked = false;
                ch_cajero.Checked = false;
                txt_Tipo.Text = "1";
                tipo = 1;
            }
        }

        private void ch_gerente_CheckedChanged(object sender, EventArgs e)
        {
            if (ch_gerente.Checked == true)
            {
                ch_sa.Checked = false;
                ch_cajero.Checked = false;
                txt_Tipo.Text = "2";
                tipo = 2;
            }
        }


        private void ch_cajero_CheckedChanged(object sender, EventArgs e)
        {
            if (ch_cajero.Checked == true)
            {
                ch_sa.Checked = false;
                ch_gerente.Checked = false;
                txt_Tipo.Text = "3";
                tipo = 3;
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btn_BackupDif_Click(object sender, EventArgs e)
        {
            DialogResult dialogo = MessageBox.Show("¿Seguro que desea modificar crear un Backup parcial?, Esto podría tomar un tiempo",
            "Crear copia parcial", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogo == DialogResult.Yes)
            {
                SqlConnection con = Conexion.CadenaConexion();
                if (con != null)
                {
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_BackUpDifferential";
                    com.Parameters.Clear();
                    com.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Copia de seguridad parcial creada");
                }
                else
                {
                    MessageBox.Show("Conexión a la base de datos fallida");
                }
            }
            else
            {
                MessageBox.Show("No se realizo la copia");
            }
               
        }

        private void btn_BackupCom_Click(object sender, EventArgs e)
        {
            DialogResult dialogo = MessageBox.Show("¿Seguro que desea modificar crear un Backup completa?, Esto podría tomar un tiempo",
            "Crear copia completa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogo == DialogResult.Yes)
            {
                SqlConnection con = Conexion.CadenaConexion();
                if (con != null)
                {
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_BackUpFull";
                    com.Parameters.Clear();
                    com.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Copia de seguridad completa creada");
                }
                else
                {
                    MessageBox.Show("Conexión a la base de datos fallida");
                }
            }
            else
            {
                MessageBox.Show("No se realizo la copia");
            }
        }

        private void dgv_info_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_OpenCopyTable_Click(object sender, EventArgs e)
        {
            pnl_CopiaTablas.Visible = true;
            btn_OpenCopyTable.Visible = false;
            pnl_CopiaTablas.Dock= DockStyle.Fill;
        }

        private void btn_CerrarCopiaTabla_Click(object sender, EventArgs e)
        {
            pnl_CopiaTablas.Visible=false;
            btn_OpenCopyTable.Visible = true;
            pnl_CopiaTablas.Dock = DockStyle.None;

        }

        private void btn_CopiarTabla_Click(object sender, EventArgs e)
        {
            DialogResult dialogo = MessageBox.Show("¿Seguro que desea copiar la tabla "+nombre_tabla+"?, Esto podría tomar un tiempo",
            "Copiar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogo == DialogResult.Yes)
            {
                SqlConnection con = Conexion.CadenaConexion();
                if (con != null)
                {
                    try
                    {
                        SqlCommand com = new SqlCommand();
                        com.Connection = con;
                        com.CommandType = CommandType.StoredProcedure;
                        com.CommandText = "sp_CopiaTabla";
                        com.Parameters.Clear();

                        com.Parameters.Add("@TABLA", SqlDbType.VarChar, 50).Value = nombre_tabla;

                        com.Parameters.Add("@EXIST", SqlDbType.Bit).Value = 0;
                        com.Parameters["@EXIST"].Direction = ParameterDirection.Output;

                        com.ExecuteNonQuery();
                        con.Close();

                        bool status = bool.Parse(com.Parameters["@EXIST"].Value.ToString());
                        if (status==true) 
                            MessageBox.Show("Tabla copiada exitosamente");
                        else
                            MessageBox.Show("La tabla no existe en la base de datos");

                    }
                    catch(Exception Ex)
                    {
                        Console.WriteLine(Ex);
                    }
                }
                else
                {
                    MessageBox.Show("Conexión a la base de datos fallida");
                }
            }
            else
            {
                MessageBox.Show("No se realizo la copia");
            }

        }


        private void rdbtn_Administrador_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Administrador.Checked == true)
            {
                nombre_tabla = "ADMINISTRADOR";
                btn_CopiarTabla.Enabled = true;
            }
        }

        private void rdbtn_Detalle_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Detalle.Checked == true)
            {
                nombre_tabla = "DETALLE";
                btn_CopiarTabla.Enabled = true;
            }

        }

        private void rdbtn_Bitacora_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Bitacora.Checked == true)
            {
                nombre_tabla = "BITACORA";
                btn_CopiarTabla.Enabled = true;
            }

        }

        private void rdbtn_Descuento_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Descuento.Checked == true)
            {
                btn_CopiarTabla.Enabled = true;
                nombre_tabla = "DESCUENTO";
            }
            
        }

        private void rdbtn_Ticket_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Ticket.Checked == true)
            {
                btn_CopiarTabla.Enabled = true;
                nombre_tabla = "FACTURA";
            }
           
        }

        private void rdbtn_Logins_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Logins.Checked == true)
            {
                btn_CopiarTabla.Enabled = true;
                nombre_tabla = "LOGINS";
            }
           
        }

        private void rdbtn_Producto_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Producto.Checked == true)
            {
                btn_CopiarTabla.Enabled = true;
                nombre_tabla = "PRODUCTO";
            }
           
        }

        private void rdbtn_TiposAdmin_CheckedChanged(object sender, EventArgs e)
        {
              if (rdbtn_TiposAdmin.Checked == true)
              {
                btn_CopiarTabla.Enabled = true;
                nombre_tabla = "TIPOS_ADMIN";
              }
        }
           

        private void rdbtn_Usuario_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Usuario.Checked == true)
            {
                btn_CopiarTabla.Enabled = true;
                nombre_tabla = "USUARIO";
            }

        }
    }
    
}
