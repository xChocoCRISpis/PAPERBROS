﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using AForge.Video;
using AForge.Video.DirectShow;
using ZXing.QrCode;
using ZXing;
using static System.Net.Mime.MediaTypeNames;
using ZXing.Common;
using System.Media;

namespace PAPERBROS
{
    public partial class form_inicio : Form
    {
        int TipoAdmin;
        string foto;
        string RFC;
        string Usuario;
        Menu menu;

        //Captura video
        private FilterInfoCollection CaptureDevice;
        private VideoCaptureDevice FinalFrame;

        public form_inicio()
        {
            InitializeComponent();
            pictureBox1.SendToBack();
        }

       
        //GUI
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int IParam);
        private void btn_Ingresar_Click(object sender, EventArgs e)
        {

            SqlConnection con = Conexion.CadenaConexion();

            if (con != null)
            {
                try
                {
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_Logueo";// nombre del Proc Alm
                    com.Parameters.Add("@NOMBRE_LOG", SqlDbType.VarChar, 50).Value = txt_Usuario.Text;
                    com.Parameters.Add("@CONTRASENA", SqlDbType.VarChar, 50).Value = txt_Contra.Text;

                    com.Parameters.Add("@TipoU", SqlDbType.Int).Value = -1;
                    com.Parameters["@TipoU"].Direction = ParameterDirection.Output;

                    com.Parameters.Add("@Status", SqlDbType.Bit).Value = 0;
                    com.Parameters["@Status"].Direction = ParameterDirection.Output;

                    com.Parameters.Add("@Foto", SqlDbType.VarChar, -1).Value = "asdadfgfjghdfjkghsgjklhsdfjkghdfjgh";
                    com.Parameters["@Foto"].Direction = ParameterDirection.Output;

                    com.Parameters.Add("@RFC", SqlDbType.VarChar, 15).Value = "";
                    com.Parameters["@RFC"].Direction= ParameterDirection.Output;

                    com.Parameters.Add("@CONTRATADO", SqlDbType.Bit).Value = 0;
                    com.Parameters["@CONTRATADO"].Direction = ParameterDirection.Output;

                    com.ExecuteNonQuery();
                    con.Close();

                    Console.WriteLine("status: "+com.Parameters["@Status"].Value.ToString());
                    bool status = bool.Parse(com.Parameters["@Status"].Value.ToString());
                    bool contratado = bool.Parse(com.Parameters["@CONTRATADO"].Value.ToString());


                    if (status == true && contratado == true) 
                    {
                        TipoAdmin = Convert.ToInt32(com.Parameters["@TipoU"].Value.ToString());
                        foto = (com.Parameters["@Foto"].Value.ToString());
                        pic_foto.Image = System.Drawing.Image.FromFile(System.Windows.Forms.Application.StartupPath + "\\Admins" + foto);
                        string rfc = com.Parameters["@RFC"].Value.ToString();
                        Console.WriteLine("Contratado: " + contratado);
                        this.RFC= rfc;
                        this.Usuario = txt_Usuario.Text;

                    }
                    

                    if (TipoAdmin != -1 && status == true)
                    {
                        if (contratado == true)
                        {
                            btn_Ingresar.Enabled = false;
                            btn_CerrarSesion.Enabled = true;
                            btn_Opciones.Enabled = true;
                            txt_Contra.Enabled = false;
                            txt_Usuario.Enabled = false;
                            MessageBox.Show("Bienvenido " + txt_Usuario.Text);
                            lbl_TipoAdmin.Text = Convert.ToString(TipoAdmin);

                            // Crear una instancia de SoundPlayer con el archivo de audio
                            btn_OpenQR.Enabled = false;
                            SoundPlayer player = new SoundPlayer();
                            player.SoundLocation= @"Audio\Inicio.wav";
                            player.Play();
                            player.Dispose();
                        }
                        else
                        {
                            MessageBox.Show("Persona no contratada");
                        }
                        
                    }
                    else
                    {
                        txt_Contra.Text = null;
                        txt_Usuario.Text = null;
                        MessageBox.Show("Usuario o Contraseña incorrectos");
                    }
                }
                catch (Exception a)
                {
                    Console.WriteLine(a);
                }


            }
            else
            {
                MessageBox.Show("Sin conexion a la base de datos");
            }
        
        }

       
        private void btn_Opciones_Click(object sender, EventArgs e)
        {
            menu=new Menu(Convert.ToString(TipoAdmin), foto,RFC,Usuario);
            menu.Show(); 
        }
            

        private void btn_CerrarSesion_Click(object sender, EventArgs e)
        {
            SoundPlayer player = new SoundPlayer();
            player.SoundLocation = @"Audio\Final.wav";
            player.Play();
            player.Dispose();
            FinalFrame.Stop();
            string TipoAdmin = Convert.ToString(this.TipoAdmin);
            txt_Contra.Text = null;
            txt_Usuario.Text = null;
            btn_Opciones.Enabled = false;
            btn_CerrarSesion.Enabled = false;
            btn_Ingresar.Enabled = true;
            txt_Contra.Enabled = true;
            txt_Usuario.Enabled = true;
            pic_foto.Image = null;
            btn_OpenQR.Enabled = true;
            if(menu!=null)
            menu.Close();
            //Cerrar todas la clases de FORMS
        }

        //Parte de la GUI
        private void pb_Exit_Click(object sender, EventArgs e)
        {
            btn_login.Enabled = false;
            FinalFrame.Stop();
            System.Windows.Forms.Application.Exit();
        }

        private void pb_Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void txt_QR_Click(object sender, EventArgs e)
        {
            btn_login.Enabled = true;
            FinalFrame.Stop();
            FinalFrame = new VideoCaptureDevice(CaptureDevice[cmb_Camara.SelectedIndex].MonikerString);
            FinalFrame.NewFrame += new NewFrameEventHandler(FinalFrame_NewFrame);
            FinalFrame.Start();

        }

        private void form_inicio_Load(object sender, EventArgs e)
        {
            CaptureDevice = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo Device in CaptureDevice)
            {
                cmb_Camara.Items.Add(Device.Name);
            }

            cmb_Camara.SelectedIndex = 0;
            FinalFrame = new VideoCaptureDevice();
        }

        private void FinalFrame_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pb_QR.Image = (Bitmap)eventArgs.Frame.Clone();
        }

        private void time_QR_Tick(object sender, EventArgs e)
        {
            //QR tick

            Bitmap cameraImage = (Bitmap)pb_QR.Image;

            // Configurar opciones para el lector de códigos de barras
            var barcodeReader = new BarcodeReader
            {
                AutoRotate = true, // Permitir rotación automática de la imagen
                Options = new DecodingOptions
                {
                    TryHarder = true // Intentar más veces para leer el código QR
                }
            };

            // Leer el código QR desde la imagen
            Result result = barcodeReader.Decode(cameraImage);

            //Consulta base de datos
            SqlConnection con = Conexion.CadenaConexion();
            if (con != null)
            {
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.Text;
                    if (result != null)
                    {
                        // Se encontró un código QR, puedes acceder a su contenido a través de result.Text
                        string decoded = result.Text;
                        time_QR.Stop();
                        cmd.CommandText = "sp_qr";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@QR", SqlDbType.VarChar, -1).Value = decoded;


                        cmd.Parameters.Add("@SALIDA", SqlDbType.VarChar, -1).Value = decoded;
                        cmd.Parameters["@SALIDA"].Direction = ParameterDirection.Output;

                        cmd.ExecuteNonQuery();

                        string qr_info = cmd.Parameters["@SALIDA"].Value.ToString();

                        cmd.Parameters.Clear();

                        if (decoded == qr_info && qr_info!= "NO_VALIDO")
                        {

                            SqlCommand QR_log = new SqlCommand();
                            QR_log.Connection = con;
                            QR_log.CommandType = CommandType.Text;
                            QR_log.CommandText = "sp_QR_Logueo";
                            QR_log.CommandType = CommandType.StoredProcedure;

                            QR_log.Parameters.Add("@QR", SqlDbType.VarChar, -1).Value = decoded;

                            QR_log.Parameters.Add("@NOMBRE_LOG", SqlDbType.VarChar, 50).Value = " ";
                            QR_log.Parameters["@NOMBRE_LOG"].Direction = ParameterDirection.Output;

                            QR_log.Parameters.Add("@CONTRASENA", SqlDbType.VarChar, 50).Value = " ";
                            QR_log.Parameters["@CONTRASENA"].Direction = ParameterDirection.Output;
                            QR_log.ExecuteNonQuery();

                            string usuario = QR_log.Parameters["@NOMBRE_LOG"].Value.ToString();
                            string password = QR_log.Parameters["@CONTRASENA"].Value.ToString();

                            txt_Usuario.Text = usuario;

                            SqlCommand com = new SqlCommand();
                            com.Connection = con;
                            com.CommandType = CommandType.StoredProcedure;
                            com.CommandText = "sp_Logueo";// nombre del Proc Alm
                            com.Parameters.Add("@NOMBRE_LOG", SqlDbType.VarChar, 50).Value = usuario;
                            com.Parameters.Add("@CONTRASENA", SqlDbType.VarChar, 50).Value = password;

                            com.Parameters.Add("@TipoU", SqlDbType.Int).Value = -1;
                            com.Parameters["@TipoU"].Direction = ParameterDirection.Output;

                            com.Parameters.Add("@Status", SqlDbType.Bit).Value = 0;
                            com.Parameters["@Status"].Direction = ParameterDirection.Output;

                            com.Parameters.Add("@Foto", SqlDbType.VarChar, -1).Value = "asdadfgfjghdfjkghsgjklhsdfjkghdfjgh";
                            com.Parameters["@Foto"].Direction = ParameterDirection.Output;

                            com.Parameters.Add("@RFC", SqlDbType.VarChar, 15).Value = "";
                            com.Parameters["@RFC"].Direction = ParameterDirection.Output;

                            com.Parameters.Add("@CONTRATADO", SqlDbType.Bit).Value = 0;
                            com.Parameters["@CONTRATADO"].Direction = ParameterDirection.Output;

                            com.ExecuteNonQuery();
                            con.Close();

                            Console.WriteLine("status: " + com.Parameters["@Status"].Value.ToString());
                            bool status = bool.Parse(com.Parameters["@Status"].Value.ToString());
                            bool contratado = bool.Parse(com.Parameters["@CONTRATADO"].Value.ToString());

                            FinalFrame.Stop();
                            pnl_QR.Visible = false;
                            btn_OpenQR.Visible = true;


                            if (status == true && contratado == true)
                            {
                                TipoAdmin = Convert.ToInt32(com.Parameters["@TipoU"].Value.ToString());
                                foto = (com.Parameters["@Foto"].Value.ToString());
                                pic_foto.Image = System.Drawing.Image.FromFile(System.Windows.Forms.Application.StartupPath + "\\Admins" + foto);
                                string rfc = com.Parameters["@RFC"].Value.ToString();
                                Console.WriteLine("Contratado: " + contratado);
                                this.RFC = rfc;
                                this.Usuario = txt_Usuario.Text;

                            }


                            if (TipoAdmin != -1 && status == true)
                            {
                                if (contratado == true)
                                {
                                    btn_Ingresar.Enabled = false;
                                    btn_CerrarSesion.Enabled = true;
                                    btn_Opciones.Enabled = true;
                                    txt_Contra.Enabled = false;
                                    txt_Usuario.Enabled = false;
                                    SoundPlayer player = new SoundPlayer();
                                    player.SoundLocation = @"Audio\Inicio.wav";
                                    player.Play();
                                    player.Dispose();
                                    MessageBox.Show("Bienvenido " + txt_Usuario.Text);
                                    lbl_TipoAdmin.Text = Convert.ToString(TipoAdmin);
                                    btn_OpenQR.Enabled = false;
                                }
                                else
                                {
                                    MessageBox.Show("Persona no contratada");
                                }

                            }
                            else
                            {
                                txt_Contra.Text = null;
                                txt_Usuario.Text = null;
                                MessageBox.Show("Usuario o Contraseña incorrectos");
                            }
                        }
                        else
                        {
                            pnl_QR.Visible = false;
                            btn_OpenQR.Visible = true;
                            FinalFrame.Stop();

                            MessageBox.Show("Usuario no registrado");
                        }
                    }

                }
                catch (Exception a)
                {
                    Console.WriteLine(a);
                }
            }
            else
            {
                MessageBox.Show("Sin conexion a la base de datos");
            }

            /*
            try
            {
                string decoded = result.ToString().Trim();

                com.CommandText = "SELECT QR_info FROM LOGINS WHERE  QR_info='" + decoded + "'";
                com.ExecuteNonQuery();


                string qr_info = com.ExecuteReader().GetString(0);
                MessageBox.Show(qr_info + "antes");
                com.Parameters.Clear();

                if (decoded == qr_info)
                {
                    MessageBox.Show(qr_info);
                    time_QR.Stop();


                }
            }
            catch { }
            */

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            time_QR.Enabled = true;
            time_QR.Start();
        }

        private void btn_OpenQR_Click(object sender, EventArgs e)
        {
            btn_login.Enabled = false;
            pnl_QR.Visible = true;
            btn_OpenQR.Visible= false;

        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            pnl_QR.Visible = false;
            btn_OpenQR.Visible = true;
            FinalFrame.Stop();
        }
    }
}
