﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.IO;
using System.Drawing.Imaging;

namespace PAPERBROS
{
    public partial class Usuarios : Form
    {
        string mostrar;
        int seleccion;
        bool contrato;
        int id;
        string nombre;
        string paterno;
        string materno;
        string rfc;
        int tipo;
        string imagen;
        bool cambiarfoto = false;
        string ruta;
        string path;

        int id_cliente;
        string paterno_cliente;
        string materno_cliente;
        string nombre_cliente;
        int nivel;
        string rfc_cliente;
        int puntos;
        public Usuarios()
        {
            InitializeComponent();
        }

        private void txt_Buscar_TextChanged(object sender, EventArgs e)
        {
            if (seleccion == 1)
            {
                if (txt_Buscar.Text != null && txt_Buscar.Text != "")
                {
                    dgv_info.Visible = true;
                    dgv_info.Enabled = true;
                    dgv_info_buscar_Usuarios();
                }
            }
            if (seleccion==2)
            {
                if (txt_Buscar.Text != null && txt_Buscar.Text != "")
                {
                    dgv_info.Visible = true;
                    dgv_info.Enabled = true;
                    dgv_info_buscar_Clientes();
                }
            }
        }

        private void dgv_info_set_Clientes()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT id_Usuario AS ID,ApPaterno,ApMaterno,Nombre,TipoUsuario AS Nivel,RFC,Puntos from USUARIO WHERE Id_Usuario != -1";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_info.ReadOnly = true;
            dgv_info.DataSource = ds.Tables[0];
        }

        private void dgv_info_buscar_Clientes()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT id_Usuario AS ID,ApPaterno,ApMaterno,Nombre,TipoUsuario AS Nivel,RFC,Puntos from USUARIO WHERE Id_Usuario != -1 AND RFC LIKE '%" + txt_Buscar.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_info.ReadOnly = true;
            dgv_info.DataSource = ds.Tables[0];
        }

        private void dgv_info_set_Usuarios()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT ADMINISTRADOR.Contratado,Id_ADMINISTRADOR AS 'ID Admin', NOMBRE, ApPaterno, ApMaterno, RFC,Id_TIPOS_ADMIN_FK AS 'Tipo',Imagen " +
                "FROM ADMINISTRADOR INNER JOIN LOGINS ON LOGINS.Id_ADMINISTRADOR_FK = Id_ADMINISTRADOR " +
                "WHERE ((ADMINISTRADOR.Id_ADMINISTRADOR = 2) OR (ADMINISTRADOR.Id_ADMINISTRADOR = 3))";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_info.ReadOnly = true;
            dgv_info.DataSource = ds.Tables[0];
        }

        private void dgv_info_buscar_Usuarios()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT ADMINISTRADOR.Contratado,Id_ADMINISTRADOR AS 'ID Admin', NOMBRE, ApPaterno, ApMaterno, RFC,Id_TIPOS_ADMIN_FK AS 'Tipo',Imagen " +
                "FROM ADMINISTRADOR INNER JOIN LOGINS ON LOGINS.Id_ADMINISTRADOR_FK = Id_ADMINISTRADOR " +
                "WHERE ((ADMINISTRADOR.Id_ADMINISTRADOR = 2) OR (ADMINISTRADOR.Id_ADMINISTRADOR = 3)) AND (RFC LIKE '%"+txt_Buscar.Text+"%')";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_info.ReadOnly = true;
            dgv_info.DataSource = ds.Tables[0];
        }

        private void rdb_Usuarios_CheckedChanged(object sender, EventArgs e)
        {
            if(rdb_Usuarios.Checked==true)
            {
                seleccion = 1;
                gpb_Usuarios.Visible= true;
                gpb_Usuarios2.Visible = true;
                pnl_Clientes.Visible = false;
                dgv_Set();
            }
        }

        private void rdb_clientes_CheckedChanged(object sender, EventArgs e)
        {
            if (rdb_clientes.Checked == true)
            {
                seleccion = 2;
                gpb_Usuarios.Visible = false;
                gpb_Usuarios2.Visible = false;
                pnl_Clientes.Visible = true;
                dgv_Set();
            }    
        }

        private void Usuarios_Load(object sender, EventArgs e)
        {
            dgv_Set();
        }

        private void dgv_Set()
        {
            if (seleccion == 1)
            {
                dgv_info_set_Usuarios();
                pic_Foto.Visible = true;
                label9.Visible = true;
                label12.Visible = true;
            }
            if (seleccion == 2)
            {
                dgv_info_set_Clientes();
                pic_Foto.Visible = false;
                label9.Visible = false;
                label12.Visible = false;
            }
        }

        private void ch_modificar_CheckedChanged(object sender, EventArgs e)
        {
            
            bool c = true;
            bool a = false;
            if (ch_modificar.Checked == true)
            {
                c = false;
                a = true;

            }

            txt_Nombre.ReadOnly = c;
            txt_Paterno.ReadOnly = c;
            txt_Materno.ReadOnly = c;
            txt_RFC.ReadOnly = c;

            btn_Modificar.Enabled = a;
            pic_Foto.Enabled = a;
            ch_cajero.Enabled = a;
            ch_gerente.Enabled = a;
            ch_NO.Enabled = a;
            ch_Si.Enabled = a;

        }

        private void chb_mod_Cliente_CheckedChanged(object sender, EventArgs e)
        {
            txt_id_cliente.Enabled = false;
            txt_Nivel.Enabled = false;
            bool c = true;
            if (chb_mod_Cliente.Checked == true)
            {
                c = true;
                btn_Modificar.Enabled = true;
            }
            else
            {
                btn_Modificar.Enabled = false;
                c = false;
            }
                
            txt_paterno_cliente.Enabled= c;
            txt_materno_cliente.Enabled = c;
            txt_nombre_cliente.Enabled=c;
            
            txt_rfc_cliente.Enabled = c;
            txt_Puntos.Enabled= c;
            
        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();
            if (seleccion == 1)
            {
                DialogResult dialogo = MessageBox.Show("¿Seguro que desea modificar a el administrador, los cambios serán permanetes?",
                "Modificar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogo == DialogResult.Yes)
                    if (con != null)
                    {
                        SqlCommand com = new SqlCommand();
                        com.Connection = con;
                        com.CommandType = CommandType.StoredProcedure;

                        com.CommandText = "sp_Gestion_Usuarios";
                        com.Parameters.Clear();

                        ruta = System.Windows.Forms.Application.StartupPath + @"\Admins\" + rfc + ".jpg";
                        path = Path.GetFileName(ruta);

                        com.Parameters.Add("@CONTRATO", SqlDbType.Bit).Value = contrato;
                        com.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                        com.Parameters.Add("@NOMBRE", SqlDbType.VarChar, 50).Value = nombre;
                        com.Parameters.Add("@PATERNO", SqlDbType.VarChar, 50).Value = paterno;
                        com.Parameters.Add("@MATERNO", SqlDbType.VarChar, 50).Value = materno;
                        com.Parameters.Add("@RFC", SqlDbType.VarChar, 15).Value = rfc;
                        com.Parameters.Add("@TIPO", SqlDbType.Int).Value = tipo;

                        com.Parameters.Add("@IMG", SqlDbType.VarChar).Value = "\\" + path;

                        int a = com.ExecuteNonQuery();
                        con.Close();
                        if (a <= 0)
                        {
                            MessageBox.Show("No se pudo realizar la modificacion");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No hay conexión  ala base de datos");
                    }


                if (seleccion == 2)
                {
                    DialogResult dialogo2 = MessageBox.Show("¿Seguro que desea modificar a el cliente, los cambios serán permanetes?",
              "Modificar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogo2 == DialogResult.Yes)
                        if (con != null)
                        {
                            SqlCommand com = new SqlCommand();
                            com.Connection = con;
                            com.CommandType = CommandType.StoredProcedure;

                            com.CommandText = "sp_Gestion_Clientes";
                            com.Parameters.Clear();

                            com.Parameters.Add("@ID", SqlDbType.Int).Value = id_cliente;
                            com.Parameters.Add("@NOMBRE", SqlDbType.VarChar, 50).Value = nombre_cliente;
                            com.Parameters.Add("@PATERNO", SqlDbType.VarChar, 50).Value = paterno_cliente;
                            com.Parameters.Add("@MATERNO", SqlDbType.VarChar, 50).Value = materno_cliente;
                            com.Parameters.Add("@NIVEL", SqlDbType.Int).Value = nivel;
                            com.Parameters.Add("@RFC", SqlDbType.VarChar, 15).Value = rfc_cliente;
                            com.Parameters.Add("@PUNTOS", SqlDbType.Int).Value = puntos;


                            int a = com.ExecuteNonQuery();
                            con.Close();
                            if (a <= 0)
                            {
                                MessageBox.Show("No se pudo realizar la modificacion");
                            }
                        }
                        else
                        {
                            MessageBox.Show("No hay conexión  ala base de datos");
                        }
                }
                   
            }
            
        }

        private void dgv_info_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (seleccion == 1)
                try
                {
                    DataGridViewRow row = (DataGridViewRow)dgv_info.Rows[e.RowIndex];
                    contrato = bool.Parse(Convert.ToString(row.Cells[0].Value));
                    id = int.Parse(Convert.ToString(row.Cells[1].Value));
                    nombre = Convert.ToString(row.Cells[2].Value);
                    paterno = Convert.ToString(row.Cells[3].Value);
                    materno = Convert.ToString(row.Cells[4].Value);
                    rfc = Convert.ToString(row.Cells[5].Value);
                    tipo = int.Parse(Convert.ToString(row.Cells[6].Value));
                    imagen = Convert.ToString(row.Cells[7].Value);

                    txt_Contratado.Text = Convert.ToString(contrato);
                    txt_Admin.Text = Convert.ToString(id);
                    txt_Nombre.Text = Convert.ToString(nombre);
                    txt_Paterno.Text = Convert.ToString(paterno);
                    txt_Materno.Text = Convert.ToString(materno);
                    txt_RFC.Text = Convert.ToString(rfc);
                    txt_Tipo.Text = Convert.ToString(tipo);

                    Console.WriteLine(imagen);
                    pic_Foto.Image = System.Drawing.Image.FromFile(System.Windows.Forms.Application.StartupPath + "\\Admins" + imagen);

                }
                catch (Exception a)
                {
                    Console.WriteLine(a);
                }

            if (seleccion == 2)
                try
                {
                    DataGridViewRow row = (DataGridViewRow)dgv_info.Rows[e.RowIndex];
                    id_cliente = int.Parse(Convert.ToString(row.Cells[0].Value));
                    paterno_cliente = Convert.ToString(row.Cells[1].Value);
                    materno_cliente = Convert.ToString(row.Cells[2].Value);
                    nombre_cliente = Convert.ToString(row.Cells[3].Value);
                    nivel = int.Parse(Convert.ToString(row.Cells[4].Value));
                    rfc_cliente = Convert.ToString(row.Cells[5].Value);
                    puntos = int.Parse(Convert.ToString(row.Cells[6].Value));

                    txt_id_cliente.Text = Convert.ToString(id_cliente);
                    txt_paterno_cliente.Text = Convert.ToString(paterno_cliente);
                    txt_materno_cliente.Text = Convert.ToString(materno_cliente);
                    txt_nombre_cliente.Text = Convert.ToString(nombre_cliente);
                    txt_Nivel.Text = Convert.ToString(nivel);
                    txt_rfc_cliente.Text = Convert.ToString(rfc_cliente);
                    txt_Puntos.Text = Convert.ToString(puntos);

                }
                catch (Exception a)
                {
                    Console.WriteLine(a);
                }
        }

        private void pic_Foto_Click(object sender, EventArgs e)
        {
            if (ofd_FotoAdmin.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                string path = "\\Admins\\" + rfc + ".jpg";


                ruta = ofd_FotoAdmin.FileName;
                pic_Foto.Image = System.Drawing.Image.FromFile(ruta);
                pic_Foto.Image.Save(System.Windows.Forms.Application.StartupPath + "\\Admins\\" + rfc + ".jpg", ImageFormat.Jpeg);
                this.ruta = ofd_FotoAdmin.FileName;
                cambiarfoto = true;
                Console.WriteLine(path);
            }
        }
    }
}
