﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;


namespace PAPERBROS
{
    public partial class AlertaStock : Form
    {
        string mostrar;
        public AlertaStock()
        {
            InitializeComponent();
 
        }
        //GUI
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int IParam);

        private void pb_Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }

        private void pb_Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }


        private void AlertaStock_Load(object sender, EventArgs e)
        {
            DataGrid_Todo();
        }

        public void DataGrid_PRODUCTO()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT Id_Producto AS 'ID DEL PRODUCTO',Nombre,Disponibilidad,Lim_Stock AS 'LIMITE DE STOCK' FROM PRODUCTO WHERE NOMBRE LIKE '%"+txt_SearchProducto.Text+"%' AND (Lim_Stock>=Disponibilidad) AND (Disponibilidad!=-1) ORDER BY Disponibilidad ASC";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_Alerta.ReadOnly = true;
            dgv_Alerta.DataSource = ds.Tables[0];
        }

        public void DataGrid_Todo()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT Id_Producto AS 'ID DEL PRODUCTO',Nombre,Disponibilidad,Lim_Stock AS 'LIMITE DE STOCK' FROM PRODUCTO WHERE (Lim_Stock>=Disponibilidad) AND (Disponibilidad!=-1) ORDER BY Disponibilidad ASC";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_Alerta.ReadOnly = true;
            dgv_Alerta.DataSource = ds.Tables[0];
        }

        private void panel1_MouseDown_1(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void txt_SearchProducto_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataGrid_PRODUCTO();
            }
            catch (Exception ex)
            {
            }
        }
    }
}
