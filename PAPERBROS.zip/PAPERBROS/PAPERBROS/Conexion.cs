﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace PAPERBROS
{
    class Conexion
    {
        public static SqlConnection CadenaConexion()
        {
            /*Para conectar:
             * Explolador de servidores -> Conexiones de datos (Agregar nueva conexion)
             * Cadena= Conexion creada-> Propiedades -> Cadena de conexion
             */
            
            SqlConnection con = new SqlConnection("Data Source=CHRIS\\SQLEXPRESS;Initial Catalog=PAPERBROS;Persist Security Info=True;User ID=Admin;Password=123456789");
            Configuration config;
            config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.ConnectionStrings.SectionInformation.ProtectSection(null);
            config.Save();
            try
            {
                con.Open();
                return con;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
