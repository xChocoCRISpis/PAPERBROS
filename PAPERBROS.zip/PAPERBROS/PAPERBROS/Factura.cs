﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Data.Common;
using System.Security.Cryptography;

namespace PAPERBROS
{
    public partial class Factura : Form
    {
        int factura = -2;
        int detalle = -1;
        double descuento = 0;
        int cambio = 0;
        int cliente = -2;
        string TipoAdmin;
        int fac_consulta = 0;
        string fac_rfc;
        string foto;
        int disp;
        int id_prod;
        public Factura(int cliente, int factura,string admin,string imagen)
        {
            InitializeComponent();
            this.factura = factura;
            this.cliente = cliente;
            TipoAdmin = admin;
            foto = imagen;

            if (cliente == -2 && factura == -2)
            {
                btn_mas.Enabled = false;
                btn_menos.Enabled = false;
                txt_paga.Enabled = false;
                lbl_Cambio.Visible = false;
                lbl_Producto.Visible = false;
                btn_Descuento.Enabled = false;
                txt_Factura.Enabled = false;
                btn_terminar.Enabled = false;
                pnl_Titulo.Visible = false;
            }
            else 
            {
                btn_mas.Enabled = true;
                btn_menos.Enabled = true;
                txt_paga.Enabled = true;
                lbl_Cambio.Visible = true;
                lbl_Producto.Visible = true;
                btn_Descuento.Enabled = true;
                txt_Factura.Enabled = true;
                btn_terminar.Enabled = true;
                chb_Descuento.Enabled = true;
              
                pnl_Titulo.Visible = true;
            }
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int IParam);

        private void txt_Factura_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();

            if (txt_Factura.Text != null)
            {
                string mostrar;
                mostrar= "SELECT ID_FACTURA,FECHA,RFC AS CLIENTE FROM FACTURA " +
                   "INNER JOIN USUARIO ON Id_Usuario_FK = Id_Usuario " +
                   "WHERE USUARIO.RFC LIKE '%" + txt_RFCCliente.Text + "%'";
                SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dgv_Detalles.ReadOnly = true;
                dgv_Detalles.DataSource = ds.Tables[0];
            }
            
        }

        public void datagrid_detalle()
        {
  
                SqlConnection con = Conexion.CadenaConexion();
                string mostrar = "SELECT Id_Detalle, PRODUCTO.Nombre AS 'Artículo',PRODUCTO.Precio,Cantidad, ID_PRODUCTO AS 'ID PRODUCTO' FROM DETALLE INNER JOIN PRODUCTO" +
                    " ON DETALLE.Id_Producto_FK=PRODUCTO.Id_Producto WHERE Id_Factura_FK= " + factura;
                SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
                SqlCommandBuilder cb = new SqlCommandBuilder(da);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dgv_Detalles.DataSource = ds.Tables[0];
            
        }

        public void datagrid_factura()
        {
            SqlConnection con = Conexion.CadenaConexion();
            string mostrar;
            if (cliente != -1)
            {

                mostrar = "SELECT Id_Factura AS 'NUMERO TICKET',FECHA,USUARIO.RFC AS 'CLIENTE', ADMINISTRADOR.RFC AS 'CAJERO'," +
                  " TOTAL+Precio_descuento AS 'SUBTOTAL', TOTAL  AS 'TOTAL'  FROM FACTURA INNER JOIN USUARIO ON USUARIO.Id_Usuario = Id_Usuario_FK " +
                  "	INNER JOIN DESCUENTO ON ID_Descuento=Id_Descuento_FK"+
                  " INNER JOIN ADMINISTRADOR ON ADMINISTRADOR.Id_ADMINISTRADOR = FACTURA.Id_ADMNISTRADOR_FK  WHERE " + factura + " = Id_Factura";

            }
            else 
            {
                mostrar = "SELECT Id_Factura AS 'NUMERO TICKET',FECHA,USUARIO.RFC AS 'CLIENTE', ADMINISTRADOR.RFC AS 'CAJERO'," +
                  " TOTAL+Precio_descuento AS 'SUBTOTAL', TOTAL AS 'TOTAL'  FROM FACTURA INNER JOIN USUARIO ON USUARIO.Id_Usuario = Id_Usuario_FK " +
                  "	INNER JOIN DESCUENTO ON ID_Descuento=Id_Descuento_FK" +
                  " INNER JOIN ADMINISTRADOR ON ADMINISTRADOR.Id_ADMINISTRADOR = FACTURA.Id_ADMNISTRADOR_FK  WHERE " + factura + " = Id_Factura";
            }
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_Factura.DataSource = ds.Tables[0];

        }

        private void dgv_Detalles_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          
            

            SqlConnection con = Conexion.CadenaConexion();
            if (con != null)
            {
                try
                {
                    DataGridViewRow row = (DataGridViewRow)dgv_Detalles.Rows[e.RowIndex];
                    lbl_Producto.Text = Convert.ToString(row.Cells[1].Value);
                    detalle = int.Parse(Convert.ToString(row.Cells[0].Value));
                    if (cliente != -2)
                        id_prod = int.Parse(Convert.ToString(row.Cells[4].Value));

                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_Disponibilidad";// nombre del Proc Alm
                    com.Parameters.Add("@PRODUCTO", SqlDbType.VarChar, 50).Value = id_prod;

                    com.Parameters.Add("@Disponibilidad", SqlDbType.Int).Value = -1;
                    com.Parameters["@Disponibilidad"].Direction = ParameterDirection.Output;



                    com.ExecuteNonQuery();
                    con.Close();
                    disp = int.Parse(com.Parameters["@Disponibilidad"].Value.ToString());
                    
                }
                catch (Exception a)
                {
                    Console.WriteLine(a);
                }


            }
            else
            {
                MessageBox.Show("Sin conexion a la base de datos");
            }
        }

        private void btn_mas_Click(object sender, EventArgs e)
        {
            cambio = 1;
            SqlConnection con = Conexion.CadenaConexion();
            if (disp == -1 || disp > 0) 
                if (con != null)
                {
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_ModDetalle";
                    com.Parameters.Clear();


                    com.Parameters.Add("@FACTURA", SqlDbType.Int).Value = this.factura;
                    com.Parameters.Add("@PRODUCTO", SqlDbType.Int).Value = this.detalle;
                    com.Parameters.Add("@SELECTOR", SqlDbType.Int).Value = this.cambio;
                    com.ExecuteNonQuery();

                    datagrid_detalle();
                    datagrid_factura();
                    txt_paga.Text = null;
                }
                else
                {
                    MessageBox.Show("Sin conexión a la base de datos");
                }
            else 
            {
                MessageBox.Show("No hay suficientes productos");
            }
            cambio = 0;
        }

        private void btn_menos_Click(object sender, EventArgs e)
        {
            cambio = 2;
            SqlConnection con = Conexion.CadenaConexion();
            if (con != null)
            {
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "sp_ModDetalle";
                com.Parameters.Clear();


                com.Parameters.Add("@FACTURA", SqlDbType.Int).Value = this.factura;
                com.Parameters.Add("@PRODUCTO", SqlDbType.Int).Value = this.detalle;
                com.Parameters.Add("@SELECTOR", SqlDbType.Int).Value = this.cambio;
                com.ExecuteNonQuery();

                datagrid_detalle();
                datagrid_factura();
                txt_paga.Text = null;
            }
            else
            {
                MessageBox.Show("Sin conexión a la base de datos");
            }

            cambio = 0;
        }

        private void Factura_Load(object sender, EventArgs e)
        {
            txt_Descuento.Enabled = false;
            if (this.factura != -2)
            {
                datagrid_detalle();
                datagrid_factura();
                txt_RFCCliente.Enabled = false;
                label1.Enabled = false;
                chb_Descuento.Enabled = true;
                chb_Descuento.Visible = true;
                txt_Descuento.Enabled = false;
                txt_Factura.Text = factura + "";
                txt_Factura.Enabled = false;
                btn_Descuento.Enabled = false;
               
            }
            else
            {
                btn_Descuento.Visible = false;
                btn_menos.Visible = false;
                btn_mas.Visible = false;
                txt_Descuento.Visible = false;
                btn_terminar.Visible = false;
                txt_paga.Visible = false;
                lbl_puntos.Visible = false;
                lbl_PuntosDisp.Visible = false;
                lbl_PagadoCon.Visible = false;

            }
            if (cliente == -1)
            {
                chb_Descuento.Enabled = false;
                txt_Descuento.Enabled = false;
                PuntosDisponibles();
            }
            if(cliente != -2)
            {
                PuntosDisponibles();
            }                
        }


        private void txt_paga_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double total = double.Parse(Convert.ToString(dgv_Factura.Rows[0].Cells[5].Value));
                lbl_Cambio.Text = "Cambio: "+Convert.ToString((double.Parse(txt_paga.Text)) - total);
            }
            catch (Exception)
            {
                if (txt_paga.Text != null)
                {
                    txt_paga.Text = null;
                }
            }
        }

        private void txt_Descuento_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void chb_Descuento_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chb_Descuento.Checked == true)
            {
                txt_Descuento.Enabled = true;
                btn_Descuento.Enabled = true;
            }
            else
            {
                txt_Descuento.Enabled = false;
                btn_Descuento.Enabled = false;
            }
        }

        private void btn_Descuento_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();
            try
            {
                double descu = double.Parse(txt_Descuento.Text);
                this.descuento = descu;
                if (MessageBox.Show("¿Quieres descontar " + descu + " puntos?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
                if (descuento != 0)
                    if (con != null)
                    {
                        if (cliente != -1)
                        {
                            SqlCommand desc = new SqlCommand();
                            desc.Connection = con;
                            desc.CommandType = CommandType.StoredProcedure;
                            desc.CommandText = "sp_Descuento";
                            desc.Parameters.Clear();

                            desc.Parameters.Add("@FACTURA", SqlDbType.Int).Value = factura;
                            desc.Parameters.Add("@CLIENTE", SqlDbType.Int).Value = cliente;
                            desc.Parameters.Add("@DESCUENTO", SqlDbType.Int).Value = this.descuento;

                            desc.Parameters.Add("@DESC_OUT", SqlDbType.Int).Value = 1;
                            desc.Parameters.Add("@TOTAL_OUT", SqlDbType.Money).Value = 1;
                            desc.Parameters.Add("@PDIS_OUT", SqlDbType.Int).Value = 1;

                            desc.Parameters["@DESC_OUT"].Direction = ParameterDirection.Output;
                            desc.Parameters["@TOTAL_OUT"].Direction = ParameterDirection.Output;
                            desc.Parameters["@PDIS_OUT"].Direction = ParameterDirection.Output;
                            desc.ExecuteNonQuery();


                            int descuento = int.Parse(desc.Parameters["@DESC_OUT"].Value.ToString());
                            double total = double.Parse(desc.Parameters["@TOTAL_OUT"].Value.ToString());
                            int pdis = int.Parse(desc.Parameters["@PDIS_OUT"].Value.ToString());
                                Console.WriteLine("des:" + descuento, " total:" + total + " pdis:" + pdis);
                                PuntosDisponibles();


                                if (pdis >= descuento)
                            {
                                if (descuento <= total)
                                {
                                        datagrid_factura();
                                }
                                else
                                {
                                    MessageBox.Show("DESCUENTO EXCEDE AL TOTAL");
                                }
                            }
                            else
                            {
                                MessageBox.Show("PUNTOS INSUFICIENTES");
                            }
                        }
                        else
                        {
                            MessageBox.Show("No se le puede aplicar un descuento al cliente");
                        }
                    }
                    else {
                        MessageBox.Show("Sin conenexión a la base de datos");
                    }
            }

            catch (Exception a)
            {
                Console.WriteLine(a);
            }

        }

        private void btn_terminar_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();
            try
            {
                if (MessageBox.Show("¿Quieres terminar de cobrar este ticket?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    if (con != null)
                    {


                        SqlCommand p = new SqlCommand();
                        p.Connection = con;
                        p.CommandType = CommandType.StoredProcedure;
                        p.CommandText = "sp_SumaPuntos";
                        p.Parameters.Clear();

                        p.Parameters.Add("@FACTURA", SqlDbType.Int).Value = factura;
                        p.Parameters.Add("@CLIENTE", SqlDbType.Int).Value = cliente;
                        p.ExecuteNonQuery();
                        Cobrar cobrar = new Cobrar(TipoAdmin,foto);
                        cobrar.Close();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Sin conenexión a la base de datos");
                    }
            }

            catch (Exception a)
            {
                Console.WriteLine(a);
            }
        }

        private void txt_Factura_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception a)
            {
                MessageBox.Show(a + "");
            }
        }

        private void dgv_Detalles_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = (DataGridViewRow)dgv_Detalles.Rows[e.RowIndex];
                fac_consulta = int.Parse(Convert.ToString(row.Cells[0].Value));
                fac_rfc = Convert.ToString(row.Cells[2].Value);
                txt_RFCCliente.Text = null;
                txt_Factura.Text = Convert.ToString(fac_consulta);

                datagrid_verdetalle();
                datagrid_verfactura();
            }
            catch(Exception x)
            {

            }

           
        }

        public void datagrid_verdetalle()
        {

            SqlConnection con = Conexion.CadenaConexion();
            string mostrar = "SELECT Id_Detalle, PRODUCTO.Nombre AS 'Artículo',PRODUCTO.Precio,Cantidad FROM DETALLE "+
                "INNER JOIN FACTURA ON Id_Factura = Id_Factura_FK "+
                "INNER JOIN PRODUCTO ON Id_Producto_FK = Id_Producto  " +
                "INNER JOIN USUARIO ON Id_Usuario=Id_Usuario_FK "+
                "WHERE " + fac_consulta + " = Id_Factura AND USUARIO.RFC = '" + fac_rfc+"'";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_Detalles.DataSource = ds.Tables[0];

        }

        public void datagrid_verfactura()
        {
            SqlConnection con = Conexion.CadenaConexion();
            string mostrar;
            mostrar = "SELECT Id_Factura AS 'NUMERO TICKET',FECHA,USUARIO.RFC AS 'CLIENTE', ADMINISTRADOR.RFC AS 'CAJERO'," +
                 " TOTAL+Precio_descuento AS 'SUBTOTAL', TOTAL AS 'TOTAL'  FROM FACTURA INNER JOIN USUARIO ON USUARIO.Id_Usuario = Id_Usuario_FK " +
                 "	INNER JOIN DESCUENTO ON ID_Descuento=Id_Descuento_FK" +
                 " INNER JOIN ADMINISTRADOR ON ADMINISTRADOR.Id_ADMINISTRADOR = FACTURA.Id_ADMNISTRADOR_FK  WHERE " + fac_consulta + " = Id_Factura AND USUARIO.RFC = '" + fac_rfc+"'";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_Factura.DataSource = ds.Tables[0];

        }

        private void dgv_Factura_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pb_Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pb_Chico_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            pb_Full.Visible = true;
            pb_Full.Enabled = true;
            pb_Chico.Visible = false;
            pb_Chico.Enabled = false;
        }

        private void pb_Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }

        private void pb_Full_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            pb_Full.Visible = false;
            pb_Full.Enabled = false;
            pb_Chico.Visible = true;
            pb_Chico.Enabled = true;
        }

        private void pnl_Titulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void PuntosDisponibles()
        {
            SqlConnection con = Conexion.CadenaConexion();
            try
            {
                if (con != null)
                {


                    SqlCommand p = new SqlCommand();
                    p.Connection = con;
                    p.CommandType = CommandType.StoredProcedure;
                    p.CommandText = "sp_PuntosDisponibles";
                    p.Parameters.Clear();

                    p.Parameters.Add("@CLIENTE", SqlDbType.Int).Value = cliente;
                    p.Parameters.Add("@PUNTOS", SqlDbType.Int).Value = 0;
                    p.Parameters["@PUNTOS"].Direction = ParameterDirection.Output;

                    p.ExecuteNonQuery();
                   
                    int points = int.Parse(p.Parameters["@PUNTOS"].Value.ToString());
                    lbl_PuntosDisp.Text = points.ToString();
                }
                else
                {
                    MessageBox.Show("Sin conenexión a la base de datos");
                }
            }

            catch (Exception a)
            {
                Console.WriteLine(a);
            }
        }
    }
}
