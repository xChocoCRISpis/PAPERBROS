﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace PAPERBROS
{
    public partial class Inventario : Form
    {
        string mostrar;
        double precio;
        int cantidad;
        string tipoadmin;
        string foto;
        public Inventario(string TipoAdmin, string imagen)
        {
            InitializeComponent();
            dgv_Inv_set();
            tipoadmin = TipoAdmin;
            foto = imagen;
        }

        private void rd_disp_CheckedChanged(object sender, EventArgs e)
        {
            bool check = false;
            if (rd_disp.Checked == true)
            {
                check = true;
                txt_Precio.Enabled = false;
                lbl_prec.Enabled = false;
            }

            txt_Cantidad.Enabled = check;


        }

       

        private void rd_precio_CheckedChanged(object sender, EventArgs e)
        {
            bool check = false;
            if (rd_precio.Checked == true)
            {
                check = true;
            }
            txt_Precio.Enabled = check;
            lbl_prec.Enabled = check;
        }

        public void dgv_Inv_set()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT * FROM PRODUCTO";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_Inv.DataSource = ds.Tables[0];
        }

        public void dgv_Inv_Buscar()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT * FROM PRODUCTO WHERE Nombre LIKE '%" + txt_Buscar.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_Inv.DataSource = ds.Tables[0];
        }

        private void txt_Buscar_TextChanged(object sender, EventArgs e)
        {
            if (txt_Buscar.Text != null && txt_Buscar.Text != "")
                dgv_Inv_Buscar();
        }

        private void dgv_Inv_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = (DataGridViewRow)dgv_Inv.Rows[e.RowIndex];
                int id = int.Parse(Convert.ToString(row.Cells[0].Value));
                string prod = Convert.ToString(row.Cells[1].Value);
                string disp = Convert.ToString(row.Cells[2].Value);
                string precio = Convert.ToString(row.Cells[3].Value);
                txt_Id.Text = Convert.ToString(id);
                txt_Nombre.Text = prod;
                txt_Cantidad.Text = disp;
                txt_Precio.Text = precio;

            }
            catch (Exception)
            {
            }
        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();

            DialogResult dialogo = MessageBox.Show("¿Seguro que desea modificar el inventario?",
              "Modificar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if(dialogo==DialogResult.Yes)
            if (con != null)
            {
                try
                {
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_ModProductos";
                    com.Parameters.Clear();


                    /*
                     * @ID_PRODUCTO INT,
                        @DISPONIBILIDAD INT,
                        @PRECIO MONEY
                     */

                    Console.WriteLine("precio: " + precio);
                    Console.WriteLine("cantidad: " + cantidad);
                    com.Parameters.Add("@ID_PRODUCTO", SqlDbType.Int).Value = txt_Id.Text;
                    com.Parameters.Add("@DISPONIBILIDAD", SqlDbType.Int).Value = cantidad;
                    com.Parameters.Add("@PRECIO", SqlDbType.Money).Value = precio;
                    com.ExecuteNonQuery();
                    con.Close();
                        dgv_Inv_set();
                        txt_Buscar.Text = null;
                        txt_Cantidad.Text = null;
                        txt_Precio.Text = null;
                        txt_Nombre.Text = null;
                        txt_Id.Text=null;
                        rd_disp.Checked = false;
                        rd_precio.Checked = false;
                }
                catch (Exception A)
                {
                    MessageBox.Show(A + "");
                }
            }
            else
            {
                MessageBox.Show("Sin conexión a la base de datos");
            }
        }

        private void txt_Precio_TextChanged(object sender, EventArgs e)
        {
            if (txt_Precio.Text != null && txt_Precio.Text != "")
                try
                {
                    precio = double.Parse(txt_Precio.Text);
                }
                catch (Exception)
                { 
                
                }

        }

        private void txt_Cantidad_TextChanged(object sender, EventArgs e)
        {
            if (txt_Cantidad.Text != null && txt_Cantidad.Text != "")
                try
                {
                    cantidad = int.Parse(txt_Cantidad.Text);
                }
                catch (Exception)
                {

                }

        }

        private void btn_regresar_Click(object sender, EventArgs e)
        {
            Opciones Opciones = new Opciones(tipoadmin,foto);
            Opciones.Show();
            this.Dispose();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {

        }
    }
}

