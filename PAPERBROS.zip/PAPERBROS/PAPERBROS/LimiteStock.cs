﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAPERBROS
{
    public partial class LimiteStock : Form
    {
        string mostrar;
        public LimiteStock()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txt_SearchProducto_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataGrid_PRODUCTO();
            }
           catch (Exception ex) 
            { 
            }
        }

        public void DataGrid_PRODUCTO()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT Id_Producto,Nombre,Disponibilidad,Lim_Stock FROM PRODUCTO WHERE Nombre LIKE '%" + txt_SearchProducto.Text + "%' ORDER BY Disponibilidad ASC";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_buscador.ReadOnly = true;
            dgv_buscador.DataSource = ds.Tables[0];
        }

        public void DataGrid_Todo()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT Id_Producto,Nombre,Disponibilidad,Lim_Stock FROM PRODUCTO ORDER BY Disponibilidad ASC";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_buscador.ReadOnly = true;
            dgv_buscador.DataSource = ds.Tables[0];
        }

        private void LimiteStock_Load(object sender, EventArgs e)
        {
            DataGrid_Todo();
        }

        private void dgv_buscador_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = (DataGridViewRow)dgv_buscador.Rows[e.RowIndex];
                int id = int.Parse(Convert.ToString(row.Cells[0].Value));
                string nombre = Convert.ToString(row.Cells[1].Value);
                int disponibilidad= int.Parse(Convert.ToString(row.Cells[2].Value));
                int limite= int.Parse(Convert.ToString(row.Cells[3].Value));

                txt_id.Text = Convert.ToString(id);
                txt_nombre.Text = Convert.ToString(nombre);
                txt_disponibilidad.Text = Convert.ToString(disponibilidad);
                txt_limite.Text = Convert.ToString(limite);
            }
            catch (Exception)
            {
            }
        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();

            DialogResult dialogo = MessageBox.Show("¿Seguro que desea modificar limite de stock del producto: "+txt_nombre.Text+"?",
              "Modificar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialogo == DialogResult.Yes)
                if (con != null)
                {
                    try
                    {
                        SqlCommand com = new SqlCommand();
                        com.Connection = con;
                        com.CommandType = CommandType.StoredProcedure;
                        com.CommandText = "sp_ModLimiteStock";
                        com.Parameters.Clear();


                        /*
                        @ID_PRODUCTO INT,
                        @LIMITE INT
                         */

                        com.Parameters.Add("@ID_PRODUCTO", SqlDbType.Int).Value = Convert.ToInt32(txt_id.Text);
                        com.Parameters.Add("@LIMITE", SqlDbType.Int).Value =Convert.ToInt32(txt_limite.Text);

                        com.ExecuteNonQuery();
                        con.Close();

                        DataGrid_Todo();
                        txt_id.Text = null;
                        txt_disponibilidad.Text = null;
                        txt_limite.Text = null;
                        txt_SearchProducto.Text = null;
                        txt_nombre.Text = null;
                    }
                    catch (Exception A)
                    {
                        txt_limite.Text = null;
                    }
                }
                else
                {
                    MessageBox.Show("Sin conexión a la base de datos");
                }
        }
    }
}
