﻿
namespace PAPERBROS
{
    partial class SuperAdministrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SuperAdministrador));
            this.dgv_info = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lable7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_Contratado = new System.Windows.Forms.TextBox();
            this.txt_Admin = new System.Windows.Forms.TextBox();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_Paterno = new System.Windows.Forms.TextBox();
            this.txt_RFC = new System.Windows.Forms.TextBox();
            this.txt_Materno = new System.Windows.Forms.TextBox();
            this.txt_Tipo = new System.Windows.Forms.TextBox();
            this.txt_Login = new System.Windows.Forms.TextBox();
            this.txt_Contra = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Buscar = new System.Windows.Forms.TextBox();
            this.btn_Modificar = new System.Windows.Forms.Button();
            this.ch_modificar = new System.Windows.Forms.CheckBox();
            this.ofd_FotoAdmin = new System.Windows.Forms.OpenFileDialog();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ch_Si = new System.Windows.Forms.CheckBox();
            this.ch_NO = new System.Windows.Forms.CheckBox();
            this.ch_gerente = new System.Windows.Forms.CheckBox();
            this.ch_sa = new System.Windows.Forms.CheckBox();
            this.ch_cajero = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pic_Foto = new System.Windows.Forms.PictureBox();
            this.btn_BackupDif = new System.Windows.Forms.Button();
            this.btn_BackupCom = new System.Windows.Forms.Button();
            this.pnl_CopiaTablas = new System.Windows.Forms.Panel();
            this.btn_CerrarCopiaTabla = new System.Windows.Forms.Button();
            this.btn_CopiarTabla = new System.Windows.Forms.Button();
            this.rdbtn_Usuario = new System.Windows.Forms.RadioButton();
            this.rdbtn_TiposAdmin = new System.Windows.Forms.RadioButton();
            this.rdbtn_Producto = new System.Windows.Forms.RadioButton();
            this.rdbtn_Logins = new System.Windows.Forms.RadioButton();
            this.rdbtn_Ticket = new System.Windows.Forms.RadioButton();
            this.rdbtn_Descuento = new System.Windows.Forms.RadioButton();
            this.rdbtn_Bitacora = new System.Windows.Forms.RadioButton();
            this.rdbtn_Detalle = new System.Windows.Forms.RadioButton();
            this.rdbtn_Administrador = new System.Windows.Forms.RadioButton();
            this.btn_OpenCopyTable = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_info)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Foto)).BeginInit();
            this.pnl_CopiaTablas.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv_info
            // 
            this.dgv_info.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_info.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Franklin Gothic Demi", 9.75F, System.Drawing.FontStyle.Italic);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(16)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_info.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_info.EnableHeadersVisualStyles = false;
            this.dgv_info.Location = new System.Drawing.Point(12, 292);
            this.dgv_info.Name = "dgv_info";
            this.dgv_info.RowHeadersVisible = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(74)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_info.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_info.Size = new System.Drawing.Size(762, 162);
            this.dgv_info.TabIndex = 0;
            this.dgv_info.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_info_CellContentClick);
            this.dgv_info.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_info_CellDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(23, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Contratado";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(34, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Id Admin";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(38, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nombre";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(11, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Apellido paterno";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(46, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Login";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(46, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "Tipo";
            // 
            // lable7
            // 
            this.lable7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lable7.AutoSize = true;
            this.lable7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lable7.Location = new System.Drawing.Point(46, 22);
            this.lable7.Name = "lable7";
            this.lable7.Size = new System.Drawing.Size(27, 15);
            this.lable7.TabIndex = 6;
            this.lable7.Text = "RFC";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(9, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 15);
            this.label8.TabIndex = 5;
            this.label8.Text = "Apellido materno";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(680, 140);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 15);
            this.label9.TabIndex = 9;
            this.label9.Text = "Foto";
            // 
            // txt_Contratado
            // 
            this.txt_Contratado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Contratado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Contratado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Contratado.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Contratado.Location = new System.Drawing.Point(100, 46);
            this.txt_Contratado.Name = "txt_Contratado";
            this.txt_Contratado.ReadOnly = true;
            this.txt_Contratado.Size = new System.Drawing.Size(166, 20);
            this.txt_Contratado.TabIndex = 11;
            // 
            // txt_Admin
            // 
            this.txt_Admin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Admin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Admin.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Admin.Location = new System.Drawing.Point(100, 72);
            this.txt_Admin.Name = "txt_Admin";
            this.txt_Admin.ReadOnly = true;
            this.txt_Admin.Size = new System.Drawing.Size(166, 20);
            this.txt_Admin.TabIndex = 12;
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Nombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Nombre.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Nombre.Location = new System.Drawing.Point(100, 98);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.ReadOnly = true;
            this.txt_Nombre.Size = new System.Drawing.Size(166, 20);
            this.txt_Nombre.TabIndex = 13;
            // 
            // txt_Paterno
            // 
            this.txt_Paterno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Paterno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Paterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Paterno.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Paterno.Location = new System.Drawing.Point(100, 127);
            this.txt_Paterno.Name = "txt_Paterno";
            this.txt_Paterno.ReadOnly = true;
            this.txt_Paterno.Size = new System.Drawing.Size(166, 20);
            this.txt_Paterno.TabIndex = 14;
            // 
            // txt_RFC
            // 
            this.txt_RFC.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_RFC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_RFC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_RFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_RFC.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_RFC.Location = new System.Drawing.Point(87, 22);
            this.txt_RFC.Name = "txt_RFC";
            this.txt_RFC.ReadOnly = true;
            this.txt_RFC.Size = new System.Drawing.Size(164, 20);
            this.txt_RFC.TabIndex = 15;
            // 
            // txt_Materno
            // 
            this.txt_Materno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Materno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Materno.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Materno.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Materno.Location = new System.Drawing.Point(100, 153);
            this.txt_Materno.Name = "txt_Materno";
            this.txt_Materno.ReadOnly = true;
            this.txt_Materno.Size = new System.Drawing.Size(167, 20);
            this.txt_Materno.TabIndex = 16;
            // 
            // txt_Tipo
            // 
            this.txt_Tipo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Tipo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Tipo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Tipo.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Tipo.Location = new System.Drawing.Point(87, 46);
            this.txt_Tipo.Name = "txt_Tipo";
            this.txt_Tipo.ReadOnly = true;
            this.txt_Tipo.Size = new System.Drawing.Size(164, 20);
            this.txt_Tipo.TabIndex = 17;
            // 
            // txt_Login
            // 
            this.txt_Login.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Login.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Login.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Login.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Login.Location = new System.Drawing.Point(87, 73);
            this.txt_Login.Name = "txt_Login";
            this.txt_Login.ReadOnly = true;
            this.txt_Login.Size = new System.Drawing.Size(164, 20);
            this.txt_Login.TabIndex = 18;
            // 
            // txt_Contra
            // 
            this.txt_Contra.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Contra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Contra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Contra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Contra.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Contra.Location = new System.Drawing.Point(87, 99);
            this.txt_Contra.Name = "txt_Contra";
            this.txt_Contra.ReadOnly = true;
            this.txt_Contra.Size = new System.Drawing.Size(164, 20);
            this.txt_Contra.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(20, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 15);
            this.label10.TabIndex = 19;
            this.label10.Text = "Contraseña";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(12, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 15);
            this.label7.TabIndex = 21;
            this.label7.Text = "Buscar por RFC:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txt_Buscar
            // 
            this.txt_Buscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Buscar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Buscar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Buscar.Location = new System.Drawing.Point(103, 22);
            this.txt_Buscar.Name = "txt_Buscar";
            this.txt_Buscar.Size = new System.Drawing.Size(164, 20);
            this.txt_Buscar.TabIndex = 22;
            this.txt_Buscar.TextChanged += new System.EventHandler(this.txt_Buscar_TextChanged);
            // 
            // btn_Modificar
            // 
            this.btn_Modificar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Modificar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Modificar.Enabled = false;
            this.btn_Modificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Modificar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Modificar.Location = new System.Drawing.Point(683, 252);
            this.btn_Modificar.Name = "btn_Modificar";
            this.btn_Modificar.Size = new System.Drawing.Size(75, 23);
            this.btn_Modificar.TabIndex = 23;
            this.btn_Modificar.Text = "Modificar";
            this.btn_Modificar.UseVisualStyleBackColor = false;
            this.btn_Modificar.Click += new System.EventHandler(this.btn_Modificar_Click);
            // 
            // ch_modificar
            // 
            this.ch_modificar.AutoSize = true;
            this.ch_modificar.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_modificar.Location = new System.Drawing.Point(12, 19);
            this.ch_modificar.Name = "ch_modificar";
            this.ch_modificar.Size = new System.Drawing.Size(69, 19);
            this.ch_modificar.TabIndex = 24;
            this.ch_modificar.Text = "Modificar";
            this.ch_modificar.UseVisualStyleBackColor = true;
            this.ch_modificar.CheckedChanged += new System.EventHandler(this.ch_modificar_CheckedChanged);
            // 
            // ofd_FotoAdmin
            // 
            this.ofd_FotoAdmin.FileName = "openFileDialog1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(109, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(123, 15);
            this.label11.TabIndex = 25;
            this.label11.Text = "Contratado= 0 = No, 1= Si";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(17, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(304, 15);
            this.label12.TabIndex = 26;
            this.label12.Text = "Tipos de administradores: 1= SuperAdmin, 2= Gerente, 3= Cajero";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // ch_Si
            // 
            this.ch_Si.AutoSize = true;
            this.ch_Si.BackColor = System.Drawing.Color.Transparent;
            this.ch_Si.Enabled = false;
            this.ch_Si.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_Si.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_Si.Location = new System.Drawing.Point(274, 34);
            this.ch_Si.Name = "ch_Si";
            this.ch_Si.Size = new System.Drawing.Size(35, 19);
            this.ch_Si.TabIndex = 27;
            this.ch_Si.Text = "Si";
            this.ch_Si.UseVisualStyleBackColor = false;
            this.ch_Si.CheckedChanged += new System.EventHandler(this.ch_Si_CheckedChanged);
            // 
            // ch_NO
            // 
            this.ch_NO.AutoSize = true;
            this.ch_NO.BackColor = System.Drawing.Color.Transparent;
            this.ch_NO.Enabled = false;
            this.ch_NO.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_NO.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_NO.Location = new System.Drawing.Point(274, 52);
            this.ch_NO.Name = "ch_NO";
            this.ch_NO.Size = new System.Drawing.Size(39, 19);
            this.ch_NO.TabIndex = 28;
            this.ch_NO.Text = "No";
            this.ch_NO.UseVisualStyleBackColor = false;
            this.ch_NO.CheckedChanged += new System.EventHandler(this.ch_NO_CheckedChanged);
            // 
            // ch_gerente
            // 
            this.ch_gerente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_gerente.AutoSize = true;
            this.ch_gerente.BackColor = System.Drawing.Color.Transparent;
            this.ch_gerente.Enabled = false;
            this.ch_gerente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_gerente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_gerente.Location = new System.Drawing.Point(126, 127);
            this.ch_gerente.Name = "ch_gerente";
            this.ch_gerente.Size = new System.Drawing.Size(61, 19);
            this.ch_gerente.TabIndex = 30;
            this.ch_gerente.Text = "Gerente";
            this.ch_gerente.UseVisualStyleBackColor = false;
            this.ch_gerente.CheckedChanged += new System.EventHandler(this.ch_gerente_CheckedChanged);
            // 
            // ch_sa
            // 
            this.ch_sa.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_sa.AutoSize = true;
            this.ch_sa.BackColor = System.Drawing.Color.Transparent;
            this.ch_sa.Enabled = false;
            this.ch_sa.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_sa.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_sa.Location = new System.Drawing.Point(12, 127);
            this.ch_sa.Name = "ch_sa";
            this.ch_sa.Size = new System.Drawing.Size(84, 19);
            this.ch_sa.TabIndex = 29;
            this.ch_sa.Text = "SuperAdmin";
            this.ch_sa.UseVisualStyleBackColor = false;
            this.ch_sa.CheckedChanged += new System.EventHandler(this.ch_sa_CheckedChanged);
            // 
            // ch_cajero
            // 
            this.ch_cajero.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_cajero.AutoSize = true;
            this.ch_cajero.BackColor = System.Drawing.Color.Transparent;
            this.ch_cajero.Enabled = false;
            this.ch_cajero.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_cajero.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_cajero.Location = new System.Drawing.Point(233, 127);
            this.ch_cajero.Name = "ch_cajero";
            this.ch_cajero.Size = new System.Drawing.Size(56, 19);
            this.ch_cajero.TabIndex = 31;
            this.ch_cajero.Text = "Cajero";
            this.ch_cajero.UseVisualStyleBackColor = false;
            this.ch_cajero.CheckedChanged += new System.EventHandler(this.ch_cajero_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.groupBox1.Controls.Add(this.ch_NO);
            this.groupBox1.Controls.Add(this.txt_Paterno);
            this.groupBox1.Controls.Add(this.ch_Si);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.ch_modificar);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_Materno);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_Nombre);
            this.groupBox1.Controls.Add(this.txt_Contratado);
            this.groupBox1.Controls.Add(this.txt_Admin);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(15, 87);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(326, 199);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.groupBox2.Controls.Add(this.ch_cajero);
            this.groupBox2.Controls.Add(this.txt_Login);
            this.groupBox2.Controls.Add(this.ch_gerente);
            this.groupBox2.Controls.Add(this.lable7);
            this.groupBox2.Controls.Add(this.ch_sa);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txt_Contra);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txt_RFC);
            this.groupBox2.Controls.Add(this.txt_Tipo);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(354, 87);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(302, 199);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(294, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(372, 33);
            this.label13.TabIndex = 34;
            this.label13.Text = "GESTIÓN DE USUARIOS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(708, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 46);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // pic_Foto
            // 
            this.pic_Foto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pic_Foto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.pic_Foto.Enabled = false;
            this.pic_Foto.Location = new System.Drawing.Point(673, 159);
            this.pic_Foto.Name = "pic_Foto";
            this.pic_Foto.Size = new System.Drawing.Size(100, 87);
            this.pic_Foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Foto.TabIndex = 10;
            this.pic_Foto.TabStop = false;
            this.pic_Foto.Click += new System.EventHandler(this.pic_Foto_Click);
            // 
            // btn_BackupDif
            // 
            this.btn_BackupDif.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_BackupDif.BackColor = System.Drawing.Color.Transparent;
            this.btn_BackupDif.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BackupDif.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_BackupDif.Location = new System.Drawing.Point(663, 73);
            this.btn_BackupDif.Name = "btn_BackupDif";
            this.btn_BackupDif.Size = new System.Drawing.Size(121, 23);
            this.btn_BackupDif.TabIndex = 36;
            this.btn_BackupDif.Text = "BACKUP PARCIAL";
            this.btn_BackupDif.UseVisualStyleBackColor = false;
            this.btn_BackupDif.Click += new System.EventHandler(this.btn_BackupDif_Click);
            // 
            // btn_BackupCom
            // 
            this.btn_BackupCom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_BackupCom.BackColor = System.Drawing.Color.Transparent;
            this.btn_BackupCom.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BackupCom.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_BackupCom.Location = new System.Drawing.Point(662, 102);
            this.btn_BackupCom.Name = "btn_BackupCom";
            this.btn_BackupCom.Size = new System.Drawing.Size(121, 23);
            this.btn_BackupCom.TabIndex = 37;
            this.btn_BackupCom.Text = "BACKUP ENTERO";
            this.btn_BackupCom.UseVisualStyleBackColor = false;
            this.btn_BackupCom.Click += new System.EventHandler(this.btn_BackupCom_Click);
            // 
            // pnl_CopiaTablas
            // 
            this.pnl_CopiaTablas.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_CopiaTablas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.pnl_CopiaTablas.Controls.Add(this.groupBox3);
            this.pnl_CopiaTablas.Controls.Add(this.label14);
            this.pnl_CopiaTablas.Controls.Add(this.btn_CerrarCopiaTabla);
            this.pnl_CopiaTablas.Controls.Add(this.btn_CopiarTabla);
            this.pnl_CopiaTablas.Location = new System.Drawing.Point(662, 281);
            this.pnl_CopiaTablas.Name = "pnl_CopiaTablas";
            this.pnl_CopiaTablas.Size = new System.Drawing.Size(797, 291);
            this.pnl_CopiaTablas.TabIndex = 38;
            this.pnl_CopiaTablas.Visible = false;
            // 
            // btn_CerrarCopiaTabla
            // 
            this.btn_CerrarCopiaTabla.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_CerrarCopiaTabla.BackColor = System.Drawing.Color.Transparent;
            this.btn_CerrarCopiaTabla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CerrarCopiaTabla.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_CerrarCopiaTabla.Location = new System.Drawing.Point(590, 151);
            this.btn_CerrarCopiaTabla.Name = "btn_CerrarCopiaTabla";
            this.btn_CerrarCopiaTabla.Size = new System.Drawing.Size(121, 41);
            this.btn_CerrarCopiaTabla.TabIndex = 41;
            this.btn_CerrarCopiaTabla.Text = "CERRAR";
            this.btn_CerrarCopiaTabla.UseVisualStyleBackColor = false;
            this.btn_CerrarCopiaTabla.Click += new System.EventHandler(this.btn_CerrarCopiaTabla_Click);
            // 
            // btn_CopiarTabla
            // 
            this.btn_CopiarTabla.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_CopiarTabla.BackColor = System.Drawing.Color.Transparent;
            this.btn_CopiarTabla.Enabled = false;
            this.btn_CopiarTabla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CopiarTabla.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_CopiarTabla.Location = new System.Drawing.Point(590, 93);
            this.btn_CopiarTabla.Name = "btn_CopiarTabla";
            this.btn_CopiarTabla.Size = new System.Drawing.Size(121, 40);
            this.btn_CopiarTabla.TabIndex = 40;
            this.btn_CopiarTabla.Text = "COPIAR TABLA";
            this.btn_CopiarTabla.UseVisualStyleBackColor = false;
            this.btn_CopiarTabla.Click += new System.EventHandler(this.btn_CopiarTabla_Click);
            // 
            // rdbtn_Usuario
            // 
            this.rdbtn_Usuario.AutoSize = true;
            this.rdbtn_Usuario.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Usuario.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Usuario.Location = new System.Drawing.Point(346, 104);
            this.rdbtn_Usuario.Name = "rdbtn_Usuario";
            this.rdbtn_Usuario.Size = new System.Drawing.Size(96, 29);
            this.rdbtn_Usuario.TabIndex = 8;
            this.rdbtn_Usuario.TabStop = true;
            this.rdbtn_Usuario.Text = "Usuario";
            this.rdbtn_Usuario.UseVisualStyleBackColor = true;
            this.rdbtn_Usuario.CheckedChanged += new System.EventHandler(this.rdbtn_Usuario_CheckedChanged);
            // 
            // rdbtn_TiposAdmin
            // 
            this.rdbtn_TiposAdmin.AutoSize = true;
            this.rdbtn_TiposAdmin.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_TiposAdmin.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_TiposAdmin.Location = new System.Drawing.Point(346, 77);
            this.rdbtn_TiposAdmin.Name = "rdbtn_TiposAdmin";
            this.rdbtn_TiposAdmin.Size = new System.Drawing.Size(142, 29);
            this.rdbtn_TiposAdmin.TabIndex = 7;
            this.rdbtn_TiposAdmin.TabStop = true;
            this.rdbtn_TiposAdmin.Text = "Tipos_Admin";
            this.rdbtn_TiposAdmin.UseVisualStyleBackColor = true;
            this.rdbtn_TiposAdmin.CheckedChanged += new System.EventHandler(this.rdbtn_TiposAdmin_CheckedChanged);
            // 
            // rdbtn_Producto
            // 
            this.rdbtn_Producto.AutoSize = true;
            this.rdbtn_Producto.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Producto.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Producto.Location = new System.Drawing.Point(346, 53);
            this.rdbtn_Producto.Name = "rdbtn_Producto";
            this.rdbtn_Producto.Size = new System.Drawing.Size(108, 29);
            this.rdbtn_Producto.TabIndex = 6;
            this.rdbtn_Producto.TabStop = true;
            this.rdbtn_Producto.Text = "Producto";
            this.rdbtn_Producto.UseVisualStyleBackColor = true;
            this.rdbtn_Producto.CheckedChanged += new System.EventHandler(this.rdbtn_Producto_CheckedChanged);
            // 
            // rdbtn_Logins
            // 
            this.rdbtn_Logins.AutoSize = true;
            this.rdbtn_Logins.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Logins.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Logins.Location = new System.Drawing.Point(200, 104);
            this.rdbtn_Logins.Name = "rdbtn_Logins";
            this.rdbtn_Logins.Size = new System.Drawing.Size(89, 29);
            this.rdbtn_Logins.TabIndex = 5;
            this.rdbtn_Logins.TabStop = true;
            this.rdbtn_Logins.Text = "Logins";
            this.rdbtn_Logins.UseVisualStyleBackColor = true;
            this.rdbtn_Logins.CheckedChanged += new System.EventHandler(this.rdbtn_Logins_CheckedChanged);
            // 
            // rdbtn_Ticket
            // 
            this.rdbtn_Ticket.AutoSize = true;
            this.rdbtn_Ticket.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Ticket.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Ticket.Location = new System.Drawing.Point(200, 77);
            this.rdbtn_Ticket.Name = "rdbtn_Ticket";
            this.rdbtn_Ticket.Size = new System.Drawing.Size(82, 29);
            this.rdbtn_Ticket.TabIndex = 4;
            this.rdbtn_Ticket.TabStop = true;
            this.rdbtn_Ticket.Text = "Ticket";
            this.rdbtn_Ticket.UseVisualStyleBackColor = true;
            this.rdbtn_Ticket.CheckedChanged += new System.EventHandler(this.rdbtn_Ticket_CheckedChanged);
            // 
            // rdbtn_Descuento
            // 
            this.rdbtn_Descuento.AutoSize = true;
            this.rdbtn_Descuento.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Descuento.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Descuento.Location = new System.Drawing.Point(200, 52);
            this.rdbtn_Descuento.Name = "rdbtn_Descuento";
            this.rdbtn_Descuento.Size = new System.Drawing.Size(121, 29);
            this.rdbtn_Descuento.TabIndex = 3;
            this.rdbtn_Descuento.TabStop = true;
            this.rdbtn_Descuento.Text = "Descuento";
            this.rdbtn_Descuento.UseVisualStyleBackColor = true;
            this.rdbtn_Descuento.CheckedChanged += new System.EventHandler(this.rdbtn_Descuento_CheckedChanged);
            // 
            // rdbtn_Bitacora
            // 
            this.rdbtn_Bitacora.AutoSize = true;
            this.rdbtn_Bitacora.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Bitacora.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Bitacora.Location = new System.Drawing.Point(26, 104);
            this.rdbtn_Bitacora.Name = "rdbtn_Bitacora";
            this.rdbtn_Bitacora.Size = new System.Drawing.Size(101, 29);
            this.rdbtn_Bitacora.TabIndex = 2;
            this.rdbtn_Bitacora.TabStop = true;
            this.rdbtn_Bitacora.Text = "Bitácora";
            this.rdbtn_Bitacora.UseVisualStyleBackColor = true;
            this.rdbtn_Bitacora.CheckedChanged += new System.EventHandler(this.rdbtn_Bitacora_CheckedChanged);
            // 
            // rdbtn_Detalle
            // 
            this.rdbtn_Detalle.AutoSize = true;
            this.rdbtn_Detalle.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Detalle.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Detalle.Location = new System.Drawing.Point(26, 77);
            this.rdbtn_Detalle.Name = "rdbtn_Detalle";
            this.rdbtn_Detalle.Size = new System.Drawing.Size(88, 29);
            this.rdbtn_Detalle.TabIndex = 1;
            this.rdbtn_Detalle.TabStop = true;
            this.rdbtn_Detalle.Text = "Detalle";
            this.rdbtn_Detalle.UseVisualStyleBackColor = true;
            this.rdbtn_Detalle.CheckedChanged += new System.EventHandler(this.rdbtn_Detalle_CheckedChanged);
            // 
            // rdbtn_Administrador
            // 
            this.rdbtn_Administrador.AutoSize = true;
            this.rdbtn_Administrador.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_Administrador.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdbtn_Administrador.Location = new System.Drawing.Point(26, 52);
            this.rdbtn_Administrador.Name = "rdbtn_Administrador";
            this.rdbtn_Administrador.Size = new System.Drawing.Size(151, 29);
            this.rdbtn_Administrador.TabIndex = 0;
            this.rdbtn_Administrador.TabStop = true;
            this.rdbtn_Administrador.Text = "Administrador";
            this.rdbtn_Administrador.UseVisualStyleBackColor = true;
            this.rdbtn_Administrador.CheckedChanged += new System.EventHandler(this.rdbtn_Administrador_CheckedChanged);
            // 
            // btn_OpenCopyTable
            // 
            this.btn_OpenCopyTable.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_OpenCopyTable.BackColor = System.Drawing.Color.Transparent;
            this.btn_OpenCopyTable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OpenCopyTable.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_OpenCopyTable.Location = new System.Drawing.Point(662, 133);
            this.btn_OpenCopyTable.Name = "btn_OpenCopyTable";
            this.btn_OpenCopyTable.Size = new System.Drawing.Size(121, 23);
            this.btn_OpenCopyTable.TabIndex = 39;
            this.btn_OpenCopyTable.Text = "COPIAR TABLA";
            this.btn_OpenCopyTable.UseVisualStyleBackColor = false;
            this.btn_OpenCopyTable.Click += new System.EventHandler(this.btn_OpenCopyTable_Click);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(251, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(257, 33);
            this.label14.TabIndex = 40;
            this.label14.Text = "COPIAR TABLAS";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.SlateBlue;
            this.panel2.Location = new System.Drawing.Point(2, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1300, 5);
            this.panel2.TabIndex = 42;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.groupBox3.Controls.Add(this.rdbtn_TiposAdmin);
            this.groupBox3.Controls.Add(this.rdbtn_Administrador);
            this.groupBox3.Controls.Add(this.rdbtn_Detalle);
            this.groupBox3.Controls.Add(this.rdbtn_Bitacora);
            this.groupBox3.Controls.Add(this.rdbtn_Usuario);
            this.groupBox3.Controls.Add(this.rdbtn_Descuento);
            this.groupBox3.Controls.Add(this.rdbtn_Ticket);
            this.groupBox3.Controls.Add(this.rdbtn_Producto);
            this.groupBox3.Controls.Add(this.rdbtn_Logins);
            this.groupBox3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(50, 89);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(505, 199);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            // 
            // SuperAdministrador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(785, 506);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn_OpenCopyTable);
            this.Controls.Add(this.pnl_CopiaTablas);
            this.Controls.Add(this.btn_BackupCom);
            this.Controls.Add(this.btn_BackupDif);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btn_Modificar);
            this.Controls.Add(this.txt_Buscar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pic_Foto);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dgv_info);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SuperAdministrador";
            this.Load += new System.EventHandler(this.SuperAdministrador_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_info)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Foto)).EndInit();
            this.pnl_CopiaTablas.ResumeLayout(false);
            this.pnl_CopiaTablas.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_info;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lable7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pic_Foto;
        private System.Windows.Forms.TextBox txt_Contratado;
        private System.Windows.Forms.TextBox txt_Admin;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_Paterno;
        private System.Windows.Forms.TextBox txt_RFC;
        private System.Windows.Forms.TextBox txt_Materno;
        private System.Windows.Forms.TextBox txt_Tipo;
        private System.Windows.Forms.TextBox txt_Login;
        private System.Windows.Forms.TextBox txt_Contra;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Buscar;
        private System.Windows.Forms.Button btn_Modificar;
        private System.Windows.Forms.CheckBox ch_modificar;
        private System.Windows.Forms.OpenFileDialog ofd_FotoAdmin;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox ch_Si;
        private System.Windows.Forms.CheckBox ch_NO;
        private System.Windows.Forms.CheckBox ch_gerente;
        private System.Windows.Forms.CheckBox ch_sa;
        private System.Windows.Forms.CheckBox ch_cajero;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_BackupDif;
        private System.Windows.Forms.Button btn_BackupCom;
        private System.Windows.Forms.Panel pnl_CopiaTablas;
        private System.Windows.Forms.Button btn_CerrarCopiaTabla;
        private System.Windows.Forms.Button btn_CopiarTabla;
        private System.Windows.Forms.RadioButton rdbtn_Usuario;
        private System.Windows.Forms.RadioButton rdbtn_TiposAdmin;
        private System.Windows.Forms.RadioButton rdbtn_Producto;
        private System.Windows.Forms.RadioButton rdbtn_Logins;
        private System.Windows.Forms.RadioButton rdbtn_Ticket;
        private System.Windows.Forms.RadioButton rdbtn_Descuento;
        private System.Windows.Forms.RadioButton rdbtn_Bitacora;
        private System.Windows.Forms.RadioButton rdbtn_Detalle;
        private System.Windows.Forms.RadioButton rdbtn_Administrador;
        private System.Windows.Forms.Button btn_OpenCopyTable;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}