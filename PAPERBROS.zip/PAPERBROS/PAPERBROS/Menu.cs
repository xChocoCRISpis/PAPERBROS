﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.CodeDom.Compiler;
using System.Data.SqlClient;
using System.IO;

namespace PAPERBROS
{
    public partial class Menu : Form
    {
        string TipoAdmin;
        string foto;
        public Menu(string TipoU, string foto, string rfc, string usuario)
        {
            
            InitializeComponent();
            btn_DeleteCliente.Visible = false;
            Diseno();
            if (TipoU == "3")
            {
                lbl_tipo.Text = "CAJERO";
                btn_SA.Visible = false;
                btn_Cobrar.Visible =true;
                btn_bitacora.Visible = false;
                btn_GestionUser.Visible = false;
                btn_Inventario.Visible = false;
                btn_UserClient.Visible = false;
            }
            if (TipoU == "1")
            {
                lbl_tipo.Text = "SUPER ADMINISTRADOR";
                btn_Cobrar.Visible= false;
                btn_UserClient.Visible = false;

            }
            if (TipoU == "2")
            {
                lbl_tipo.Text = "GERENTE";
                btn_SA.Visible = false;
                btn_Cobrar.Visible = false;
                btn_bitacora.Visible = false;
            }

            TipoAdmin = TipoU;
            this.foto = foto;
            lbl_RFC.Text = "RFC: " + rfc;
            lbl_Usuario.Text = "USUARIO: " + usuario;

            pb_Usuario.Image = Image.FromFile(Application.StartupPath + "\\Admins" + foto);

            
        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int IParam);
        public Menu()
        {
            InitializeComponent();
        }

        private void pnl_Titulo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pb_Exit_Click(object sender, EventArgs e)
        {
            this.Dispose();
            this.Close();
        }

        private void pb_Full_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            pb_Full.Visible = false;
            pb_Full.Enabled = false;
            pb_Chico.Visible = true;
            pb_Chico.Enabled = true;
        }

        private void pb_Min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void pb_Chico_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            pb_Full.Visible = true;
            pb_Full.Enabled = true;
            pb_Chico.Visible = false;
            pb_Chico.Enabled = false;
        }

        private void btn_Cobrar_Click(object sender, EventArgs e)
        {
            AbrirForm(new Cobrar(TipoAdmin, foto));
        }

        private void pnl_Titulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        public void AbrirForm(object form)
        {
            if (pnl_Base.Controls.Count > 0)
                this.pnl_Base.Controls.RemoveAt(0);
            Form OpenForm = form as Form;
            OpenForm.TopLevel = false;
            OpenForm.Dock = DockStyle.Fill;
            pnl_Base.Controls.Add(OpenForm);
            pnl_Base.Tag = OpenForm;
            OpenForm.Show();

        }

        private void btn_Stock_Click(object sender, EventArgs e)
        {
            AbrirForm(new LimiteStock());
        }

        private void Menu_Load(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();

            if (con != null)
            {
                try
                {
                    //ALERTA DE STOCK
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_BajaDisponibilidad";

                    com.Parameters.Add("@WARNING", SqlDbType.Bit).Value = 0;
                    com.Parameters["@WARNING"].Direction = ParameterDirection.Output;

                    com.ExecuteNonQuery();
                    con.Close();

                    bool aviso = bool.Parse(com.Parameters["@WARNING"].Value.ToString());

                    if (aviso == true)
                    {
                        pb_Alert.Image = Image.FromFile(Path.Combine(Application.StartupPath, "Resources", "Alert.gif"));
                        pb_Alert.SizeMode = PictureBoxSizeMode.StretchImage;
                        lbl_Stock.Visible = true;
                    }
                    else
                    {
                        pb_Alert.Enabled = false;
                        pb_Alert.Visible = false;
                        lbl_Stock.Visible = false;
                    }
                }
                catch (Exception a)
                {
                    Console.WriteLine(a);
                }


            }
            else
            {
                MessageBox.Show("Sin conexion a la base de datos");
            }

        }

        private void pb_Alert_Click(object sender, EventArgs e)
        {
            AlertaStock alertaStock = new AlertaStock();
            alertaStock.Show();
        }

        private void btn_RegistroCyU_Click(object sender, EventArgs e)
        {
            AbrirForm(new RegistrarAdmin(TipoAdmin, foto));
            Ocultar_Submenu();
        }

        private void btn_DeleteCliente_Click(object sender, EventArgs e)
        {
            AbrirForm(new BorrarUsuario(TipoAdmin, foto));
        }

        private void btn_ventas_Click(object sender, EventArgs e)
        {
            AbrirForm(new Factura(-2, -2, TipoAdmin, foto));
        }

        private void btn_Bodega_Click(object sender, EventArgs e)
        {
            AbrirForm(new Inventario(TipoAdmin, foto));
        }

        private void btn_SA_Click(object sender, EventArgs e)
        {
            AbrirForm(new SuperAdministrador());
            Ocultar_Submenu();
        }

        private void btn_bitacora_Click(object sender, EventArgs e)
        {
            AbrirForm(new Bitacora());
        }

        private void btn_AgregarProd_Click(object sender, EventArgs e)
        {
            AbrirForm(new AgregarProducto(TipoAdmin, foto));
        }

        private void Diseno()
        {
            pnl_SubUser.Visible = false;
            pnl_GesInv.Visible = false;
            pnl_GestClien.Visible = false;
            pnl_GestVentas.Visible = false;
        }

        private void Ocultar_Submenu()
        {
            if(pnl_SubUser.Visible==true)
                pnl_SubUser.Visible=false;
            if(pnl_GesInv.Visible==true)
                pnl_GesInv.Visible=false;
            if(pnl_GestClien.Visible==true)
                pnl_GestClien.Visible=false;
            if(pnl_GestVentas.Visible==true)
                pnl_GestVentas.Visible=false;
        }

        private void Mostrar_Submenu(Panel submenu)
        {
            if(submenu.Visible==false)
            {
                Ocultar_Submenu();
                submenu.Visible=true;
            }
            else
            {
                submenu.Visible=false;
            }
        }

        private void btn_GestionUser_Click(object sender, EventArgs e)
        {
            Mostrar_Submenu(pnl_SubUser);
        }

        private void btn_clientes_Click(object sender, EventArgs e)
        {
            AbrirForm(new RegistrarAdmin(TipoAdmin, foto));
            Ocultar_Submenu();
        }

        private void btn_Inventario_Click(object sender, EventArgs e)
        {
            Mostrar_Submenu(pnl_GesInv);
        }

        private void btn_GestCli_Click(object sender, EventArgs e)
        {
            Mostrar_Submenu(pnl_GestClien);
        }

        private void btn_GestVentas_Click(object sender, EventArgs e)
        {
            Mostrar_Submenu(pnl_GestVentas);
        }

        private void btn_UserClient_Click(object sender, EventArgs e)
        {
            AbrirForm(new Usuarios());
            Ocultar_Submenu();
        }

        private void btn_SuperAdmin_Click(object sender, EventArgs e)
        {
            AbrirForm(new SuperAdministrador());
        }
    }
}
