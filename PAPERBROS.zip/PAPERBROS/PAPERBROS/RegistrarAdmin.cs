﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;
using QRCoder;
using System.Diagnostics;
using PAPERBROS.Properties;

using AForge.Video;
using AForge.Video.DirectShow;
using System.Media;

namespace PAPERBROS
{
    public partial class RegistrarAdmin : Form
    {
        //Captura video
        private FilterInfoCollection CaptureDevice;
        private VideoCaptureDevice FinalFrame;
        //Atributos
        string TipoAdmin;
        int tipo_registro;
        public string ruta, path;
        bool foto = false;
        string reg;
        string imagen;
        public RegistrarAdmin(string TipoAdmin,string imagen)
        {
            InitializeComponent();
            rdbtn_Admin.Checked = false;
            rdbtn_Usuario.Checked = false;
            this.TipoAdmin = TipoAdmin;
            this.imagen = imagen;
            btn_Open_foto.Visible=false;
           
        }

        private void rdbtn_Usuario_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Usuario.Checked == true)
            {
                txt_Registro1.Enabled = true;
                lbl_Registro1.Text = "Apellido paterno:";
                txt_Registro2.Enabled = true;
                lbl_Registro2.Text = "Apellido materno:";
                txt_Registro3.Enabled = true;
                lbl_Registro3.Text = "Nombre(s):";
                txt_Registro4.Enabled = true;
                lbl_Registro4.Text = "RFC: ";
                txt_Registro5.Enabled = false;
                txt_Registro5.Text = null;
                lbl_Registro5.Text = "---";
                txt_Registro6.Enabled = false;
                txt_Registro6.Text = null;
                lbl_Registro6.Text = "---";
                txt_Registro7.Enabled = false;
                txt_Registro7.Text = null;
                lbl_Registro7.Text = "---";
                pictureBox1.Enabled = false;
                pictureBox1.Visible = false;

                if (rdbtn_Usuario.Checked == true)
                    btn_Open_foto.Visible = false;
                else
                    btn_Open_foto.Visible = true;

                tipo_registro = 0;
            }
        }

        private void rdbtn_Admin_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Admin.Checked == true)
            {
                txt_Registro1.Enabled = true;
                lbl_Registro1.Text = "Apellido paterno:";
                txt_Registro2.Enabled = true;
                lbl_Registro2.Text = "Apellido materno:";
                txt_Registro3.Enabled = true;
                lbl_Registro3.Text = "Nombre(s):";
                txt_Registro4.Enabled = true;
                lbl_Registro4.Text = "RFC:";
                txt_Registro5.Enabled = true;
                lbl_Registro5.Text = "Usuario:";
                txt_Registro6.Enabled = true;
                lbl_Registro6.Text = "Contraseña: ";
                txt_Registro7.Enabled = true;
                lbl_Registro7.Text = "Confirmación contraseña: ";
                pictureBox1.Visible = true;

                tipo_registro = 1;
                ColorFondoImagen();
            }
            if (txt_Registro4.Text == "")
            {
                btn_Open_foto.Visible = false;
            }
            else
                btn_Open_foto.Visible = true;
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Opciones Opciones = new Opciones(TipoAdmin,imagen);
            Opciones.Show();
        }

        private void btn_Registrar_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();


            if (con != null)
            {
                SqlCommand com = new SqlCommand();
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;

                //registar usaurio

                if (rdbtn_Usuario.Checked == true)
                {
                    com.CommandText = "sp_AltaUsuario";
                    com.Parameters.Clear();
                    try
                    {
                        //com.Parameters.Add("@NOMBRE", SqlDbType.VarChar, 70).Value = txt_Nombre.Text;

                        com.Parameters.Add("@ApPaterno", SqlDbType.VarChar, 35).Value = txt_Registro1.Text;
                        com.Parameters.Add("@ApMaterno", SqlDbType.VarChar, 35).Value = txt_Registro2.Text;
                        com.Parameters.Add("@Nombre", SqlDbType.VarChar, 35).Value = txt_Registro3.Text;
                        com.Parameters.Add("@TipoUsuario", SqlDbType.Int).Value = 1;
                        com.Parameters.Add("@RFC", SqlDbType.VarChar, 35).Value = txt_Registro4.Text;
                        com.Parameters.Add("@Puntos", SqlDbType.Int).Value = 0;
                        int a = com.ExecuteNonQuery();

                        if (a > 0)
                        {
                            MessageBox.Show("Usuario dado de alta exitosamente");
                            txt_Registro1.Text = null;
                            txt_Registro2.Text = null;
                            txt_Registro3.Text = null;
                            txt_Registro4.Text = null;
                            SoundPlayer player = new SoundPlayer();
                            player.SoundLocation = @"Audio\NuevoUser.wav";
                            player.Play();
                            player.Dispose();

                        }
                        else
                        {
                            MessageBox.Show("Usuario no se dió de alta");
                        }



                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }





                    //llamar a sp_nuevoadmin
                }

                else 
                {
                    SqlCommand oa = new SqlCommand();
                    oa.Connection = con;
                    oa.CommandType = CommandType.StoredProcedure;

                    //Registrar administrador
                    if (tipo_registro > 0 && tipo_registro <= 3)
                    {
                        if (txt_Registro6.Text != null && txt_Registro6.Text == txt_Registro7.Text)
                        {
                           oa.CommandText = "sp_NuevoAdmin";
                           oa.Parameters.Clear();

                            ruta = Application.StartupPath + @"\Admins\" + reg + ".jpg";
                            path = Path.GetFileName(ruta);

                            /*
                              @NOMBRE VARCHAR(50),
                                @PATERNO VARCHAR(50),
                                @MATERNO VARCHAR(50),
                                @RFC VARCHAR(15),
                                @TIPO_ADMIN INT,
                                @IMAGEN VARCHAR(MAX),
                                @USUARIO VARCHAR(50),
                                @CONTRA VARCHAR(50)

                             */

                            if (foto == false)
                            {
                                ruta = Application.StartupPath + @"\Admins\Default.jpg";
                                path = Path.GetFileName(ruta);
                            }

                            Console.WriteLine("foto= " + foto);
                                Console.WriteLine("path= " + path);
                                oa.Parameters.Add("@NOMBRE", SqlDbType.VarChar, 50).Value = txt_Registro3.Text;
                                oa.Parameters.Add("@PATERNO", SqlDbType.VarChar, 50).Value = txt_Registro1.Text;
                                oa.Parameters.Add("@MATERNO", SqlDbType.VarChar, 50).Value = txt_Registro2.Text;
                                oa.Parameters.Add("@RFC", SqlDbType.VarChar,15).Value = txt_Registro4.Text;
                                oa.Parameters.Add("@TIPO_ADMIN", SqlDbType.Int).Value = tipo_registro;
                                oa.Parameters.Add("@IMAGEN", SqlDbType.VarChar).Value = "\\" + path;
                                oa.Parameters.Add("@USUARIO", SqlDbType.VarChar,50).Value = txt_Registro5.Text;
                                oa.Parameters.Add("@CONTRA", SqlDbType.VarChar, 50).Value = txt_Registro6.Text;

                                oa.Parameters.Add("@EXIST", SqlDbType.Bit).Value = 0;
                                oa.Parameters["@EXIST"].Direction = ParameterDirection.Output;
                                oa.Parameters.Add("@EXIST_LOG", SqlDbType.Bit).Value = 0;
                                oa.Parameters["@EXIST_LOG"].Direction = ParameterDirection.Output;

                                int a = oa.ExecuteNonQuery();
                                con.Close();
                                bool e_admin= bool.Parse(oa.Parameters["@EXIST"].Value.ToString());
                                bool e_user= bool.Parse(oa.Parameters["@EXIST_LOG"].Value.ToString());

                            QR_Generator(txt_Registro4.Text, txt_Registro5.Text);


                                if (a > 0)
                                    if (e_admin == true)
                                    {
                                        MessageBox.Show("Persona ya existente");
                                        if (e_user == true)
                                        {

                                            MessageBox.Show("Inicio de sesión ya existente");
                                        }
                                    }
                                    else
                                    {
                                        if (e_user == false)
                                        {
                                            MessageBox.Show("Dado de alta");
                                            txt_Registro1.Text = null;
                                            txt_Registro2.Text = null;
                                            txt_Registro3.Text = null;
                                            txt_Registro4.Text = null;
                                            txt_Registro5.Text = null;
                                            txt_Registro6.Text = null;
                                            txt_Registro7.Text = null;
                                            foto = false;
                                            pictureBox1.Refresh();
                                            SoundPlayer player = new SoundPlayer();
                                            player.SoundLocation = @"Audio\NuevoUser.wav";
                                            player.Play();
                                            player.Dispose();

                                        }
                                           
                                    }
                                else
                                {
                                    MessageBox.Show("No se pudo dar de alta");
                                }

                        }
                        else 
                        {
                            MessageBox.Show("Verifica que las contraseñas coincidan");
                        }
                       
                    }
                    else
                    {
                        MessageBox.Show("Error en la conexion, intenta mas tarde");
                    }
                }
            }
            else
            {
                MessageBox.Show("son conexión a la base de datos");
            }

        }

        private void rd_Empleado_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_Empleado.Checked == true)
            {
                txt_Registro1.Enabled = true;
                lbl_Registro1.Text = "Apellido paterno:";
                txt_Registro2.Enabled = true;
                lbl_Registro2.Text = "Apellido materno:";
                txt_Registro3.Enabled = true;
                lbl_Registro3.Text = "Nombre(s):";
                txt_Registro4.Enabled = true;
                lbl_Registro4.Text = "RFC:";
                txt_Registro5.Enabled = true;
                lbl_Registro5.Text = "Usuario:";
                txt_Registro6.Enabled = true;
                lbl_Registro6.Text = "Contraseña: ";
                txt_Registro7.Enabled = true;
                lbl_Registro7.Text = "Confirmación contraseña: ";
                pictureBox1.Visible = true;

                tipo_registro = 3;
                ColorFondoImagen();
            }
            if (txt_Registro4.Text == "")
            {
                btn_Open_foto.Visible = false;
            }
            else
                btn_Open_foto.Visible = true;
        }

        private void rd_Gerente_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_Gerente.Checked == true)
            {
                txt_Registro1.Enabled = true;
                lbl_Registro1.Text = "Apellido paterno:";
                txt_Registro2.Enabled = true;
                lbl_Registro2.Text = "Apellido materno:";
                txt_Registro3.Enabled = true;
                lbl_Registro3.Text = "Nombre(s):";
                txt_Registro4.Enabled = true;
                lbl_Registro4.Text = "RFC:";
                txt_Registro5.Enabled = true;
                lbl_Registro5.Text = "Usuario:";
                txt_Registro6.Enabled = true;
                lbl_Registro6.Text = "Contraseña: ";
                txt_Registro7.Enabled = true;
                lbl_Registro7.Text = "Confirmación contraseña: ";
                pictureBox1.Visible = true;

                tipo_registro = 2;
                ColorFondoImagen();
            }
            if (txt_Registro4.Text == "")
            {
                btn_Open_foto.Visible = false;
            }
            else
                btn_Open_foto.Visible = true;
        }

        private void RegistrarAdmin_Load(object sender, EventArgs e)
        {
            pictureBox1.Enabled = false;
            pictureBox1.BackColor = Color.FromArgb(41, 41, 46);
            pictureBox1.Image = null;

            switch (TipoAdmin)
            {
                case "1":
                    rdbtn_Admin.Enabled = true;
                    rdbtn_Usuario.Enabled = true;
                    rd_Empleado.Enabled = true;
                    rd_Gerente.Enabled = true;
                    break;
                case "2":
                    rdbtn_Usuario.Enabled = true;
                    rd_Empleado.Enabled = true;
                    rd_Gerente.Enabled = true;
                    break;
                case "3":
                    rdbtn_Usuario.Enabled = true;
                    break;
            }
        }

        private void txt_Registro4_TextChanged(object sender, EventArgs e)
        {
            ColorFondoImagen();
            if(txt_Registro4.Text=="" && txt_Registro4!=null)
            {
                btn_Open_foto.Visible = false;
            }
            else
                btn_Open_foto.Visible = true;
            if (rdbtn_Usuario.Checked==true)
                btn_Open_foto.Visible = false;


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {


            if (ofd_FotoAdmin.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                try
                {
                    ruta = ofd_FotoAdmin.FileName;
                    pictureBox1.Image = Image.FromFile(ruta);
                    pictureBox1.Image.Save(Application.StartupPath + "\\Admins\\" + reg + ".jpg", ImageFormat.Jpeg);
                    this.ruta = ofd_FotoAdmin.FileName;
                    foto = true;

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);

                    MessageBox.Show("Formato de imagen incorrecto, solo se acepta JPGE");
                }
            }

        }

        private void ColorFondoImagen()
        {
            if (txt_Registro4.Text != null)
            {
                
                this.reg = txt_Registro4.Text;
                pictureBox1.Enabled = true;
                pictureBox1.Image = PAPERBROS.Properties.Resources.PollosHermanos;
                lbl_Aviso.Visible = false;
                btn_Open_foto.Visible = true;
            }
            else
            {
                pictureBox1.Enabled = false;
                pictureBox1.BackColor = Color.DarkGray;
                pictureBox1.Image = null;
                lbl_Aviso.Visible = true;
                btn_Open_foto.Visible = false;
            }
            if (txt_Registro4.Text == "")
            {
                pictureBox1.Enabled = false;
                pictureBox1.BackColor = Color.DarkGray;
                pictureBox1.Image = null;
                lbl_Aviso.Visible = true;
                btn_Open_foto.Visible = false;
            }

            if (rdbtn_Usuario.Checked == true)
                btn_Open_foto.Visible = false;
            else
                btn_Open_foto.Visible = true;
        }

        private void btn_Open_foto_Click(object sender, EventArgs e)
        {
            pnl_foto.Visible = true;
            btn_Open_foto.Visible = false;

            CaptureDevice = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo Device in CaptureDevice)
            {
                cmb_Camara.Items.Add(Device.Name);
            }

            cmb_Camara.SelectedIndex = 0;
            FinalFrame = new VideoCaptureDevice();
        }

        private void txt_QR_Click(object sender, EventArgs e)
        {
            FinalFrame.Stop();
            btn_tomar_foto.Enabled = true;
            FinalFrame = new VideoCaptureDevice(CaptureDevice[cmb_Camara.SelectedIndex].MonikerString);
            FinalFrame.NewFrame += new NewFrameEventHandler(FinalFrame_NewFrame);
            FinalFrame.Start();
        }
        private void FinalFrame_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pb_foto.Image = (Bitmap)eventArgs.Frame.Clone();
        }

        private void btn_tomar_foto_Click(object sender, EventArgs e)
        {
            string folderPath = Path.Combine(Application.StartupPath, "Admins");
            string fileName = txt_Registro4.Text + ".jpg";
            string filePath = Path.Combine(folderPath, fileName);

            pb_foto.Image.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);
            pictureBox1.Image = Image.FromFile(filePath);
            foto = true;

            pnl_foto.Visible = false;
            FinalFrame.Stop();

            
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            pnl_foto.Visible = false;
            btn_Open_foto.Visible = true;
            FinalFrame.Stop();
        }

        private void QR_Generator(string RFC, string Login)
        {
            string content = txt_Registro4.Text + txt_Registro5.Text + txt_Registro6.Text;
            QRCodeGenerator QRG = new QRCodeGenerator();
            QRCodeData QRD = QRG.CreateQrCode(content, QRCodeGenerator.ECCLevel.H);
            QRCode QRC = new QRCode(QRD);

            Bitmap QR_img = QRC.GetGraphic(5, Color.Black, Color.White, (Bitmap)Bitmap.FromFile("Resources/PollosHermanos.jpg"));

            string folderPath = Path.Combine(Application.StartupPath, "QR_User");
            string fileName = RFC + ".png";
            string filePath = Path.Combine(folderPath, fileName);
            
            QR_img.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);

            SqlConnection con = Conexion.CadenaConexion();

            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandType = CommandType.Text;
            //Application.StartupPath + @"\Admins\" + reg + ".jpg";
            string rute = Application.StartupPath + @"\QR_User\" + RFC + ".png";
            string path = Path.GetFileName(rute);

            SqlCommand qr = new SqlCommand();
            com.Connection = con;
            com.CommandType = CommandType.Text;
            com.CommandText = "UPDATE LOGINS SET QR='" + "\\"+path+"' FROM LOGINS INNER JOIN ADMINISTRADOR ON Id_ADMINISTRADOR=Id_ADMINISTRADOR_FK WHERE ADMINISTRADOR.RFC='"+RFC+"' AND NombreLog = '"+Login+"'";

            qr.Connection = con;
            qr.CommandType = CommandType.Text;
            qr.CommandText = "UPDATE LOGINS SET QR_INFO='" +content+ "' FROM LOGINS INNER JOIN ADMINISTRADOR ON Id_ADMINISTRADOR=Id_ADMINISTRADOR_FK WHERE ADMINISTRADOR.RFC='" + RFC + "' AND NombreLog = '" + Login + "'";

            com.ExecuteNonQuery();
            com.Parameters.Clear();
            qr.ExecuteNonQuery();
            qr.Parameters.Clear();
            con.Close();
            
        }
    }
}
