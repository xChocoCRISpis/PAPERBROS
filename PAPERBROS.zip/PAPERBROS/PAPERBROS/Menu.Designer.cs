﻿namespace PAPERBROS
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.pnl_opciones = new System.Windows.Forms.Panel();
            this.btn_bitacora = new System.Windows.Forms.Button();
            this.pnl_GestVentas = new System.Windows.Forms.Panel();
            this.btn_ventas = new System.Windows.Forms.Button();
            this.btn_GestVentas = new System.Windows.Forms.Button();
            this.pnl_GestClien = new System.Windows.Forms.Panel();
            this.btn_clientes = new System.Windows.Forms.Button();
            this.btn_DeleteCliente = new System.Windows.Forms.Button();
            this.btn_GestCli = new System.Windows.Forms.Button();
            this.pnl_GesInv = new System.Windows.Forms.Panel();
            this.btn_Bodega = new System.Windows.Forms.Button();
            this.btn_Stock = new System.Windows.Forms.Button();
            this.btn_AgregarProd = new System.Windows.Forms.Button();
            this.btn_Inventario = new System.Windows.Forms.Button();
            this.pnl_SubUser = new System.Windows.Forms.Panel();
            this.btn_UserClient = new System.Windows.Forms.Button();
            this.btn_SA = new System.Windows.Forms.Button();
            this.btn_RegistroCyU = new System.Windows.Forms.Button();
            this.btn_GestionUser = new System.Windows.Forms.Button();
            this.btn_Cobrar = new System.Windows.Forms.Button();
            this.pnl_Foto = new System.Windows.Forms.Panel();
            this.pb_Usuario = new System.Windows.Forms.PictureBox();
            this.lbl_tipo = new System.Windows.Forms.Label();
            this.lbl_Usuario = new System.Windows.Forms.Label();
            this.lbl_RFC = new System.Windows.Forms.Label();
            this.pnl_Base = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnl_Titulo = new System.Windows.Forms.Panel();
            this.lbl_Stock = new System.Windows.Forms.Label();
            this.pb_Alert = new System.Windows.Forms.PictureBox();
            this.pb_Chico = new System.Windows.Forms.PictureBox();
            this.pb_Min = new System.Windows.Forms.PictureBox();
            this.pb_Full = new System.Windows.Forms.PictureBox();
            this.pb_Exit = new System.Windows.Forms.PictureBox();
            this.btn_SuperAdmin = new System.Windows.Forms.Button();
            this.pnl_opciones.SuspendLayout();
            this.pnl_GestVentas.SuspendLayout();
            this.pnl_GestClien.SuspendLayout();
            this.pnl_GesInv.SuspendLayout();
            this.pnl_SubUser.SuspendLayout();
            this.pnl_Foto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Usuario)).BeginInit();
            this.pnl_Titulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Alert)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Chico)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Full)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_opciones
            // 
            this.pnl_opciones.AutoScroll = true;
            this.pnl_opciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnl_opciones.Controls.Add(this.btn_SuperAdmin);
            this.pnl_opciones.Controls.Add(this.btn_bitacora);
            this.pnl_opciones.Controls.Add(this.pnl_GestVentas);
            this.pnl_opciones.Controls.Add(this.btn_GestVentas);
            this.pnl_opciones.Controls.Add(this.pnl_GestClien);
            this.pnl_opciones.Controls.Add(this.btn_GestCli);
            this.pnl_opciones.Controls.Add(this.pnl_GesInv);
            this.pnl_opciones.Controls.Add(this.btn_Inventario);
            this.pnl_opciones.Controls.Add(this.pnl_SubUser);
            this.pnl_opciones.Controls.Add(this.btn_GestionUser);
            this.pnl_opciones.Controls.Add(this.btn_Cobrar);
            this.pnl_opciones.Controls.Add(this.pnl_Foto);
            this.pnl_opciones.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_opciones.Location = new System.Drawing.Point(0, 34);
            this.pnl_opciones.Name = "pnl_opciones";
            this.pnl_opciones.Size = new System.Drawing.Size(194, 616);
            this.pnl_opciones.TabIndex = 1;
            // 
            // btn_bitacora
            // 
            this.btn_bitacora.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_bitacora.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_bitacora.FlatAppearance.BorderSize = 0;
            this.btn_bitacora.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_bitacora.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_bitacora.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bitacora.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btn_bitacora.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_bitacora.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_bitacora.Location = new System.Drawing.Point(0, 795);
            this.btn_bitacora.Name = "btn_bitacora";
            this.btn_bitacora.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_bitacora.Size = new System.Drawing.Size(177, 41);
            this.btn_bitacora.TabIndex = 4;
            this.btn_bitacora.Text = "Bitácora";
            this.btn_bitacora.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_bitacora.UseVisualStyleBackColor = true;
            this.btn_bitacora.Click += new System.EventHandler(this.btn_bitacora_Click);
            // 
            // pnl_GestVentas
            // 
            this.pnl_GestVentas.BackColor = System.Drawing.Color.SlateBlue;
            this.pnl_GestVentas.Controls.Add(this.btn_ventas);
            this.pnl_GestVentas.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_GestVentas.Location = new System.Drawing.Point(0, 736);
            this.pnl_GestVentas.Name = "pnl_GestVentas";
            this.pnl_GestVentas.Size = new System.Drawing.Size(177, 59);
            this.pnl_GestVentas.TabIndex = 11;
            // 
            // btn_ventas
            // 
            this.btn_ventas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_ventas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ventas.FlatAppearance.BorderSize = 0;
            this.btn_ventas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_ventas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_ventas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ventas.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btn_ventas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ventas.Location = new System.Drawing.Point(0, 0);
            this.btn_ventas.Name = "btn_ventas";
            this.btn_ventas.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_ventas.Size = new System.Drawing.Size(177, 41);
            this.btn_ventas.TabIndex = 4;
            this.btn_ventas.Text = "Gestión ventas y tickets";
            this.btn_ventas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ventas.UseVisualStyleBackColor = true;
            this.btn_ventas.Click += new System.EventHandler(this.btn_ventas_Click);
            // 
            // btn_GestVentas
            // 
            this.btn_GestVentas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_GestVentas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_GestVentas.FlatAppearance.BorderSize = 0;
            this.btn_GestVentas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_GestVentas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_GestVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_GestVentas.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GestVentas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_GestVentas.Location = new System.Drawing.Point(0, 701);
            this.btn_GestVentas.Name = "btn_GestVentas";
            this.btn_GestVentas.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_GestVentas.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_GestVentas.Size = new System.Drawing.Size(177, 35);
            this.btn_GestVentas.TabIndex = 10;
            this.btn_GestVentas.Text = "Gestión de ventas";
            this.btn_GestVentas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GestVentas.UseVisualStyleBackColor = true;
            this.btn_GestVentas.Click += new System.EventHandler(this.btn_GestVentas_Click);
            // 
            // pnl_GestClien
            // 
            this.pnl_GestClien.BackColor = System.Drawing.Color.SlateBlue;
            this.pnl_GestClien.Controls.Add(this.btn_clientes);
            this.pnl_GestClien.Controls.Add(this.btn_DeleteCliente);
            this.pnl_GestClien.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_GestClien.Location = new System.Drawing.Point(0, 599);
            this.pnl_GestClien.Name = "pnl_GestClien";
            this.pnl_GestClien.Size = new System.Drawing.Size(177, 102);
            this.pnl_GestClien.TabIndex = 7;
            // 
            // btn_clientes
            // 
            this.btn_clientes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_clientes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_clientes.FlatAppearance.BorderSize = 0;
            this.btn_clientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_clientes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_clientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clientes.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clientes.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_clientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_clientes.Location = new System.Drawing.Point(0, 41);
            this.btn_clientes.Name = "btn_clientes";
            this.btn_clientes.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_clientes.Size = new System.Drawing.Size(177, 41);
            this.btn_clientes.TabIndex = 5;
            this.btn_clientes.Text = "Registrar clientes y/o usuarios";
            this.btn_clientes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_clientes.UseVisualStyleBackColor = true;
            this.btn_clientes.Click += new System.EventHandler(this.btn_clientes_Click);
            // 
            // btn_DeleteCliente
            // 
            this.btn_DeleteCliente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_DeleteCliente.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_DeleteCliente.FlatAppearance.BorderSize = 0;
            this.btn_DeleteCliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_DeleteCliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_DeleteCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_DeleteCliente.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DeleteCliente.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_DeleteCliente.Location = new System.Drawing.Point(0, 0);
            this.btn_DeleteCliente.Name = "btn_DeleteCliente";
            this.btn_DeleteCliente.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_DeleteCliente.Size = new System.Drawing.Size(177, 41);
            this.btn_DeleteCliente.TabIndex = 4;
            this.btn_DeleteCliente.Text = "Eliminar cliente";
            this.btn_DeleteCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_DeleteCliente.UseVisualStyleBackColor = true;
            this.btn_DeleteCliente.Click += new System.EventHandler(this.btn_DeleteCliente_Click);
            // 
            // btn_GestCli
            // 
            this.btn_GestCli.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_GestCli.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_GestCli.FlatAppearance.BorderSize = 0;
            this.btn_GestCli.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_GestCli.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_GestCli.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_GestCli.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GestCli.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_GestCli.Location = new System.Drawing.Point(0, 564);
            this.btn_GestCli.Name = "btn_GestCli";
            this.btn_GestCli.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_GestCli.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_GestCli.Size = new System.Drawing.Size(177, 35);
            this.btn_GestCli.TabIndex = 9;
            this.btn_GestCli.Text = "Gestión de clientes";
            this.btn_GestCli.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GestCli.UseVisualStyleBackColor = true;
            this.btn_GestCli.Click += new System.EventHandler(this.btn_GestCli_Click);
            // 
            // pnl_GesInv
            // 
            this.pnl_GesInv.BackColor = System.Drawing.Color.SlateBlue;
            this.pnl_GesInv.Controls.Add(this.btn_Bodega);
            this.pnl_GesInv.Controls.Add(this.btn_Stock);
            this.pnl_GesInv.Controls.Add(this.btn_AgregarProd);
            this.pnl_GesInv.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_GesInv.Location = new System.Drawing.Point(0, 444);
            this.pnl_GesInv.Name = "pnl_GesInv";
            this.pnl_GesInv.Size = new System.Drawing.Size(177, 120);
            this.pnl_GesInv.TabIndex = 0;
            // 
            // btn_Bodega
            // 
            this.btn_Bodega.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Bodega.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Bodega.FlatAppearance.BorderSize = 0;
            this.btn_Bodega.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_Bodega.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_Bodega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Bodega.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Bodega.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Bodega.Location = new System.Drawing.Point(0, 71);
            this.btn_Bodega.Name = "btn_Bodega";
            this.btn_Bodega.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Bodega.Size = new System.Drawing.Size(177, 37);
            this.btn_Bodega.TabIndex = 4;
            this.btn_Bodega.Text = "Bodega";
            this.btn_Bodega.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Bodega.UseVisualStyleBackColor = true;
            this.btn_Bodega.Click += new System.EventHandler(this.btn_Bodega_Click);
            // 
            // btn_Stock
            // 
            this.btn_Stock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Stock.FlatAppearance.BorderSize = 0;
            this.btn_Stock.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_Stock.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_Stock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Stock.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Stock.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Stock.Location = new System.Drawing.Point(0, 36);
            this.btn_Stock.Name = "btn_Stock";
            this.btn_Stock.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Stock.Size = new System.Drawing.Size(177, 35);
            this.btn_Stock.TabIndex = 2;
            this.btn_Stock.Text = "Stock";
            this.btn_Stock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Stock.UseVisualStyleBackColor = true;
            this.btn_Stock.Click += new System.EventHandler(this.btn_Stock_Click);
            // 
            // btn_AgregarProd
            // 
            this.btn_AgregarProd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_AgregarProd.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AgregarProd.FlatAppearance.BorderSize = 0;
            this.btn_AgregarProd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_AgregarProd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_AgregarProd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AgregarProd.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btn_AgregarProd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_AgregarProd.Location = new System.Drawing.Point(0, 0);
            this.btn_AgregarProd.Name = "btn_AgregarProd";
            this.btn_AgregarProd.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AgregarProd.Size = new System.Drawing.Size(177, 36);
            this.btn_AgregarProd.TabIndex = 6;
            this.btn_AgregarProd.Text = "Agregar producto";
            this.btn_AgregarProd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AgregarProd.UseVisualStyleBackColor = true;
            this.btn_AgregarProd.Click += new System.EventHandler(this.btn_AgregarProd_Click);
            // 
            // btn_Inventario
            // 
            this.btn_Inventario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_Inventario.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Inventario.FlatAppearance.BorderSize = 0;
            this.btn_Inventario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_Inventario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_Inventario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Inventario.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Inventario.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Inventario.Location = new System.Drawing.Point(0, 401);
            this.btn_Inventario.Name = "btn_Inventario";
            this.btn_Inventario.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Inventario.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_Inventario.Size = new System.Drawing.Size(177, 43);
            this.btn_Inventario.TabIndex = 8;
            this.btn_Inventario.Text = "Gestión de inventario";
            this.btn_Inventario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Inventario.UseVisualStyleBackColor = true;
            this.btn_Inventario.Click += new System.EventHandler(this.btn_Inventario_Click);
            // 
            // pnl_SubUser
            // 
            this.pnl_SubUser.BackColor = System.Drawing.Color.SlateBlue;
            this.pnl_SubUser.Controls.Add(this.btn_UserClient);
            this.pnl_SubUser.Controls.Add(this.btn_SA);
            this.pnl_SubUser.Controls.Add(this.btn_RegistroCyU);
            this.pnl_SubUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_SubUser.Location = new System.Drawing.Point(0, 253);
            this.pnl_SubUser.Name = "pnl_SubUser";
            this.pnl_SubUser.Size = new System.Drawing.Size(177, 148);
            this.pnl_SubUser.TabIndex = 0;
            // 
            // btn_UserClient
            // 
            this.btn_UserClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_UserClient.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_UserClient.FlatAppearance.BorderSize = 0;
            this.btn_UserClient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_UserClient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_UserClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UserClient.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btn_UserClient.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_UserClient.Location = new System.Drawing.Point(0, 91);
            this.btn_UserClient.Name = "btn_UserClient";
            this.btn_UserClient.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_UserClient.Size = new System.Drawing.Size(177, 50);
            this.btn_UserClient.TabIndex = 5;
            this.btn_UserClient.Text = "Gestión de clientes y/o usuarios";
            this.btn_UserClient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_UserClient.UseVisualStyleBackColor = true;
            this.btn_UserClient.Click += new System.EventHandler(this.btn_UserClient_Click);
            // 
            // btn_SA
            // 
            this.btn_SA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_SA.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_SA.FlatAppearance.BorderSize = 0;
            this.btn_SA.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_SA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_SA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SA.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.btn_SA.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_SA.Location = new System.Drawing.Point(0, 41);
            this.btn_SA.Name = "btn_SA";
            this.btn_SA.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_SA.Size = new System.Drawing.Size(177, 50);
            this.btn_SA.TabIndex = 4;
            this.btn_SA.Text = "Super administrador";
            this.btn_SA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_SA.UseVisualStyleBackColor = true;
            this.btn_SA.Click += new System.EventHandler(this.btn_SA_Click);
            // 
            // btn_RegistroCyU
            // 
            this.btn_RegistroCyU.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_RegistroCyU.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_RegistroCyU.FlatAppearance.BorderSize = 0;
            this.btn_RegistroCyU.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_RegistroCyU.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(100)))), ((int)(((byte)(186)))));
            this.btn_RegistroCyU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_RegistroCyU.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RegistroCyU.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_RegistroCyU.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_RegistroCyU.Location = new System.Drawing.Point(0, 0);
            this.btn_RegistroCyU.Name = "btn_RegistroCyU";
            this.btn_RegistroCyU.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_RegistroCyU.Size = new System.Drawing.Size(177, 41);
            this.btn_RegistroCyU.TabIndex = 4;
            this.btn_RegistroCyU.Text = "Registrar clientes y/o usuarios";
            this.btn_RegistroCyU.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_RegistroCyU.UseVisualStyleBackColor = true;
            this.btn_RegistroCyU.Click += new System.EventHandler(this.btn_RegistroCyU_Click);
            // 
            // btn_GestionUser
            // 
            this.btn_GestionUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_GestionUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_GestionUser.FlatAppearance.BorderSize = 0;
            this.btn_GestionUser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_GestionUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_GestionUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_GestionUser.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GestionUser.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_GestionUser.Location = new System.Drawing.Point(0, 218);
            this.btn_GestionUser.Name = "btn_GestionUser";
            this.btn_GestionUser.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_GestionUser.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_GestionUser.Size = new System.Drawing.Size(177, 35);
            this.btn_GestionUser.TabIndex = 7;
            this.btn_GestionUser.Text = "Gestión de usuarios";
            this.btn_GestionUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_GestionUser.UseVisualStyleBackColor = true;
            this.btn_GestionUser.Click += new System.EventHandler(this.btn_GestionUser_Click);
            // 
            // btn_Cobrar
            // 
            this.btn_Cobrar.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Cobrar.FlatAppearance.BorderSize = 0;
            this.btn_Cobrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_Cobrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_Cobrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cobrar.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cobrar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Cobrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Cobrar.Location = new System.Drawing.Point(0, 183);
            this.btn_Cobrar.Name = "btn_Cobrar";
            this.btn_Cobrar.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_Cobrar.Size = new System.Drawing.Size(177, 35);
            this.btn_Cobrar.TabIndex = 0;
            this.btn_Cobrar.Text = "Cobrar";
            this.btn_Cobrar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Cobrar.UseVisualStyleBackColor = true;
            this.btn_Cobrar.Click += new System.EventHandler(this.btn_Cobrar_Click);
            // 
            // pnl_Foto
            // 
            this.pnl_Foto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.pnl_Foto.Controls.Add(this.pb_Usuario);
            this.pnl_Foto.Controls.Add(this.lbl_tipo);
            this.pnl_Foto.Controls.Add(this.lbl_Usuario);
            this.pnl_Foto.Controls.Add(this.lbl_RFC);
            this.pnl_Foto.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Foto.Location = new System.Drawing.Point(0, 0);
            this.pnl_Foto.Name = "pnl_Foto";
            this.pnl_Foto.Size = new System.Drawing.Size(177, 183);
            this.pnl_Foto.TabIndex = 0;
            // 
            // pb_Usuario
            // 
            this.pb_Usuario.Location = new System.Drawing.Point(40, 25);
            this.pb_Usuario.Name = "pb_Usuario";
            this.pb_Usuario.Size = new System.Drawing.Size(100, 107);
            this.pb_Usuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Usuario.TabIndex = 0;
            this.pb_Usuario.TabStop = false;
            // 
            // lbl_tipo
            // 
            this.lbl_tipo.AutoSize = true;
            this.lbl_tipo.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_tipo.Location = new System.Drawing.Point(9, 11);
            this.lbl_tipo.Name = "lbl_tipo";
            this.lbl_tipo.Size = new System.Drawing.Size(10, 13);
            this.lbl_tipo.TabIndex = 4;
            this.lbl_tipo.Text = "-";
            // 
            // lbl_Usuario
            // 
            this.lbl_Usuario.AutoSize = true;
            this.lbl_Usuario.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_Usuario.Location = new System.Drawing.Point(6, 135);
            this.lbl_Usuario.Name = "lbl_Usuario";
            this.lbl_Usuario.Size = new System.Drawing.Size(49, 13);
            this.lbl_Usuario.TabIndex = 0;
            this.lbl_Usuario.Text = "Usuario: ";
            // 
            // lbl_RFC
            // 
            this.lbl_RFC.AutoSize = true;
            this.lbl_RFC.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl_RFC.Location = new System.Drawing.Point(9, 159);
            this.lbl_RFC.Name = "lbl_RFC";
            this.lbl_RFC.Size = new System.Drawing.Size(31, 13);
            this.lbl_RFC.TabIndex = 3;
            this.lbl_RFC.Text = "RFC:";
            // 
            // pnl_Base
            // 
            this.pnl_Base.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.pnl_Base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Base.Location = new System.Drawing.Point(194, 34);
            this.pnl_Base.Name = "pnl_Base";
            this.pnl_Base.Size = new System.Drawing.Size(1106, 616);
            this.pnl_Base.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.SlateBlue;
            this.panel2.Location = new System.Drawing.Point(-1, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1300, 5);
            this.panel2.TabIndex = 2;
            // 
            // pnl_Titulo
            // 
            this.pnl_Titulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.pnl_Titulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Titulo.Controls.Add(this.lbl_Stock);
            this.pnl_Titulo.Controls.Add(this.panel2);
            this.pnl_Titulo.Controls.Add(this.pb_Alert);
            this.pnl_Titulo.Controls.Add(this.pb_Chico);
            this.pnl_Titulo.Controls.Add(this.pb_Min);
            this.pnl_Titulo.Controls.Add(this.pb_Full);
            this.pnl_Titulo.Controls.Add(this.pb_Exit);
            this.pnl_Titulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Titulo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnl_Titulo.Location = new System.Drawing.Point(0, 0);
            this.pnl_Titulo.Name = "pnl_Titulo";
            this.pnl_Titulo.Size = new System.Drawing.Size(1300, 34);
            this.pnl_Titulo.TabIndex = 0;
            this.pnl_Titulo.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_Titulo_Paint);
            this.pnl_Titulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnl_Titulo_MouseDown);
            // 
            // lbl_Stock
            // 
            this.lbl_Stock.AutoSize = true;
            this.lbl_Stock.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Stock.ForeColor = System.Drawing.Color.Salmon;
            this.lbl_Stock.Location = new System.Drawing.Point(54, 6);
            this.lbl_Stock.Name = "lbl_Stock";
            this.lbl_Stock.Size = new System.Drawing.Size(101, 20);
            this.lbl_Stock.TabIndex = 4;
            this.lbl_Stock.Text = "Limite de stock";
            // 
            // pb_Alert
            // 
            this.pb_Alert.BackColor = System.Drawing.Color.Transparent;
            this.pb_Alert.Location = new System.Drawing.Point(11, 1);
            this.pb_Alert.Name = "pb_Alert";
            this.pb_Alert.Size = new System.Drawing.Size(28, 26);
            this.pb_Alert.TabIndex = 0;
            this.pb_Alert.TabStop = false;
            this.pb_Alert.Click += new System.EventHandler(this.pb_Alert_Click);
            // 
            // pb_Chico
            // 
            this.pb_Chico.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Chico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Chico.Enabled = false;
            this.pb_Chico.Image = ((System.Drawing.Image)(resources.GetObject("pb_Chico.Image")));
            this.pb_Chico.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Chico.InitialImage")));
            this.pb_Chico.Location = new System.Drawing.Point(1217, -1);
            this.pb_Chico.Name = "pb_Chico";
            this.pb_Chico.Size = new System.Drawing.Size(29, 30);
            this.pb_Chico.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Chico.TabIndex = 3;
            this.pb_Chico.TabStop = false;
            this.pb_Chico.Visible = false;
            this.pb_Chico.Click += new System.EventHandler(this.pb_Chico_Click);
            // 
            // pb_Min
            // 
            this.pb_Min.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Min.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Min.Image = ((System.Drawing.Image)(resources.GetObject("pb_Min.Image")));
            this.pb_Min.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Min.InitialImage")));
            this.pb_Min.Location = new System.Drawing.Point(1177, 0);
            this.pb_Min.Name = "pb_Min";
            this.pb_Min.Size = new System.Drawing.Size(29, 30);
            this.pb_Min.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Min.TabIndex = 2;
            this.pb_Min.TabStop = false;
            this.pb_Min.Click += new System.EventHandler(this.pb_Min_Click);
            // 
            // pb_Full
            // 
            this.pb_Full.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Full.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Full.Image = ((System.Drawing.Image)(resources.GetObject("pb_Full.Image")));
            this.pb_Full.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Full.InitialImage")));
            this.pb_Full.Location = new System.Drawing.Point(1217, 0);
            this.pb_Full.Name = "pb_Full";
            this.pb_Full.Size = new System.Drawing.Size(29, 30);
            this.pb_Full.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Full.TabIndex = 1;
            this.pb_Full.TabStop = false;
            this.pb_Full.Click += new System.EventHandler(this.pb_Full_Click);
            // 
            // pb_Exit
            // 
            this.pb_Exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pb_Exit.Image")));
            this.pb_Exit.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Exit.InitialImage")));
            this.pb_Exit.Location = new System.Drawing.Point(1257, -1);
            this.pb_Exit.Name = "pb_Exit";
            this.pb_Exit.Size = new System.Drawing.Size(29, 30);
            this.pb_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Exit.TabIndex = 0;
            this.pb_Exit.TabStop = false;
            this.pb_Exit.Click += new System.EventHandler(this.pb_Exit_Click);
            // 
            // btn_SuperAdmin
            // 
            this.btn_SuperAdmin.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_SuperAdmin.FlatAppearance.BorderSize = 0;
            this.btn_SuperAdmin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SlateBlue;
            this.btn_SuperAdmin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_SuperAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SuperAdmin.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SuperAdmin.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_SuperAdmin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_SuperAdmin.Location = new System.Drawing.Point(0, 836);
            this.btn_SuperAdmin.Name = "btn_SuperAdmin";
            this.btn_SuperAdmin.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btn_SuperAdmin.Size = new System.Drawing.Size(177, 35);
            this.btn_SuperAdmin.TabIndex = 12;
            this.btn_SuperAdmin.Text = "Panel administrador";
            this.btn_SuperAdmin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_SuperAdmin.UseVisualStyleBackColor = true;
            this.btn_SuperAdmin.Click += new System.EventHandler(this.btn_SuperAdmin_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 650);
            this.Controls.Add(this.pnl_Base);
            this.Controls.Add(this.pnl_opciones);
            this.Controls.Add(this.pnl_Titulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.pnl_opciones.ResumeLayout(false);
            this.pnl_GestVentas.ResumeLayout(false);
            this.pnl_GestClien.ResumeLayout(false);
            this.pnl_GesInv.ResumeLayout(false);
            this.pnl_SubUser.ResumeLayout(false);
            this.pnl_Foto.ResumeLayout(false);
            this.pnl_Foto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Usuario)).EndInit();
            this.pnl_Titulo.ResumeLayout(false);
            this.pnl_Titulo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Alert)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Chico)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Full)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Exit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnl_opciones;
        private System.Windows.Forms.Panel pnl_Base;
        private System.Windows.Forms.PictureBox pb_Usuario;
        private System.Windows.Forms.Button btn_Cobrar;
        private System.Windows.Forms.PictureBox pb_Exit;
        private System.Windows.Forms.PictureBox pb_Full;
        private System.Windows.Forms.PictureBox pb_Min;
        private System.Windows.Forms.PictureBox pb_Chico;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnl_Titulo;
        private System.Windows.Forms.Button btn_Stock;
        private System.Windows.Forms.Label lbl_tipo;
        private System.Windows.Forms.Label lbl_RFC;
        private System.Windows.Forms.Label lbl_Usuario;
        private System.Windows.Forms.PictureBox pb_Alert;
        private System.Windows.Forms.Button btn_SA;
        private System.Windows.Forms.Button btn_Bodega;
        private System.Windows.Forms.Button btn_ventas;
        private System.Windows.Forms.Button btn_DeleteCliente;
        private System.Windows.Forms.Button btn_RegistroCyU;
        private System.Windows.Forms.Button btn_bitacora;
        private System.Windows.Forms.Button btn_AgregarProd;
        private System.Windows.Forms.Panel pnl_Foto;
        private System.Windows.Forms.Panel pnl_SubUser;
        private System.Windows.Forms.Button btn_GestionUser;
        private System.Windows.Forms.Panel pnl_GestClien;
        private System.Windows.Forms.Button btn_clientes;
        private System.Windows.Forms.Button btn_GestCli;
        private System.Windows.Forms.Panel pnl_GesInv;
        private System.Windows.Forms.Button btn_Inventario;
        private System.Windows.Forms.Button btn_GestVentas;
        private System.Windows.Forms.Panel pnl_GestVentas;
        private System.Windows.Forms.Button btn_UserClient;
        private System.Windows.Forms.Label lbl_Stock;
        private System.Windows.Forms.Button btn_SuperAdmin;
    }
}