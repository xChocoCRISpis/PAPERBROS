﻿namespace PAPERBROS
{
    partial class Bitacora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bitacora));
            this.dgv_Bitacora = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_NomResp = new System.Windows.Forms.TextBox();
            this.tb_Fechas = new System.Windows.Forms.TabControl();
            this.tp_Fecha0 = new System.Windows.Forms.TabPage();
            this.mc_Fecha0 = new System.Windows.Forms.MonthCalendar();
            this.tp_Fecha1 = new System.Windows.Forms.TabPage();
            this.mc_Fecha1 = new System.Windows.Forms.MonthCalendar();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Tabla = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Fecha0 = new System.Windows.Forms.Label();
            this.lbl_Fecha1 = new System.Windows.Forms.Label();
            this.btn_Nombre = new System.Windows.Forms.Button();
            this.btn_tabla = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Bitacora)).BeginInit();
            this.tb_Fechas.SuspendLayout();
            this.tp_Fecha0.SuspendLayout();
            this.tp_Fecha1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv_Bitacora
            // 
            this.dgv_Bitacora.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_Bitacora.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Franklin Gothic Demi", 9.75F, System.Drawing.FontStyle.Italic);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(16)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Bitacora.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Bitacora.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Bitacora.EnableHeadersVisualStyles = false;
            this.dgv_Bitacora.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgv_Bitacora.Location = new System.Drawing.Point(60, 135);
            this.dgv_Bitacora.Name = "dgv_Bitacora";
            this.dgv_Bitacora.RowHeadersVisible = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(74)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_Bitacora.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Bitacora.Size = new System.Drawing.Size(717, 192);
            this.dgv_Bitacora.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(121, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre responsable";
            // 
            // txt_NomResp
            // 
            this.txt_NomResp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_NomResp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_NomResp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_NomResp.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_NomResp.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_NomResp.Location = new System.Drawing.Point(244, 71);
            this.txt_NomResp.Name = "txt_NomResp";
            this.txt_NomResp.Size = new System.Drawing.Size(400, 20);
            this.txt_NomResp.TabIndex = 2;
            // 
            // tb_Fechas
            // 
            this.tb_Fechas.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tb_Fechas.Controls.Add(this.tp_Fecha0);
            this.tb_Fechas.Controls.Add(this.tp_Fecha1);
            this.tb_Fechas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.tb_Fechas.ItemSize = new System.Drawing.Size(150, 25);
            this.tb_Fechas.Location = new System.Drawing.Point(92, 348);
            this.tb_Fechas.Name = "tb_Fechas";
            this.tb_Fechas.SelectedIndex = 0;
            this.tb_Fechas.Size = new System.Drawing.Size(327, 211);
            this.tb_Fechas.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tb_Fechas.TabIndex = 3;
            // 
            // tp_Fecha0
            // 
            this.tp_Fecha0.Controls.Add(this.mc_Fecha0);
            this.tp_Fecha0.Location = new System.Drawing.Point(4, 29);
            this.tp_Fecha0.Name = "tp_Fecha0";
            this.tp_Fecha0.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Fecha0.Size = new System.Drawing.Size(319, 178);
            this.tp_Fecha0.TabIndex = 0;
            this.tp_Fecha0.Text = "Inicial";
            this.tp_Fecha0.UseVisualStyleBackColor = true;
            // 
            // mc_Fecha0
            // 
            this.mc_Fecha0.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.mc_Fecha0.Location = new System.Drawing.Point(28, 7);
            this.mc_Fecha0.Name = "mc_Fecha0";
            this.mc_Fecha0.TabIndex = 0;
            this.mc_Fecha0.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.mc_Fecha0_DateChanged);
            // 
            // tp_Fecha1
            // 
            this.tp_Fecha1.BackColor = System.Drawing.Color.Transparent;
            this.tp_Fecha1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tp_Fecha1.Controls.Add(this.mc_Fecha1);
            this.tp_Fecha1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.tp_Fecha1.Location = new System.Drawing.Point(4, 29);
            this.tp_Fecha1.Name = "tp_Fecha1";
            this.tp_Fecha1.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Fecha1.Size = new System.Drawing.Size(319, 178);
            this.tp_Fecha1.TabIndex = 1;
            this.tp_Fecha1.Text = "Final";
            // 
            // mc_Fecha1
            // 
            this.mc_Fecha1.Location = new System.Drawing.Point(34, 4);
            this.mc_Fecha1.Name = "mc_Fecha1";
            this.mc_Fecha1.TabIndex = 1;
            this.mc_Fecha1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.mc_Fecha1_DateChanged);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(121, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tabla";
            // 
            // txt_Tabla
            // 
            this.txt_Tabla.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_Tabla.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Tabla.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Tabla.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Tabla.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Tabla.Location = new System.Drawing.Point(244, 109);
            this.txt_Tabla.Name = "txt_Tabla";
            this.txt_Tabla.Size = new System.Drawing.Size(400, 20);
            this.txt_Tabla.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(481, 405);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Fecha inicial: ";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(481, 452);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Fecha final: ";
            // 
            // lbl_Fecha0
            // 
            this.lbl_Fecha0.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Fecha0.AutoSize = true;
            this.lbl_Fecha0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Fecha0.ForeColor = System.Drawing.Color.MistyRose;
            this.lbl_Fecha0.Location = new System.Drawing.Point(579, 405);
            this.lbl_Fecha0.Name = "lbl_Fecha0";
            this.lbl_Fecha0.Size = new System.Drawing.Size(23, 13);
            this.lbl_Fecha0.TabIndex = 8;
            this.lbl_Fecha0.Text = "----";
            // 
            // lbl_Fecha1
            // 
            this.lbl_Fecha1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_Fecha1.AutoSize = true;
            this.lbl_Fecha1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Fecha1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lbl_Fecha1.Location = new System.Drawing.Point(579, 452);
            this.lbl_Fecha1.Name = "lbl_Fecha1";
            this.lbl_Fecha1.Size = new System.Drawing.Size(23, 13);
            this.lbl_Fecha1.TabIndex = 9;
            this.lbl_Fecha1.Text = "----";
            // 
            // btn_Nombre
            // 
            this.btn_Nombre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Nombre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Nombre.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Nombre.Location = new System.Drawing.Point(671, 63);
            this.btn_Nombre.Name = "btn_Nombre";
            this.btn_Nombre.Size = new System.Drawing.Size(89, 23);
            this.btn_Nombre.TabIndex = 10;
            this.btn_Nombre.Text = "Buscar nombre";
            this.btn_Nombre.UseVisualStyleBackColor = true;
            this.btn_Nombre.Click += new System.EventHandler(this.btn_Nombre_Click);
            // 
            // btn_tabla
            // 
            this.btn_tabla.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_tabla.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_tabla.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tabla.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_tabla.Location = new System.Drawing.Point(671, 99);
            this.btn_tabla.Name = "btn_tabla";
            this.btn_tabla.Size = new System.Drawing.Size(89, 23);
            this.btn_tabla.TabIndex = 11;
            this.btn_tabla.Text = "Buscar Tabla";
            this.btn_tabla.UseVisualStyleBackColor = true;
            this.btn_tabla.Click += new System.EventHandler(this.btn_tabla_Click);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(331, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(201, 39);
            this.label7.TabIndex = 19;
            this.label7.Text = "BITACORA";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.SlateBlue;
            this.panel2.Location = new System.Drawing.Point(3, 45);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(855, 5);
            this.panel2.TabIndex = 33;
            // 
            // Bitacora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.ClientSize = new System.Drawing.Size(855, 569);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_tabla);
            this.Controls.Add(this.btn_Nombre);
            this.Controls.Add(this.lbl_Fecha1);
            this.Controls.Add(this.lbl_Fecha0);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Tabla);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_Fechas);
            this.Controls.Add(this.txt_NomResp);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_Bitacora);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Bitacora";
            this.Text = "Bitacora";
            this.Load += new System.EventHandler(this.Bitacora_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Bitacora)).EndInit();
            this.tb_Fechas.ResumeLayout(false);
            this.tp_Fecha0.ResumeLayout(false);
            this.tp_Fecha1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Bitacora;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_NomResp;
        private System.Windows.Forms.TabControl tb_Fechas;
        private System.Windows.Forms.TabPage tp_Fecha0;
        private System.Windows.Forms.MonthCalendar mc_Fecha0;
        private System.Windows.Forms.TabPage tp_Fecha1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_Tabla;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Fecha0;
        private System.Windows.Forms.Label lbl_Fecha1;
        private System.Windows.Forms.Button btn_Nombre;
        private System.Windows.Forms.Button btn_tabla;
        private System.Windows.Forms.MonthCalendar mc_Fecha1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
    }
}