﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Media;

namespace PAPERBROS
{
    public partial class Cobrar : Form
    {

        string mostrar;
        int factura=-1;
        int cliente=-2;
        string tadmin;
        string foto;
        int disp;
        Factura ticket;
        public Cobrar(string admin,string imagen)
        {
            InitializeComponent();
            tadmin = admin;
            foto = imagen;
        }

        private void btn_Cobrar_Click(object sender, EventArgs e)
        {
            SqlConnection con = Conexion.CadenaConexion();

            if (con != null)
            {
               


                try
                {
                    if (factura == -1)
                    {
                        SqlCommand fac = new SqlCommand();
                        fac.Connection = con;
                        fac.CommandType = CommandType.StoredProcedure;
                        fac.CommandText = "sp_UltimaFactura";
                        fac.Parameters.Clear();
                        fac.Parameters.Add("@FACTURA", SqlDbType.Int).Value = factura;
                        fac.Parameters["@FACTURA"].Direction = ParameterDirection.Output;
                        fac.ExecuteNonQuery();

                        factura = int.Parse(fac.Parameters["@FACTURA"].Value.ToString());

                    }
                    if (cliente == -2)
                    {
                        

                        SqlCommand cli = new SqlCommand();
                        cli.Connection = con;
                        cli.CommandType = CommandType.StoredProcedure;
                        cli.CommandText = "sp_NumeroCliente";
                        cli.Parameters.Clear();
                        cli.Parameters.Add("@RFC", SqlDbType.VarChar, 35).Value = txt_Cliente.Text;
                        cli.Parameters.Add("@CLIENTE", SqlDbType.Int).Value = cliente;
                        cli.Parameters["@CLIENTE"].Direction = ParameterDirection.Output;
                        cli.ExecuteNonQuery();

                        cliente= int.Parse(cli.Parameters["@CLIENTE"].Value.ToString());


                       
                    }

                    if (cliente!=null && cliente!=-2 )
                    {

                        SqlCommand com = new SqlCommand();
                        com.Connection = con;
                        com.CommandType = CommandType.StoredProcedure;
                        com.CommandText = "sp_Cobro";
                        com.Parameters.Clear();
                        com.Parameters.Add("@PRODUCTO", SqlDbType.Int).Value = txt_SetProducto.Text;
                        int cantidad = Convert.ToInt32(txt_Cantidad.Text);
                        com.Parameters.Add("@CANTIDAD", SqlDbType.Int).Value = cantidad;
                        com.Parameters.Add("@FACTURA", SqlDbType.Int).Value = factura;
                        com.Parameters.Add("@CLIENTE", SqlDbType.Int).Value = cliente;

                        com.Parameters.Add("@DISPONIBILIDAD", SqlDbType.Int).Value = -1;
                        com.Parameters["@DISPONIBILIDAD"].Direction = ParameterDirection.Output;

                        chb_Cliente.Enabled = false;
                        chb_ClienteNO.Enabled = false;
                        txt_Cliente.Enabled = false;

                        com.ExecuteNonQuery();
                       

                        SqlCommand LimStock=new SqlCommand();
                        LimStock.Connection = con;
                        LimStock.CommandType= CommandType.StoredProcedure;
                        LimStock.CommandText = "sp_CobrarLimStock";
                        LimStock.Parameters.Clear();

                        LimStock.Parameters.Add("@PRODUCTO_ID", SqlDbType.Int).Value = Convert.ToInt32(txt_SetProducto.Text);
                        LimStock.Parameters.Add("@LIM_STOCK", SqlDbType.Int).Value = 0;
                        LimStock.Parameters["@LIM_STOCK"].Direction = ParameterDirection.Output;
                        LimStock.ExecuteNonQuery();
                        int Limite = int.Parse(LimStock.Parameters["@LIM_STOCK"].Value.ToString());
                        Console.WriteLine("limite stock:" + Limite);

                        disp = int.Parse(com.Parameters["@DISPONIBILIDAD"].Value.ToString());
                        con.Close();
                        Console.WriteLine(disp + "");
                        if (disp >= 0 && disp <= Limite)
                            MessageBox.Show("El artículo esta en el límite de stock, informar al gerente lo antes posible");

                        if (disp == -1 || disp >= 0)
                        {
                            if (disp >= cantidad || disp==-1)
                            {
                                SoundPlayer player = new SoundPlayer();
                                player.SoundLocation = @"Audio\Scanner.wav";
                                player.Play();
                                player.Dispose();
                                VentanaTickets();
                            }

                            else
                                MessageBox.Show("No hay productos suficientes");
                        }
                        else
                        {
                            MessageBox.Show("No hay productos suficientes");
                        }
                    }
                    else
                    {

                        MessageBox.Show("El cliente no existe en la base de datos");
                    }
                    txt_SetProducto.Text = null;
                    txt_Cantidad.Text = null;

                }
                catch (Exception ex)
                {
                    Console.WriteLine ("Linea error: "+ ex);
                    MessageBox.Show("Valores inválidos");
                }
              
            }
            else
            {
                MessageBox.Show("Sin conexión a la base de datos");
            }
        }

        public void DataGrid_PRODUCTO()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT Id_Producto,Nombre FROM PRODUCTO WHERE Nombre LIKE '%" + txt_Producto.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dg_producto.ReadOnly = true;
            dg_producto.DataSource = ds.Tables[0];
        }

        private void txt_Producto_TextChanged(object sender, EventArgs e)
        {
            DataGrid_PRODUCTO();
        }


        

        private void chb_Cliente_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_Cliente.Checked == true)
            {
                chb_ClienteNO.Checked = false;
                txt_Cliente.Text = null;
                txt_Cliente.Enabled = true;
                txt_Cantidad.Enabled = true;
                txt_Producto.Enabled = true;
                txt_SetProducto.Enabled = true;
                txt_Cliente.Enabled = true;

            }
        }

        private void chb_ClienteNO_CheckedChanged(object sender, EventArgs e)
        {
            if (chb_ClienteNO.Checked == true)
            {
                chb_Cliente.Checked = false;
                txt_Cliente.Text = "DESC";
                txt_Cliente.Enabled = false;
                txt_Cantidad.Enabled = true;
                txt_Producto.Enabled = true;
                txt_SetProducto.Enabled = true;
            }
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            Opciones Opciones = new Opciones(tadmin, foto);
            Opciones.Show();
            Factura obj_factura = new Factura(cliente, this.factura,tadmin,foto);
            obj_factura.Dispose();
            this.Dispose();
        }

        private void dg_producto_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = (DataGridViewRow)dg_producto.Rows[e.RowIndex];
                int id = int.Parse(Convert.ToString(row.Cells[0].Value));
                string prod = Convert.ToString(row.Cells[1].Value);
                txt_SetProducto.Text = Convert.ToString(id);
                lbl_prod.Text = "Producto seleccionado: " + prod;
            }
            catch (Exception)
            {
            }
        }

        private void Cobrar_Load(object sender, EventArgs e)
        {

        }

        private void VentanaTickets()
        {
            List<Form> formsACerrar = new List<Form>();

            foreach (Form form in Application.OpenForms)
            {
                if (form is Factura && form != this)
                {
                    formsACerrar.Add(form);
                }
            }

            foreach (Form formCerrar in formsACerrar)
            {
                formCerrar.Close();  // Cierra las instancias adicionales de Factura
            }

            ticket = new Factura(cliente, this.factura, tadmin, foto);
            ticket.Show();
        }

        private void txt_SetProducto_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
