﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAPERBROS
{
    public partial class BorrarUsuario : Form
    {
        string mostrar;
        string TipoAdmin;
        string foto;
        public BorrarUsuario(string TipoAdmin,string imagen)
        {
            InitializeComponent();
            DataGrid_Usuario();
            this.TipoAdmin = TipoAdmin;
            txt_Buscar.Enabled = true;
            txt_BorrarU1.Enabled = false;
            foto = imagen;
        }


        private void btn_Borrar_Click(object sender, EventArgs e)
        {
            DialogResult dialogo = MessageBox.Show("¿Desea borrar a un cliente?",
               "Borrar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogo == DialogResult.No)
            {
                txt_BorrarU1.Text = null;
            }
            else
            {
                SqlConnection con = Conexion.CadenaConexion();
                if (con != null)
                {
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandType = CommandType.StoredProcedure;
                    com.CommandText = "sp_BorrarUsuario";
                    com.Parameters.Clear();

                    try
                    {
                        // pase de parámetros
                        com.Parameters.AddWithValue("@RFC", txt_BorrarU1.Text);
                        int a = com.ExecuteNonQuery();

                        if (a > 0)
                        {
                            MessageBox.Show("Usuario eliminado exitosamente");
                            txt_BorrarU1.Text = null;
                            DataGrid_Usuario();

                        }
                        else
                        {
                            MessageBox.Show("Usuario no se dió de alta porque ya existe en la base de datos");
                        }

                    }
                    catch (Exception Ex)
                    {
                        MessageBox.Show(Ex.Message);
                    }
                    
                    
                }
                else
                {
                    MessageBox.Show("son conexión a la base de datos");
                }
            }
        }

        public void DataGrid_Usuario()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = "SELECT RFC,Nombre,ApPaterno,ApMaterno,Puntos FROM USUARIO";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_BorrarUsuario.DataSource = ds.Tables[0];
        }

        public void Datagrid_buscar()
        {
            SqlConnection con = Conexion.CadenaConexion();
            mostrar = mostrar = "SELECT RFC,Nombre,ApPaterno,ApMaterno,Puntos FROM USUARIO WHERE RFC LIKE '%" + txt_Buscar.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(mostrar, con);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgv_BorrarUsuario.DataSource = ds.Tables[0];
        }

        private void dgv_BorrarUsuario_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow row = (DataGridViewRow)dgv_BorrarUsuario.Rows[e.RowIndex];
                string rfc = Convert.ToString(row.Cells[0].Value);
                txt_BorrarU1.Text = rfc;
            }
            catch (Exception)
            {
            }
        }

        private void txt_Buscar_TextChanged(object sender, EventArgs e)
        {
            if (txt_Buscar.Text != null && txt_Buscar.Text != "")
                    Datagrid_buscar();
        }

        private void dgv_BorrarUsuario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
