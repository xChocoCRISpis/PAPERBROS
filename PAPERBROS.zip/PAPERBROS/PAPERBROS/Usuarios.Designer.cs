﻿namespace PAPERBROS
{
    partial class Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Usuarios));
            this.label13 = new System.Windows.Forms.Label();
            this.gpb_Usuarios2 = new System.Windows.Forms.GroupBox();
            this.ch_cajero = new System.Windows.Forms.CheckBox();
            this.ch_gerente = new System.Windows.Forms.CheckBox();
            this.lable7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_RFC = new System.Windows.Forms.TextBox();
            this.txt_Tipo = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btn_Modificar = new System.Windows.Forms.Button();
            this.txt_Buscar = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dgv_info = new System.Windows.Forms.DataGridView();
            this.gpb_Usuarios = new System.Windows.Forms.GroupBox();
            this.ch_NO = new System.Windows.Forms.CheckBox();
            this.txt_Paterno = new System.Windows.Forms.TextBox();
            this.ch_Si = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ch_modificar = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Materno = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_Contratado = new System.Windows.Forms.TextBox();
            this.txt_Admin = new System.Windows.Forms.TextBox();
            this.rdb_clientes = new System.Windows.Forms.RadioButton();
            this.rdb_Usuarios = new System.Windows.Forms.RadioButton();
            this.pnl_Clientes = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_Nivel = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_Puntos = new System.Windows.Forms.TextBox();
            this.txt_materno_cliente = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_rfc_cliente = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_paterno_cliente = new System.Windows.Forms.TextBox();
            this.txt_id_cliente = new System.Windows.Forms.TextBox();
            this.txt_nombre_cliente = new System.Windows.Forms.TextBox();
            this.chb_mod_Cliente = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pic_Foto = new System.Windows.Forms.PictureBox();
            this.ofd_FotoAdmin = new System.Windows.Forms.OpenFileDialog();
            this.gpb_Usuarios2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_info)).BeginInit();
            this.gpb_Usuarios.SuspendLayout();
            this.pnl_Clientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Foto)).BeginInit();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(294, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(372, 33);
            this.label13.TabIndex = 47;
            this.label13.Text = "GESTIÓN DE USUARIOS";
            // 
            // gpb_Usuarios2
            // 
            this.gpb_Usuarios2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpb_Usuarios2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.gpb_Usuarios2.Controls.Add(this.ch_cajero);
            this.gpb_Usuarios2.Controls.Add(this.ch_gerente);
            this.gpb_Usuarios2.Controls.Add(this.lable7);
            this.gpb_Usuarios2.Controls.Add(this.label6);
            this.gpb_Usuarios2.Controls.Add(this.txt_RFC);
            this.gpb_Usuarios2.Controls.Add(this.txt_Tipo);
            this.gpb_Usuarios2.ForeColor = System.Drawing.Color.White;
            this.gpb_Usuarios2.Location = new System.Drawing.Point(356, 86);
            this.gpb_Usuarios2.Name = "gpb_Usuarios2";
            this.gpb_Usuarios2.Size = new System.Drawing.Size(302, 199);
            this.gpb_Usuarios2.TabIndex = 46;
            this.gpb_Usuarios2.TabStop = false;
            // 
            // ch_cajero
            // 
            this.ch_cajero.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_cajero.AutoSize = true;
            this.ch_cajero.BackColor = System.Drawing.Color.Transparent;
            this.ch_cajero.Enabled = false;
            this.ch_cajero.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_cajero.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_cajero.Location = new System.Drawing.Point(178, 127);
            this.ch_cajero.Name = "ch_cajero";
            this.ch_cajero.Size = new System.Drawing.Size(56, 19);
            this.ch_cajero.TabIndex = 31;
            this.ch_cajero.Text = "Cajero";
            this.ch_cajero.UseVisualStyleBackColor = false;
            // 
            // ch_gerente
            // 
            this.ch_gerente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_gerente.AutoSize = true;
            this.ch_gerente.BackColor = System.Drawing.Color.Transparent;
            this.ch_gerente.Enabled = false;
            this.ch_gerente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_gerente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_gerente.Location = new System.Drawing.Point(38, 127);
            this.ch_gerente.Name = "ch_gerente";
            this.ch_gerente.Size = new System.Drawing.Size(61, 19);
            this.ch_gerente.TabIndex = 30;
            this.ch_gerente.Text = "Gerente";
            this.ch_gerente.UseVisualStyleBackColor = false;
            // 
            // lable7
            // 
            this.lable7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lable7.AutoSize = true;
            this.lable7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.lable7.Location = new System.Drawing.Point(35, 45);
            this.lable7.Name = "lable7";
            this.lable7.Size = new System.Drawing.Size(27, 15);
            this.lable7.TabIndex = 6;
            this.lable7.Text = "RFC";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(35, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 15);
            this.label6.TabIndex = 7;
            this.label6.Text = "Tipo";
            // 
            // txt_RFC
            // 
            this.txt_RFC.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_RFC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_RFC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_RFC.Enabled = false;
            this.txt_RFC.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_RFC.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_RFC.Location = new System.Drawing.Point(76, 45);
            this.txt_RFC.Name = "txt_RFC";
            this.txt_RFC.ReadOnly = true;
            this.txt_RFC.Size = new System.Drawing.Size(164, 20);
            this.txt_RFC.TabIndex = 15;
            // 
            // txt_Tipo
            // 
            this.txt_Tipo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Tipo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Tipo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Tipo.Enabled = false;
            this.txt_Tipo.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Tipo.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Tipo.Location = new System.Drawing.Point(76, 69);
            this.txt_Tipo.Name = "txt_Tipo";
            this.txt_Tipo.ReadOnly = true;
            this.txt_Tipo.Size = new System.Drawing.Size(164, 20);
            this.txt_Tipo.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(353, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(227, 15);
            this.label12.TabIndex = 44;
            this.label12.Text = "Tipos de administradores: 2= Gerente, 3= Cajero";
            // 
            // btn_Modificar
            // 
            this.btn_Modificar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Modificar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Modificar.Enabled = false;
            this.btn_Modificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Modificar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Modificar.Location = new System.Drawing.Point(685, 251);
            this.btn_Modificar.Name = "btn_Modificar";
            this.btn_Modificar.Size = new System.Drawing.Size(75, 23);
            this.btn_Modificar.TabIndex = 43;
            this.btn_Modificar.Text = "Modificar";
            this.btn_Modificar.UseVisualStyleBackColor = false;
            this.btn_Modificar.Click += new System.EventHandler(this.btn_Modificar_Click);
            // 
            // txt_Buscar
            // 
            this.txt_Buscar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Buscar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Buscar.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Buscar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Buscar.Location = new System.Drawing.Point(105, 8);
            this.txt_Buscar.Name = "txt_Buscar";
            this.txt_Buscar.Size = new System.Drawing.Size(164, 20);
            this.txt_Buscar.TabIndex = 42;
            this.txt_Buscar.TextChanged += new System.EventHandler(this.txt_Buscar_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(14, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 15);
            this.label7.TabIndex = 41;
            this.label7.Text = "Buscar por RFC:";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(682, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 15);
            this.label9.TabIndex = 39;
            this.label9.Text = "Foto";
            // 
            // dgv_info
            // 
            this.dgv_info.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_info.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Franklin Gothic Demi", 9.75F, System.Drawing.FontStyle.Italic);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(16)))), ((int)(((byte)(109)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_info.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgv_info.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_info.EnableHeadersVisualStyles = false;
            this.dgv_info.Location = new System.Drawing.Point(14, 291);
            this.dgv_info.Name = "dgv_info";
            this.dgv_info.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial", 9F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(74)))), ((int)(((byte)(225)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            this.dgv_info.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgv_info.Size = new System.Drawing.Size(762, 162);
            this.dgv_info.TabIndex = 38;
            this.dgv_info.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_info_CellClick);
            // 
            // gpb_Usuarios
            // 
            this.gpb_Usuarios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.gpb_Usuarios.Controls.Add(this.ch_NO);
            this.gpb_Usuarios.Controls.Add(this.txt_Paterno);
            this.gpb_Usuarios.Controls.Add(this.ch_Si);
            this.gpb_Usuarios.Controls.Add(this.label1);
            this.gpb_Usuarios.Controls.Add(this.label11);
            this.gpb_Usuarios.Controls.Add(this.label2);
            this.gpb_Usuarios.Controls.Add(this.ch_modificar);
            this.gpb_Usuarios.Controls.Add(this.label3);
            this.gpb_Usuarios.Controls.Add(this.txt_Materno);
            this.gpb_Usuarios.Controls.Add(this.label4);
            this.gpb_Usuarios.Controls.Add(this.label8);
            this.gpb_Usuarios.Controls.Add(this.txt_Nombre);
            this.gpb_Usuarios.Controls.Add(this.txt_Contratado);
            this.gpb_Usuarios.Controls.Add(this.txt_Admin);
            this.gpb_Usuarios.ForeColor = System.Drawing.Color.White;
            this.gpb_Usuarios.Location = new System.Drawing.Point(17, 86);
            this.gpb_Usuarios.Name = "gpb_Usuarios";
            this.gpb_Usuarios.Size = new System.Drawing.Size(330, 199);
            this.gpb_Usuarios.TabIndex = 45;
            this.gpb_Usuarios.TabStop = false;
            // 
            // ch_NO
            // 
            this.ch_NO.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_NO.AutoSize = true;
            this.ch_NO.BackColor = System.Drawing.Color.Transparent;
            this.ch_NO.Enabled = false;
            this.ch_NO.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_NO.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_NO.Location = new System.Drawing.Point(274, 52);
            this.ch_NO.Name = "ch_NO";
            this.ch_NO.Size = new System.Drawing.Size(39, 19);
            this.ch_NO.TabIndex = 28;
            this.ch_NO.Text = "No";
            this.ch_NO.UseVisualStyleBackColor = false;
            // 
            // txt_Paterno
            // 
            this.txt_Paterno.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Paterno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Paterno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Paterno.Enabled = false;
            this.txt_Paterno.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Paterno.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Paterno.Location = new System.Drawing.Point(100, 127);
            this.txt_Paterno.Name = "txt_Paterno";
            this.txt_Paterno.ReadOnly = true;
            this.txt_Paterno.Size = new System.Drawing.Size(166, 20);
            this.txt_Paterno.TabIndex = 14;
            // 
            // ch_Si
            // 
            this.ch_Si.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_Si.AutoSize = true;
            this.ch_Si.BackColor = System.Drawing.Color.Transparent;
            this.ch_Si.Enabled = false;
            this.ch_Si.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_Si.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.ch_Si.Location = new System.Drawing.Point(274, 34);
            this.ch_Si.Name = "ch_Si";
            this.ch_Si.Size = new System.Drawing.Size(35, 19);
            this.ch_Si.TabIndex = 27;
            this.ch_Si.Text = "Si";
            this.ch_Si.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(23, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Contratado";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(109, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(123, 15);
            this.label11.TabIndex = 25;
            this.label11.Text = "Contratado= 0 = No, 1= Si";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(34, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Id Admin";
            // 
            // ch_modificar
            // 
            this.ch_modificar.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ch_modificar.AutoSize = true;
            this.ch_modificar.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.ch_modificar.Location = new System.Drawing.Point(12, 19);
            this.ch_modificar.Name = "ch_modificar";
            this.ch_modificar.Size = new System.Drawing.Size(69, 19);
            this.ch_modificar.TabIndex = 24;
            this.ch_modificar.Text = "Modificar";
            this.ch_modificar.UseVisualStyleBackColor = true;
            this.ch_modificar.CheckedChanged += new System.EventHandler(this.ch_modificar_CheckedChanged);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(38, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nombre";
            // 
            // txt_Materno
            // 
            this.txt_Materno.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Materno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Materno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Materno.Enabled = false;
            this.txt_Materno.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Materno.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Materno.Location = new System.Drawing.Point(100, 153);
            this.txt_Materno.Name = "txt_Materno";
            this.txt_Materno.ReadOnly = true;
            this.txt_Materno.Size = new System.Drawing.Size(167, 20);
            this.txt_Materno.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(11, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Apellido paterno";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(9, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 15);
            this.label8.TabIndex = 5;
            this.label8.Text = "Apellido materno";
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Nombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Nombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Nombre.Enabled = false;
            this.txt_Nombre.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Nombre.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Nombre.Location = new System.Drawing.Point(100, 98);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.ReadOnly = true;
            this.txt_Nombre.Size = new System.Drawing.Size(166, 20);
            this.txt_Nombre.TabIndex = 13;
            // 
            // txt_Contratado
            // 
            this.txt_Contratado.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Contratado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Contratado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Contratado.Enabled = false;
            this.txt_Contratado.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Contratado.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Contratado.Location = new System.Drawing.Point(100, 46);
            this.txt_Contratado.Name = "txt_Contratado";
            this.txt_Contratado.ReadOnly = true;
            this.txt_Contratado.Size = new System.Drawing.Size(166, 20);
            this.txt_Contratado.TabIndex = 11;
            // 
            // txt_Admin
            // 
            this.txt_Admin.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Admin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Admin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Admin.Enabled = false;
            this.txt_Admin.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Admin.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Admin.Location = new System.Drawing.Point(100, 72);
            this.txt_Admin.Name = "txt_Admin";
            this.txt_Admin.ReadOnly = true;
            this.txt_Admin.Size = new System.Drawing.Size(166, 20);
            this.txt_Admin.TabIndex = 12;
            // 
            // rdb_clientes
            // 
            this.rdb_clientes.AutoSize = true;
            this.rdb_clientes.BackColor = System.Drawing.Color.Transparent;
            this.rdb_clientes.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdb_clientes.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdb_clientes.Location = new System.Drawing.Point(31, 63);
            this.rdb_clientes.Name = "rdb_clientes";
            this.rdb_clientes.Size = new System.Drawing.Size(62, 19);
            this.rdb_clientes.TabIndex = 49;
            this.rdb_clientes.TabStop = true;
            this.rdb_clientes.Text = "Clientes";
            this.rdb_clientes.UseVisualStyleBackColor = false;
            this.rdb_clientes.CheckedChanged += new System.EventHandler(this.rdb_clientes_CheckedChanged);
            // 
            // rdb_Usuarios
            // 
            this.rdb_Usuarios.AutoSize = true;
            this.rdb_Usuarios.BackColor = System.Drawing.Color.Transparent;
            this.rdb_Usuarios.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.rdb_Usuarios.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rdb_Usuarios.Location = new System.Drawing.Point(31, 40);
            this.rdb_Usuarios.Name = "rdb_Usuarios";
            this.rdb_Usuarios.Size = new System.Drawing.Size(66, 19);
            this.rdb_Usuarios.TabIndex = 50;
            this.rdb_Usuarios.TabStop = true;
            this.rdb_Usuarios.Text = "Usuarios";
            this.rdb_Usuarios.UseVisualStyleBackColor = false;
            this.rdb_Usuarios.CheckedChanged += new System.EventHandler(this.rdb_Usuarios_CheckedChanged);
            // 
            // pnl_Clientes
            // 
            this.pnl_Clientes.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnl_Clientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.pnl_Clientes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_Clientes.Controls.Add(this.label18);
            this.pnl_Clientes.Controls.Add(this.txt_Nivel);
            this.pnl_Clientes.Controls.Add(this.label17);
            this.pnl_Clientes.Controls.Add(this.txt_Puntos);
            this.pnl_Clientes.Controls.Add(this.txt_materno_cliente);
            this.pnl_Clientes.Controls.Add(this.label5);
            this.pnl_Clientes.Controls.Add(this.label10);
            this.pnl_Clientes.Controls.Add(this.label14);
            this.pnl_Clientes.Controls.Add(this.txt_rfc_cliente);
            this.pnl_Clientes.Controls.Add(this.label15);
            this.pnl_Clientes.Controls.Add(this.label16);
            this.pnl_Clientes.Controls.Add(this.txt_paterno_cliente);
            this.pnl_Clientes.Controls.Add(this.txt_id_cliente);
            this.pnl_Clientes.Controls.Add(this.txt_nombre_cliente);
            this.pnl_Clientes.Controls.Add(this.chb_mod_Cliente);
            this.pnl_Clientes.Location = new System.Drawing.Point(6, 88);
            this.pnl_Clientes.Name = "pnl_Clientes";
            this.pnl_Clientes.Size = new System.Drawing.Size(652, 199);
            this.pnl_Clientes.TabIndex = 51;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label18.Location = new System.Drawing.Point(347, 47);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(30, 15);
            this.label18.TabIndex = 29;
            this.label18.Text = "Nivel";
            // 
            // txt_Nivel
            // 
            this.txt_Nivel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Nivel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Nivel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Nivel.Enabled = false;
            this.txt_Nivel.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Nivel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Nivel.Location = new System.Drawing.Point(384, 42);
            this.txt_Nivel.Name = "txt_Nivel";
            this.txt_Nivel.ReadOnly = true;
            this.txt_Nivel.Size = new System.Drawing.Size(167, 20);
            this.txt_Nivel.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label17.Location = new System.Drawing.Point(324, 152);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 15);
            this.label17.TabIndex = 27;
            this.label17.Text = "PUNTOS";
            // 
            // txt_Puntos
            // 
            this.txt_Puntos.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_Puntos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_Puntos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Puntos.Enabled = false;
            this.txt_Puntos.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_Puntos.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_Puntos.Location = new System.Drawing.Point(391, 149);
            this.txt_Puntos.Name = "txt_Puntos";
            this.txt_Puntos.ReadOnly = true;
            this.txt_Puntos.Size = new System.Drawing.Size(166, 20);
            this.txt_Puntos.TabIndex = 28;
            // 
            // txt_materno_cliente
            // 
            this.txt_materno_cliente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_materno_cliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_materno_cliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_materno_cliente.Enabled = false;
            this.txt_materno_cliente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_materno_cliente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_materno_cliente.Location = new System.Drawing.Point(113, 128);
            this.txt_materno_cliente.Name = "txt_materno_cliente";
            this.txt_materno_cliente.ReadOnly = true;
            this.txt_materno_cliente.Size = new System.Drawing.Size(166, 20);
            this.txt_materno_cliente.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Location = new System.Drawing.Point(66, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 15);
            this.label5.TabIndex = 17;
            this.label5.Text = "ID";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label10.Location = new System.Drawing.Point(347, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 15);
            this.label10.TabIndex = 18;
            this.label10.Text = "RFC";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label14.Location = new System.Drawing.Point(46, 77);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 15);
            this.label14.TabIndex = 19;
            this.label14.Text = "Nombre";
            // 
            // txt_rfc_cliente
            // 
            this.txt_rfc_cliente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_rfc_cliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_rfc_cliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_rfc_cliente.Enabled = false;
            this.txt_rfc_cliente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_rfc_cliente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_rfc_cliente.Location = new System.Drawing.Point(384, 69);
            this.txt_rfc_cliente.Name = "txt_rfc_cliente";
            this.txt_rfc_cliente.ReadOnly = true;
            this.txt_rfc_cliente.Size = new System.Drawing.Size(167, 20);
            this.txt_rfc_cliente.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label15.Location = new System.Drawing.Point(8, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 15);
            this.label15.TabIndex = 20;
            this.label15.Text = "Apellido paterno";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label16.Location = new System.Drawing.Point(6, 129);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(87, 15);
            this.label16.TabIndex = 21;
            this.label16.Text = "Apellido materno";
            // 
            // txt_paterno_cliente
            // 
            this.txt_paterno_cliente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_paterno_cliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_paterno_cliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_paterno_cliente.Enabled = false;
            this.txt_paterno_cliente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_paterno_cliente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_paterno_cliente.Location = new System.Drawing.Point(113, 99);
            this.txt_paterno_cliente.Name = "txt_paterno_cliente";
            this.txt_paterno_cliente.ReadOnly = true;
            this.txt_paterno_cliente.Size = new System.Drawing.Size(166, 20);
            this.txt_paterno_cliente.TabIndex = 24;
            // 
            // txt_id_cliente
            // 
            this.txt_id_cliente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_id_cliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_id_cliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_id_cliente.Enabled = false;
            this.txt_id_cliente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_id_cliente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_id_cliente.Location = new System.Drawing.Point(113, 47);
            this.txt_id_cliente.Name = "txt_id_cliente";
            this.txt_id_cliente.ReadOnly = true;
            this.txt_id_cliente.Size = new System.Drawing.Size(166, 20);
            this.txt_id_cliente.TabIndex = 22;
            // 
            // txt_nombre_cliente
            // 
            this.txt_nombre_cliente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txt_nombre_cliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.txt_nombre_cliente.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_nombre_cliente.Enabled = false;
            this.txt_nombre_cliente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.txt_nombre_cliente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_nombre_cliente.Location = new System.Drawing.Point(113, 73);
            this.txt_nombre_cliente.Name = "txt_nombre_cliente";
            this.txt_nombre_cliente.ReadOnly = true;
            this.txt_nombre_cliente.Size = new System.Drawing.Size(166, 20);
            this.txt_nombre_cliente.TabIndex = 23;
            // 
            // chb_mod_Cliente
            // 
            this.chb_mod_Cliente.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.chb_mod_Cliente.AutoSize = true;
            this.chb_mod_Cliente.BackColor = System.Drawing.Color.Transparent;
            this.chb_mod_Cliente.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold);
            this.chb_mod_Cliente.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.chb_mod_Cliente.Location = new System.Drawing.Point(22, 15);
            this.chb_mod_Cliente.Name = "chb_mod_Cliente";
            this.chb_mod_Cliente.Size = new System.Drawing.Size(69, 19);
            this.chb_mod_Cliente.TabIndex = 0;
            this.chb_mod_Cliente.Text = "Modificar";
            this.chb_mod_Cliente.UseVisualStyleBackColor = false;
            this.chb_mod_Cliente.CheckedChanged += new System.EventHandler(this.chb_mod_Cliente_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(711, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 46);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // pic_Foto
            // 
            this.pic_Foto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pic_Foto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.pic_Foto.Enabled = false;
            this.pic_Foto.Location = new System.Drawing.Point(675, 158);
            this.pic_Foto.Name = "pic_Foto";
            this.pic_Foto.Size = new System.Drawing.Size(100, 87);
            this.pic_Foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Foto.TabIndex = 40;
            this.pic_Foto.TabStop = false;
            this.pic_Foto.Click += new System.EventHandler(this.pic_Foto_Click);
            // 
            // Usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl_Clientes);
            this.Controls.Add(this.rdb_Usuarios);
            this.Controls.Add(this.rdb_clientes);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.gpb_Usuarios2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btn_Modificar);
            this.Controls.Add(this.txt_Buscar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pic_Foto);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dgv_info);
            this.Controls.Add(this.gpb_Usuarios);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Usuarios";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Usuarios_Load);
            this.gpb_Usuarios2.ResumeLayout(false);
            this.gpb_Usuarios2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_info)).EndInit();
            this.gpb_Usuarios.ResumeLayout(false);
            this.gpb_Usuarios.PerformLayout();
            this.pnl_Clientes.ResumeLayout(false);
            this.pnl_Clientes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Foto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox gpb_Usuarios2;
        private System.Windows.Forms.CheckBox ch_cajero;
        private System.Windows.Forms.CheckBox ch_gerente;
        private System.Windows.Forms.Label lable7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_RFC;
        private System.Windows.Forms.TextBox txt_Tipo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_Modificar;
        private System.Windows.Forms.TextBox txt_Buscar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pic_Foto;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dgv_info;
        private System.Windows.Forms.GroupBox gpb_Usuarios;
        private System.Windows.Forms.CheckBox ch_NO;
        private System.Windows.Forms.TextBox txt_Paterno;
        private System.Windows.Forms.CheckBox ch_Si;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox ch_modificar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Materno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_Contratado;
        private System.Windows.Forms.TextBox txt_Admin;
        private System.Windows.Forms.RadioButton rdb_clientes;
        private System.Windows.Forms.RadioButton rdb_Usuarios;
        private System.Windows.Forms.Panel pnl_Clientes;
        private System.Windows.Forms.CheckBox chb_mod_Cliente;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_Nivel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_Puntos;
        private System.Windows.Forms.TextBox txt_materno_cliente;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_rfc_cliente;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_paterno_cliente;
        private System.Windows.Forms.TextBox txt_id_cliente;
        private System.Windows.Forms.TextBox txt_nombre_cliente;
        private System.Windows.Forms.OpenFileDialog ofd_FotoAdmin;
    }
}