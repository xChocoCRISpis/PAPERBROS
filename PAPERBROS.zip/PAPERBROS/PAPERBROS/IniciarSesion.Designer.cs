﻿namespace PAPERBROS
{
    partial class form_inicio
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_inicio));
            this.txt_Usuario = new System.Windows.Forms.TextBox();
            this.txt_Contra = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_TipoAdmin = new System.Windows.Forms.Label();
            this.btn_CerrarSesion = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_Ingresar = new System.Windows.Forms.Button();
            this.btn_Opciones = new System.Windows.Forms.Button();
            this.pic_foto = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnl_inicio = new System.Windows.Forms.Panel();
            this.btn_OpenQR = new System.Windows.Forms.Button();
            this.pnl_QR = new System.Windows.Forms.Panel();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.pb_QR = new System.Windows.Forms.PictureBox();
            this.txt_QR = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.cmb_Camara = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pb_Min = new System.Windows.Forms.PictureBox();
            this.pb_Exit = new System.Windows.Forms.PictureBox();
            this.time_QR = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pic_foto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_inicio.SuspendLayout();
            this.pnl_QR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_QR)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Exit)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_Usuario
            // 
            this.txt_Usuario.Location = new System.Drawing.Point(133, 77);
            this.txt_Usuario.Name = "txt_Usuario";
            this.txt_Usuario.Size = new System.Drawing.Size(100, 20);
            this.txt_Usuario.TabIndex = 1;
            // 
            // txt_Contra
            // 
            this.txt_Contra.Location = new System.Drawing.Point(133, 124);
            this.txt_Contra.Name = "txt_Contra";
            this.txt_Contra.PasswordChar = '*';
            this.txt_Contra.Size = new System.Drawing.Size(100, 20);
            this.txt_Contra.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(63, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Usuario";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(54, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Contraseña";
            // 
            // lbl_TipoAdmin
            // 
            this.lbl_TipoAdmin.AutoSize = true;
            this.lbl_TipoAdmin.Location = new System.Drawing.Point(364, 131);
            this.lbl_TipoAdmin.Name = "lbl_TipoAdmin";
            this.lbl_TipoAdmin.Size = new System.Drawing.Size(13, 13);
            this.lbl_TipoAdmin.TabIndex = 7;
            this.lbl_TipoAdmin.Text = "--";
            // 
            // btn_CerrarSesion
            // 
            this.btn_CerrarSesion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_CerrarSesion.Enabled = false;
            this.btn_CerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CerrarSesion.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_CerrarSesion.Location = new System.Drawing.Point(336, 186);
            this.btn_CerrarSesion.Name = "btn_CerrarSesion";
            this.btn_CerrarSesion.Size = new System.Drawing.Size(82, 30);
            this.btn_CerrarSesion.TabIndex = 6;
            this.btn_CerrarSesion.Text = "Cerrar Sesión";
            this.btn_CerrarSesion.UseVisualStyleBackColor = false;
            this.btn_CerrarSesion.Click += new System.EventHandler(this.btn_CerrarSesion_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(164, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 21);
            this.label3.TabIndex = 10;
            this.label3.Text = "PAPERBROS";
            // 
            // btn_Ingresar
            // 
            this.btn_Ingresar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_Ingresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Ingresar.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Ingresar.Location = new System.Drawing.Point(197, 186);
            this.btn_Ingresar.Name = "btn_Ingresar";
            this.btn_Ingresar.Size = new System.Drawing.Size(82, 30);
            this.btn_Ingresar.TabIndex = 0;
            this.btn_Ingresar.Text = "Ingresar";
            this.btn_Ingresar.UseVisualStyleBackColor = false;
            this.btn_Ingresar.Click += new System.EventHandler(this.btn_Ingresar_Click);
            // 
            // btn_Opciones
            // 
            this.btn_Opciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_Opciones.Enabled = false;
            this.btn_Opciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Opciones.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Opciones.Location = new System.Drawing.Point(57, 186);
            this.btn_Opciones.Name = "btn_Opciones";
            this.btn_Opciones.Size = new System.Drawing.Size(82, 30);
            this.btn_Opciones.TabIndex = 5;
            this.btn_Opciones.Text = "Opciones";
            this.btn_Opciones.UseVisualStyleBackColor = false;
            this.btn_Opciones.Click += new System.EventHandler(this.btn_Opciones_Click);
            // 
            // pic_foto
            // 
            this.pic_foto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.pic_foto.Location = new System.Drawing.Point(326, 77);
            this.pic_foto.Name = "pic_foto";
            this.pic_foto.Size = new System.Drawing.Size(100, 97);
            this.pic_foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_foto.TabIndex = 8;
            this.pic_foto.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(451, 265);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pnl_inicio
            // 
            this.pnl_inicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnl_inicio.Controls.Add(this.btn_OpenQR);
            this.pnl_inicio.Controls.Add(this.pnl_QR);
            this.pnl_inicio.Controls.Add(this.pic_foto);
            this.pnl_inicio.Controls.Add(this.panel1);
            this.pnl_inicio.Controls.Add(this.pictureBox1);
            this.pnl_inicio.Controls.Add(this.txt_Contra);
            this.pnl_inicio.Controls.Add(this.label1);
            this.pnl_inicio.Controls.Add(this.btn_Ingresar);
            this.pnl_inicio.Controls.Add(this.btn_CerrarSesion);
            this.pnl_inicio.Controls.Add(this.btn_Opciones);
            this.pnl_inicio.Controls.Add(this.txt_Usuario);
            this.pnl_inicio.Controls.Add(this.label2);
            this.pnl_inicio.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_inicio.Location = new System.Drawing.Point(0, 0);
            this.pnl_inicio.Name = "pnl_inicio";
            this.pnl_inicio.Size = new System.Drawing.Size(451, 287);
            this.pnl_inicio.TabIndex = 11;
            // 
            // btn_OpenQR
            // 
            this.btn_OpenQR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_OpenQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OpenQR.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_OpenQR.Location = new System.Drawing.Point(336, 41);
            this.btn_OpenQR.Name = "btn_OpenQR";
            this.btn_OpenQR.Size = new System.Drawing.Size(82, 30);
            this.btn_OpenQR.TabIndex = 17;
            this.btn_OpenQR.Text = "QR";
            this.btn_OpenQR.UseVisualStyleBackColor = false;
            this.btn_OpenQR.Click += new System.EventHandler(this.btn_OpenQR_Click);
            // 
            // pnl_QR
            // 
            this.pnl_QR.BackColor = System.Drawing.Color.Transparent;
            this.pnl_QR.Controls.Add(this.btn_Cancel);
            this.pnl_QR.Controls.Add(this.pb_QR);
            this.pnl_QR.Controls.Add(this.txt_QR);
            this.pnl_QR.Controls.Add(this.label4);
            this.pnl_QR.Controls.Add(this.btn_login);
            this.pnl_QR.Controls.Add(this.cmb_Camara);
            this.pnl_QR.Location = new System.Drawing.Point(0, 29);
            this.pnl_QR.Name = "pnl_QR";
            this.pnl_QR.Size = new System.Drawing.Size(451, 258);
            this.pnl_QR.TabIndex = 15;
            this.pnl_QR.Visible = false;
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Cancel.Location = new System.Drawing.Point(326, 141);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(82, 30);
            this.btn_Cancel.TabIndex = 17;
            this.btn_Cancel.Text = "Cancelar";
            this.btn_Cancel.UseVisualStyleBackColor = false;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // pb_QR
            // 
            this.pb_QR.BackColor = System.Drawing.Color.DimGray;
            this.pb_QR.Location = new System.Drawing.Point(27, 48);
            this.pb_QR.Name = "pb_QR";
            this.pb_QR.Size = new System.Drawing.Size(226, 198);
            this.pb_QR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_QR.TabIndex = 16;
            this.pb_QR.TabStop = false;
            // 
            // txt_QR
            // 
            this.txt_QR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.txt_QR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txt_QR.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txt_QR.Location = new System.Drawing.Point(376, 11);
            this.txt_QR.Name = "txt_QR";
            this.txt_QR.Size = new System.Drawing.Size(70, 25);
            this.txt_QR.TabIndex = 12;
            this.txt_QR.Text = "Camara";
            this.txt_QR.UseVisualStyleBackColor = false;
            this.txt_QR.Click += new System.EventHandler(this.txt_QR_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(24, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Camaras";
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(43)))), ((int)(((byte)(53)))));
            this.btn_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_login.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btn_login.Location = new System.Drawing.Point(326, 95);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(82, 30);
            this.btn_login.TabIndex = 14;
            this.btn_login.Text = "Escanear";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // cmb_Camara
            // 
            this.cmb_Camara.FormattingEnabled = true;
            this.cmb_Camara.Location = new System.Drawing.Point(79, 11);
            this.cmb_Camara.Name = "cmb_Camara";
            this.cmb_Camara.Size = new System.Drawing.Size(278, 21);
            this.cmb_Camara.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(35)))));
            this.panel1.Controls.Add(this.pb_Min);
            this.panel1.Controls.Add(this.pb_Exit);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(451, 29);
            this.panel1.TabIndex = 11;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // pb_Min
            // 
            this.pb_Min.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Min.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Min.Image = ((System.Drawing.Image)(resources.GetObject("pb_Min.Image")));
            this.pb_Min.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Min.InitialImage")));
            this.pb_Min.Location = new System.Drawing.Point(381, 2);
            this.pb_Min.Name = "pb_Min";
            this.pb_Min.Size = new System.Drawing.Size(27, 26);
            this.pb_Min.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Min.TabIndex = 13;
            this.pb_Min.TabStop = false;
            this.pb_Min.Click += new System.EventHandler(this.pb_Min_Click);
            // 
            // pb_Exit
            // 
            this.pb_Exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pb_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(49)))));
            this.pb_Exit.Image = ((System.Drawing.Image)(resources.GetObject("pb_Exit.Image")));
            this.pb_Exit.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_Exit.InitialImage")));
            this.pb_Exit.Location = new System.Drawing.Point(419, 2);
            this.pb_Exit.Name = "pb_Exit";
            this.pb_Exit.Size = new System.Drawing.Size(27, 26);
            this.pb_Exit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Exit.TabIndex = 11;
            this.pb_Exit.TabStop = false;
            this.pb_Exit.Click += new System.EventHandler(this.pb_Exit_Click);
            // 
            // time_QR
            // 
            this.time_QR.Tick += new System.EventHandler(this.time_QR_Tick);
            // 
            // form_inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 287);
            this.Controls.Add(this.pnl_inicio);
            this.Controls.Add(this.lbl_TipoAdmin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_inicio";
            this.Text = "Inicio";
            this.Load += new System.EventHandler(this.form_inicio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_foto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_inicio.ResumeLayout(false);
            this.pnl_inicio.PerformLayout();
            this.pnl_QR.ResumeLayout(false);
            this.pnl_QR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_QR)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Exit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_Usuario;
        private System.Windows.Forms.TextBox txt_Contra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_TipoAdmin;
        private System.Windows.Forms.PictureBox pic_foto;
        private System.Windows.Forms.Button btn_CerrarSesion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_Ingresar;
        private System.Windows.Forms.Button btn_Opciones;
        private System.Windows.Forms.Panel pnl_inicio;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pb_Min;
        private System.Windows.Forms.PictureBox pb_Exit;
        private System.Windows.Forms.Button txt_QR;
        private System.Windows.Forms.ComboBox cmb_Camara;
        private System.Windows.Forms.Timer time_QR;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Panel pnl_QR;
        private System.Windows.Forms.PictureBox pb_QR;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_OpenQR;
        private System.Windows.Forms.Button btn_Cancel;
    }
}

