﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAPERBROS
{
    public partial class Opciones : Form
    {
        string TipoAdmin;
        string foto;
        public Opciones(string TipoU, string foto)
        {
            InitializeComponent();
            if (TipoU == "3")
            {
                cmb_Opciones.Items.AddRange(new String[] { "Cobrar", "Gestión ventas y tickets", "Registrar clientes y usuarios" });
            }
            if (TipoU == "1")
            {
                cmb_Opciones.Items.AddRange(new String[] { "Cobrar", "Gestión ventas y tickets", "Registrar clientes y usuarios", "Eliminar cliente","Bodega","Gestión de invetario", "SA y Gestión de usuarios","Bitacora"});
            }
            if (TipoU == "2")
            {
                cmb_Opciones.Items.AddRange(new String[] { "Cobrar", "Gestión ventas y tickets", "Registrar clientes y usuarios", "Eliminar cliente", "Bodega", "Gestión de inventario" });
            }

            TipoAdmin = TipoU;
            this.foto = foto;
            pic_foto.Image = Image.FromFile(Application.StartupPath + "\\Admins" + foto);
        }

        private void cmb_Opciones_SelectedIndexChanged(object sender, EventArgs e)
        {
            btn_Seleccionar.Enabled = true;
        }

        private void btn_Seleccionar_Click(object sender, EventArgs e)
        {
            /*
                "Cobrar",
            "Ver factura",
            "Registrar",
            "Eliminar cliente",
            "Agregar producto",
            "Inventario",
            "Super Administrador"
             */
            switch (cmb_Opciones.SelectedIndex)
            {
                case 0:
                    Cobrar cobrar = new Cobrar(TipoAdmin,foto);
                    cobrar.Show();
                    break;
                case 1:
                    Factura factura = new Factura(-2, -2,TipoAdmin,foto);
                    factura.Show();
                    break;
                case 2:
                    RegistrarAdmin registrarAdmin = new RegistrarAdmin(TipoAdmin,foto);
                    registrarAdmin.Show();
                    break;
                case 3:
                    BorrarUsuario borrarUsuario = new BorrarUsuario(TipoAdmin,foto);
                    borrarUsuario.Show();
                    break;
                case 4:
                    AgregarProducto agregarProducto = new AgregarProducto(TipoAdmin,foto);
                    agregarProducto.Show();
                    break;
                case 5:
                    Inventario inventario = new Inventario(TipoAdmin,foto);
                    inventario.Show();
                    break;
                case 6:
                    SuperAdministrador sa = new SuperAdministrador();
                    sa.Show();
                    break;
                case 7:
                    Bitacora Bitacora = new Bitacora();
                    Bitacora.Show();
                    break;
                case 8:

                    break;

            }
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Opciones_Load(object sender, EventArgs e)
        {

        }

        private void lbl_TipoAdmin_Click(object sender, EventArgs e)
        {

        }
    }
}
